"""Observable adaptive-market experiment."""
