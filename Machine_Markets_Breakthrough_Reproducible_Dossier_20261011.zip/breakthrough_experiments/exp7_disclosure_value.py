#!/usr/bin/env python3
"""
Phase 4 / Priority 7: Quantitative Value of Financial Disclosure
Quantifies how financial disclosures (I0 to I5) substitute for costly active probing.
Derives exact measurement channel Fisher information and optimizes required volume V and capital B
to achieve statistical identification error alpha <= 0.05 under each contract.

Clarifies:
- Theoretical capital infimum inf C = 0 under exact disclosure (Proposition 2.8)
- Real-world discrete lot size minimum lot V_min = 1.0 unit on Binance USD(S)-M
- Concrete joint likelihoods for prices, order flow, equity, and audit timestamps
"""
import json
import math
from pathlib import Path
import numpy as np
from scipy.stats import norm

def solve_contract_requirements(delta, alpha=0.05):
    z_alpha = norm.ppf(1.0 - alpha) # ~1.64485
    kappa = 0.8                     # price impact
    q = 0.2                         # feedback intensity
    mu = 0.005                      # Binance MMR (0.50%)
    c_fee = 0.0004                  # Binance taker fee (4 bps)
    P_star = 100.0                  # index price
    V_min_lot = 1.0                 # physical exchange minimum lot size (Binance USD(S)-M)
    
    # Noise parameters
    sigma_p = 0.01                  # price observation noise
    sigma_q = 0.05                  # order flow observation noise
    sigma_E_noisy = 0.50            # quarterly financial statement noise
    
    # ---------------------------------------------------------
    # Contract I0: Public Prices Only
    # Price difference signal: Delta p = kappa^2 * q * delta^2 * V / 2
    # KL = ||Delta p||^2 / (2 * sigma_p^2) >= 2 * z_alpha^2
    # ---------------------------------------------------------
    req_V_I0 = float((2.0 * sigma_p * z_alpha) / (kappa**2 * q * (delta**2)))
    req_B_I0 = float(0.5 * kappa * (req_V_I0**2) + (c_fee + mu) * P_star * req_V_I0)
    
    # ---------------------------------------------------------
    # Contract I1: Prices + Signed Order Flow
    # Flow provides direct measurement of algorithmic execution u_t:
    # Fisher information is additive: I_total = I_price + I_flow
    # ---------------------------------------------------------
    info_scale = 1.0 + (kappa * sigma_p / sigma_q)**2
    req_V_I1 = float(req_V_I0 / math.sqrt(info_scale))
    req_B_I1 = float(0.5 * kappa * (req_V_I1**2) + (c_fee + mu) * P_star * req_V_I1)
    
    # ---------------------------------------------------------
    # Contract I2: Prices + Noisy Marked Equity Disclosure (Proposition 2.8)
    # Marked equity difference: Delta E = kappa^2 * q * delta^2 * V^2
    # Under test with error target alpha: Delta E / sigma_E >= 2 * z_alpha
    # Yields scaling V ~ delta^{-1}:
    # V_req = (1 / delta) * sqrt((2 * sigma_E * z_alpha) / (kappa^2 * q))
    # ---------------------------------------------------------
    req_V_I2 = float((1.0 / delta) * math.sqrt((2.0 * sigma_E_noisy * z_alpha) / (kappa**2 * q)))
    req_B_I2 = float(0.5 * kappa * (req_V_I2**2) + (c_fee + mu) * P_star * req_V_I2)
    
    # ---------------------------------------------------------
    # Contract I3: Exact Account Equity Disclosure (Proposition 2.8)
    # Theoretical infimum is inf C = 0 (as V -> 0).
    # Under discrete exchange contract constraints, minimum lot is V_min_lot = 1.0.
    # ---------------------------------------------------------
    req_V_I3_theor = 0.0
    req_B_I3_theor = 0.0
    req_V_I3_phys = float(V_min_lot)
    req_B_I3_phys = float(0.5 * kappa * (req_V_I3_phys**2) + (c_fee + mu) * P_star * req_V_I3_phys) # ~0.94 USDT
    
    # ---------------------------------------------------------
    # Contract I4: Algorithmic Update Timestamps (Event Study)
    # Known event window eliminates search over horizon, V ~ delta^{-1}
    # ---------------------------------------------------------
    req_V_I4 = float(0.5 / delta)
    req_B_I4 = float(0.5 * kappa * (req_V_I4**2) + (c_fee + mu) * P_star * req_V_I4)
    
    # ---------------------------------------------------------
    # Contract I5: Supervisory Algorithmic Tagging / Full Audit Trail
    # Regulator directly inspects code/weights; zero probing needed
    # ---------------------------------------------------------
    req_V_I5 = 0.0
    req_B_I5 = 0.0

    # Operational per-trade capacity limit
    V_eff = 6.25

    def get_sequential_schedule(V_unconstrained):
        if V_unconstrained <= 0.0:
            return 0, 0.0, 0.0
        if V_unconstrained <= V_eff:
            n_p = 1
            b_seq = float(0.5 * kappa * (V_unconstrained**2) + (c_fee + mu) * P_star * V_unconstrained)
            return n_p, float(V_unconstrained), b_seq
        else:
            n_p = int(math.ceil((V_unconstrained / V_eff)**2))
            cost_pulse = float(0.5 * kappa * (V_eff**2) + c_fee * P_star * V_eff)
            margin_lockup = float(mu * P_star * V_eff)
            b_seq = float(n_p * cost_pulse + margin_lockup)
            return n_p, float(V_eff), b_seq

    n_p_I0, v_pulse_I0, b_seq_I0 = get_sequential_schedule(req_V_I0)
    n_p_I1, v_pulse_I1, b_seq_I1 = get_sequential_schedule(req_V_I1)
    n_p_I2, v_pulse_I2, b_seq_I2 = get_sequential_schedule(req_V_I2)
    n_p_I3, v_pulse_I3, b_seq_I3 = get_sequential_schedule(req_V_I3_phys)
    n_p_I4, v_pulse_I4, b_seq_I4 = get_sequential_schedule(req_V_I4)
    n_p_I5, v_pulse_I5, b_seq_I5 = get_sequential_schedule(req_V_I5)
    
    return {
        "I0_Prices_Only": {
            "required_volume_V": req_V_I0,
            "required_capital_B": req_B_I0,
            "sequential_n_pulses": n_p_I0,
            "sequential_pulse_size": v_pulse_I0,
            "sequential_capital_B": b_seq_I0,
            "disclosure_type": "Public Prices Only"
        },
        "I1_Prices_and_Flow": {
            "required_volume_V": req_V_I1,
            "required_capital_B": req_B_I1,
            "sequential_n_pulses": n_p_I1,
            "sequential_pulse_size": v_pulse_I1,
            "sequential_capital_B": b_seq_I1,
            "disclosure_type": "Public Flow Records"
        },
        "I2_Noisy_Equity": {
            "required_volume_V": req_V_I2,
            "required_capital_B": req_B_I2,
            "sequential_n_pulses": n_p_I2,
            "sequential_pulse_size": v_pulse_I2,
            "sequential_capital_B": b_seq_I2,
            "disclosure_type": "Periodic Accounting Statements"
        },
        "I3_Exact_Equity": {
            "required_volume_V": req_V_I3_phys,
            "required_capital_B": req_B_I3_phys,
            "theoretical_infimum_capital": req_B_I3_theor,
            "sequential_n_pulses": n_p_I3,
            "sequential_pulse_size": v_pulse_I3,
            "sequential_capital_B": b_seq_I3,
            "disclosure_type": "Exact Account Reporting (Min Lot)"
        },
        "I4_Update_Timestamps": {
            "required_volume_V": req_V_I4,
            "required_capital_B": req_B_I4,
            "sequential_n_pulses": n_p_I4,
            "sequential_pulse_size": v_pulse_I4,
            "sequential_capital_B": b_seq_I4,
            "disclosure_type": "Event Timestamps Registry"
        },
        "I5_Full_Audit_Trail": {
            "required_volume_V": req_V_I5,
            "required_capital_B": req_B_I5,
            "sequential_n_pulses": n_p_I5,
            "sequential_pulse_size": v_pulse_I5,
            "sequential_capital_B": b_seq_I5,
            "disclosure_type": "Ex-Ante Regulatory Model Tagging"
        }
    }

def run_experiment():
    deltas = [0.03, 0.05, 0.08, 0.12]
    results = []
    
    for delta in deltas:
        contracts_res = solve_contract_requirements(delta)
        results.append({
            "delta": delta,
            "contracts": contracts_res
        })
        
    out_file = Path("breakthrough_experiments/results_exp7_disclosure_value.json")
    out_file.write_text(json.dumps(results, indent=2))
    print(f"Disclosure Value Experiment complete. Results written to {out_file}")
    
    d5 = [r for r in results if r["delta"] == 0.05][0]["contracts"]
    print(f"\n--- Value of Financial Disclosure at delta = 0.05 ---")
    for k, v in d5.items():
        print(f"[{k:22s}] Volume V = {v['required_volume_V']:8.2f} | Capital B = {v['required_capital_B']:12.2f} USDT ({v['disclosure_type']})")

if __name__ == "__main__":
    run_experiment()
