#!/usr/bin/env python3
"""
Generates publication-quality canonical figures for the breakthrough research program:
- Figure 1: The Tri-Region Financial Identification Phase Diagram
- Figure 2: Probing Method Capital Cost Scaling (Theta(delta^{-4}) verification)
- Figure 3: Causal Multi-Agent Microstructure Intervention (Active vs Frozen vs Persistent)
- Figure 4: The Quantitative Value of Financial Disclosure Frontier (I0 to I5)
- Figure 5: Non-Normal Balance Sheet Decoupling & Multi-Asset Kreiss Inflation
"""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 11,
    'axes.labelsize': 12,
    'axes.titlesize': 13,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
    'figure.titlesize': 14,
    'lines.linewidth': 1.8
})

OUT_DIR = Path("breakthrough_experiments/figures")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------------------------------------
# Figure 1: The Tri-Region Financial Identification Phase Diagram
# -------------------------------------------------------------
def plot_fig1():
    with open("breakthrough_experiments/results_exp4_phase_diagram.json") as f:
        data = json.load(f)
        
    delta_min_t3 = data["parameters"]["delta_min_3rd_tap_approx"] # 0.2028
    delta_min_t20 = data["parameters"]["delta_min_T20"] # 0.0914
    
    curve_t20 = data["phase_diagram_T20_optimal"]["delta_curve"]
    curve_t3 = data["phase_diagram_T3_restricted"]["delta_curve"]
    
    deltas = np.array([d["delta"] for d in curve_t20])
    B_pulse_t20 = np.array([d["B_req_pulse"] for d in curve_t20])
    B_seq_t20 = np.array([d["B_req_sequential"] for d in curve_t20])
    B_seq_t3 = np.array([d["B_req_sequential"] for d in curve_t3])
    
    # Proved exact spectral lower bounds from Theorem IA.D.1 and IA.D.2
    # At delta=0.05: C*_det = 61.44 USDT, E[C*_adapt] = 30.09 USDT
    # Invariant constant: delta^4 * C*_det = 3.84e-4
    C_star_det = 3.84e-4 / (deltas ** 4)
    C_star_adapt = 0.4897 * C_star_det # 1.88e-4 / delta^4
    
    fig, ax = plt.subplots(figsize=(8.5, 6))
    
    # Plot boundaries
    ax.plot(deltas, B_pulse_t20, label=r'Single-Pulse Upper Bound ($T=20$)', color='darkblue', lw=2.0)
    ax.plot(deltas, B_seq_t20, label=r'Isolated-Pulse Upper Bound ($T=20$, $|v|\leq 6.25$)', color='darkorange', lw=2.0)
    ax.plot(deltas, B_seq_t3, label=r'Isolated-Pulse Baseline ($T=3$)', color='gray', lw=1.6, ls=':')
    ax.plot(deltas, C_star_det, label=r'Certified Deterministic Lower Bound $\underline{C}_{\mathrm{det}}(\delta)$ ($61.44$ at $\delta=0.05$)', color='crimson', lw=2.2)
    ax.plot(deltas, C_star_adapt, label=r'Adaptive Expected-Loss Lower Bound $\underline{C}_{\mathrm{adapt}}(\delta)$ ($30.09$ at $\delta=0.05$)', color='purple', lw=1.8, ls='-.')
    
    # Feasible non-pulse candidate point from Theorem IA.D.1 / IA.D.4 / Exp 16
    ax.scatter([0.05], [64.56], color='black', marker='*', s=160, zorder=6,
               label='Constructed Feasible Candidate (64.56 USDT at L=240; 64.60 at L=160)')
    
    # Vertical lines for physical depth limits
    ax.axvline(delta_min_t20, color='darkgreen', lw=1.6, ls='--', label=rf'Single-Pulse Floor $\delta_{{\min}}(20) = {delta_min_t20:.4f}$')
    ax.axvline(delta_min_t3, color='crimson', lw=1.6, ls='--', label=rf'Single-Pulse Floor $\delta_{{\min}}(3) = {delta_min_t3:.4f}$')
    
    # Fill Regions
    ax.fill_between(deltas, B_pulse_t20, 1e6, where=[d >= delta_min_t20 for d in deltas], color='green', alpha=0.10, label='Regime 1: Feasible Single-Pulse ($T=20$)')
    ax.fill_between(deltas, B_seq_t20, 1e6, where=[d < delta_min_t20 for d in deltas], color='orange', alpha=0.10, label='Regime 2: Feasible Sequential Isolated-Pulse')
    ax.fill_between(deltas, C_star_det, B_seq_t20, color='gold', alpha=0.10, label=r'Regime 3: Not Feasible with Tested Isolated Pulses ($T\leq 20$)')
    ax.fill_between(deltas, 1.0, C_star_det, color='red', alpha=0.12, label=r'Regime 4: Below Certified Deterministic Lower Bound $\underline{C}_{\mathrm{det}}(\delta)$')
    
    ax.set_yscale('log')
    ax.set_xlim(0.01, 0.25)
    ax.set_ylim(10.0, 1e6)
    ax.set_xlabel(r'Memory Separation Parameter $\delta$')
    ax.set_ylabel(r'Required Trader Capital $B$ (USDT, log scale)')
    ax.set_title('The Financial Identification Frontier: Multi-Observation Phase Diagram')
    ax.grid(True, which='both', ls='-', alpha=0.2)
    ax.legend(loc='upper right', frameon=True, fontsize=7.5)
    
    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig1_phase_diagram.pdf")
    plt.savefig(OUT_DIR / "fig1_phase_diagram.png", dpi=300)
    plt.close()
    print("Figure 1 generated.")

# -------------------------------------------------------------
# Figure 2: Probing Method Capital Cost Scaling
# -------------------------------------------------------------
def plot_fig2():
    with open("breakthrough_experiments/results_exp3_adaptive_probing.json") as f:
        data = json.load(f)
        
    protocols = list(set([r["protocol"] for r in data]))
    
    fig, ax = plt.subplots(figsize=(7.5, 5))
    colors = {'Method_A_Single_Pulse': 'navy', 'Method_B_Multi_Pulse': 'crimson', 
              'Method_C_Sequential_Feedback': 'forestgreen', 'Method_D_Minimax_LQG': 'darkorange'}
    labels = {
        'Method_A_Single_Pulse': 'Method A: Unconstrained Single Pulse',
        'Method_B_Multi_Pulse': 'Method B: Repeated Capacity Pulses (|v_t| <= 6.25 BTC)',
        'Method_C_Sequential_Feedback': 'Method C: Sequential SPRT Stopping',
        'Method_D_Minimax_LQG': 'Method D: Predetermined Gen.-Eigenvector Trajectory'
    }
    
    for prot in protocols:
        sub = [r for r in data if r["protocol"] == prot]
        sub = sorted(sub, key=lambda x: x["delta"])
        deltas = [r["delta"] for r in sub]
        costs = [r["mean_capital_cost"] for r in sub]
        ax.plot(deltas, costs, marker='o', label=labels.get(prot, prot), color=colors.get(prot, 'black'))
        
    # Theoretical delta^{-4} slope reference
    ref_deltas = np.array([0.03, 0.12])
    ref_costs = 5000.0 * (0.03 / ref_deltas)**4
    ax.plot(ref_deltas, ref_costs, 'k--', alpha=0.5, label=r'Theoretical $\Theta(\delta^{-4})$ Reference')
    
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel(r'Separation $\delta$ (log scale)')
    ax.set_ylabel(r'Probing Capital Cost $\mathcal{C}$ (USDT, log scale)')
    ax.set_title(r'Observed Capital Scaling Across Evaluated Probing Protocols ($\delta \in [0.03, 0.12]$)')
    ax.grid(True, which='both', ls='-', alpha=0.2)
    ax.legend(frameon=True, fontsize=8)
    
    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig2_probing_cost_scaling.pdf")
    plt.savefig(OUT_DIR / "fig2_probing_cost_scaling.png", dpi=300)
    plt.close()
    print("Figure 2 generated.")

# -------------------------------------------------------------
# Figure 3: Causal Multi-Agent Policy-Freeze Intervention
# -------------------------------------------------------------
def plot_fig3():
    with open("breakthrough_experiments/results_exp10_multi_agent.json") as f:
        full = json.load(f)
        data = full["conditions_summary"]
        causal = full["causal_intervention"]
        
    conds = ["P0_Baseline", "P2_Frozen_Policy", "P2_Active_Learning", "P1_Persistent_Flow"]
    labels = ["P0 Baseline\n(Noise Traders)", "P2 Frozen\n(Static Policy)", "P2 Active\n(Online Learning)", "P1 Persistent\n(TWAP Splitting)"]
    drawdowns = [data[c]["mean_dealer_drawdown"] for c in conds]
    errs = [data[c]["std_dealer_drawdown"] for c in conds]
    liq_rates = [data[c]["liquidation_rate"] * 100.0 for c in conds]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    
    # Left: Dealer Drawdown
    colors = ['gray', 'royalblue', 'darkblue', 'crimson']
    bars1 = ax1.bar(labels, drawdowns, yerr=errs, capsize=5, color=colors, alpha=0.85, edgecolor='black')
    ax1.set_ylabel('Mean Dealer Drawdown (USDT)')
    ax1.set_title('Intervention Impact on Dealer Drawdown')
    ax1.grid(True, axis='y', ls='--', alpha=0.3)
    ax1.set_ylim(0, max(drawdowns) * 1.35)
    
    # Dynamic annotation
    af_diff = causal["active_minus_frozen_drawdown_mean"]
    af_t = causal["active_minus_frozen_t_stat"]
    ax1.text(0.5, 0.88, f"Active vs Frozen Policy:\n+{af_diff:.2f} USDT (t = {af_t:.2f})",
             transform=ax1.transAxes, ha='center', fontsize=9,
             bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="black", lw=1.0))
             
    # Right: Liquidation Rate
    bars2 = ax2.bar(labels, liq_rates, color=colors, alpha=0.85, edgecolor='black')
    ax2.set_ylabel('Dealer Liquidation Rate (%)')
    ax2.set_title('Forced Liquidation Frequency (Binance MMR)')
    ax2.set_ylim(0, 100)
    ax2.grid(True, axis='y', ls='--', alpha=0.3)
    
    for bar in bars2:
        yval = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2.0, yval + 2, f"{yval:.1f}%", ha='center', va='bottom', fontsize=9, fontweight='bold')
        
    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig3_causal_multi_agent.pdf")
    plt.savefig(OUT_DIR / "fig3_causal_multi_agent.png", dpi=300)
    plt.close()
    print("Figure 3 generated.")

# -------------------------------------------------------------
# Figure 4: The Quantitative Value of Financial Disclosure Frontier
# -------------------------------------------------------------
def plot_fig4():
    with open("breakthrough_experiments/results_exp7_disclosure_value.json") as f:
        data = json.load(f)
        
    d5 = data["delta_0.05"]
    c_names = ["I0 (T=3)", "I0* (T=20)", "I1 Flow", "I2 (vs T=3)", "I2* (vs T=20)", "I3 CME Std", "I3 Micro", "I3* Binance", "I3 0.01 tick", "I4 (no model)", "I5 Audit"]
    keys = ["I0_Prices_Only_Restricted_T3", "I0_Prices_Only_Optimal_T20", "I1_Prices_and_Flow", "I2_Noisy_Equity_T3", "I2_Noisy_Equity_T20", 
            "I3_Exact_Equity_CME_Std_5BTC", "I3_Exact_Equity_CME_Micro_0_1BTC", "I3_Exact_Equity_Binance_minNotional", "I3_Exact_Equity_Cent_Rounded", "I4_Timestamps_Event_Study", "I5_Supervisory_Audit"]
    
    caps = [max(0.01, d5[k]["required_capital_B"]) for k in keys]
    vols = [d5[k]["required_volume_V"] for k in keys]
    
    fig, ax1 = plt.subplots(figsize=(10, 5))
    
    x = np.arange(len(c_names))
    width = 0.38
    
    color1 = 'navy'
    bars1 = ax1.bar(x - width/2, caps, width, label='Benchmark Capital B (USDT)', color=color1, alpha=0.85, edgecolor='black')
    ax1.set_ylabel('Required Capital B (USDT, log scale)', color=color1)
    ax1.set_yscale('log')
    ax1.set_ylim(0.005, 1e5)
    ax1.tick_params(axis='y', labelcolor=color1)
    
    ax2 = ax1.twinx()
    color2 = 'darkorange'
    bars2 = ax2.bar(x + width/2, vols, width, label='Required Executed Volume V', color=color2, alpha=0.85, edgecolor='black')
    ax2.set_ylabel('Required Executed Volume V', color=color2)
    ax2.tick_params(axis='y', labelcolor=color2)
    
    ax1.set_xticks(x)
    ax1.set_xticklabels(c_names, rotation=15, ha='right')
    ax1.set_title(r'Disclosure contracts at $\delta = 0.05$ (I2: independent reports; I3: noiseless unless rounded)')
    ax1.grid(True, axis='y', ls='--', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig4_disclosure_frontier.pdf")
    plt.savefig(OUT_DIR / "fig4_disclosure_frontier.png", dpi=300)
    plt.close()
    print("Figure 4 generated.")

# -------------------------------------------------------------
# Figure 5: Non-Normal Decoupling & Multi-Asset Kreiss Inflation
# -------------------------------------------------------------
def plot_fig5():
    with open("breakthrough_experiments/results_exp12_nonnormal_balance_sheet.json") as f:
        data = json.load(f)
        
    net_data = data["multi_asset_network"]
    M_vals = [r["assets_M"] for r in net_data]
    kreiss = [r["kreiss_constant"] for r in net_data]
    rho_vals = [r["spectral_radius"] for r in net_data]
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5))
    
    # Left: Decoupling Bar Chart
    labels = ['Price Output\nC = [1, 0]', 'Weighted (price, memory)\nC = [1, 160] (not a margin)']
    gains = [1.0, 160.003]
    colors = ['steelblue', 'crimson']
    
    bars = ax1.bar(labels, gains, color=colors, alpha=0.85, edgecolor='black', width=0.5)
    ax1.set_ylabel('Peak Transient Amplification Gain $M_C$')
    ax1.set_title('Coordinate-weighted operator gain (no holdings in state)')
    ax1.grid(True, axis='y', ls='--', alpha=0.3)
    for bar in bars:
        yval = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2.0, yval + 3, f"{yval:.1f}x", ha='center', va='bottom', fontsize=10, fontweight='bold')
        
    # Right: Multi-Asset Cross-Impact Coupling
    ax2.plot(M_vals, kreiss, marker='s', color='darkred', lw=2.2, label=r'Kreiss Constant $\mathcal{K}(J) = 1.00$ (Lower Bound)')
    ax2.plot(M_vals, rho_vals, marker='o', color='navy', lw=2.0, ls='--', label=r'Network Spectral Radius $\rho(J_{\mathrm{network}}) \to 1.0$')
    ax2.set_xlabel('Number of Cross-Impacted Assets $M$')
    ax2.set_ylabel('Stability & Resolvent Metrics')
    ax2.set_title(r'Cross-Impact Network Spectral Inflation ($\mathcal{K}(J) \equiv 1.00$)')
    ax2.grid(True, ls='--', alpha=0.3)
    ax2.legend(frameon=True)
    
    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig5_nonnormal_decoupling.pdf")
    plt.savefig(OUT_DIR / "fig5_nonnormal_decoupling.png", dpi=300)
    plt.close()
    print("Figure 5 generated.")

# -------------------------------------------------------------
# Figure 6: Three Breakthrough Frontiers (Exp 16, Exp 17, Exp 18)
# -------------------------------------------------------------
def plot_fig6():
    with open("breakthrough_experiments/results_exp16_nonconvex_duality.json") as f:
        d16 = json.load(f)
    with open("breakthrough_experiments/results_exp17_minimax_lecam_bound.json") as f:
        d17 = json.load(f)
    with open("breakthrough_experiments/results_exp18_crash_free_ai_guard.json") as f:
        d18 = json.load(f)

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(15, 4.6))

    # Panel A: Finite-Horizon Rayleigh-Holder Duality & Monotone vs Unpadded Convergence (Exp 16)
    L_vals = [r["L"] for r in d16["horizon_sweep"]]
    lb_rh = [r["lb_certified_FH_rayleigh_holder"] for r in d16["horizon_sweep"]]
    doublet = [r["lb_spectral_doublet_benchmark"] for r in d16["horizon_sweep"]]
    feas_c0 = [r["feasible_probe_C0"] for r in d16["horizon_sweep"]]
    unpad_c0 = [r["unpadded_full_support_C0"] for r in d16["horizon_sweep"]]
    eig_c0 = [r["eigen_probe_C0"] for r in d16["horizon_sweep"]]

    ax1.plot(L_vals, feas_c0, 'o-', color='darkblue', lw=2.2, label=r'Monotone Best Feasible $\overline{C}_0^{\mathrm{feas}}(\leq L)$ ($64.56$)')
    ax1.plot(L_vals, unpad_c0, 'x:', color='teal', lw=1.8, label=r'Unpadded Full-Support $C_0^{\mathrm{unpad}}(L)$')
    ax1.plot(L_vals, eig_c0, 's--', color='royalblue', lw=1.5, alpha=0.75, label=r'Eigen-Probe $C_0^{\mathrm{eig}}(L)$')
    ax1.plot(L_vals, doublet, '^-.', color='darkorange', lw=1.7, label='Spectral Doublet Benchmark')
    ax1.plot(L_vals, lb_rh, 'd-', color='crimson', lw=2.0, label='Interval-Certified RH LB $\\underline{C}_{\\mathrm{RH,cert}}(L)$')
    ax1.axhline(d16["lb_inf_total"], color='black', ls=':', lw=1.6, label=r'$\infty$-Horizon Certified LB ($61.44$ USDT)')
    ax1.set_xlabel('Permitted Active Horizon $L$ (steps)')
    ax1.set_ylabel('Account Capital $C_0$ (USDT)')
    ax1.set_title('(A) Interval-Certified Duality & Monotone UB')
    ax1.set_ylim(60.5, 67.5)
    ax1.grid(True, ls='--', alpha=0.3)
    ax1.legend(loc='lower right', fontsize=6.8, frameon=True)

    # Panel B: Global Le Cam Minimax Lower Bound vs Biased/Shrinkage Estimators (Exp 17)
    bench = sorted(d17["estimator_benchmark_delta_eta_010"], key=lambda x: x["N"])
    N_vals = [b["N"] for b in bench]
    lecam_lb = [b["lecam_minimax_fail_prob_lb"] * 100.0 for b in bench]
    ml_fail = [b["estimators"]["Unregularized_ML"]["worst_case_fail_prob"] * 100.0 for b in bench]
    ridge_fail = [b["estimators"]["Ridge_Tikhonov_L2"]["worst_case_fail_prob"] * 100.0 for b in bench]
    js_fail = [b["estimators"]["James_Stein_Shrinkage_035"]["worst_case_fail_prob"] * 100.0 for b in bench]
    heavy_fail = [b["estimators"]["Heavy_Prior_Shrinkage_075"]["worst_case_fail_prob"] * 100.0 for b in bench]

    ax2.plot(N_vals, ml_fail, 'o-', color='navy', lw=2.0, label='Unregularized ML')
    ax2.plot(N_vals, js_fail, 's--', color='darkorange', lw=1.8, label='James\u2013Stein Shrinkage ($\\gamma=0.35$)')
    ax2.plot(N_vals, ridge_fail, '^-', color='forestgreen', lw=1.8, label=r'Ridge / Tikhonov ($L_2$)')
    ax2.plot(N_vals, heavy_fail, 'v:', color='purple', lw=1.8, label=r'Heavy Prior Shrinkage ($\gamma=0.75$)')
    ax2.plot(N_vals, lecam_lb, 'd-', color='crimson', lw=2.4, label=r'Le Cam $\Omega((\Delta\eta)^{-6})$ Minimax LB')
    ax2.fill_between(N_vals, 0, lecam_lb, color='red', alpha=0.12, label='Minimax Infeasible Region')
    ax2.set_xscale('log')
    ax2.set_xlabel('Number of Probes $N$ (log scale)')
    ax2.set_ylabel(r'Worst-Case Error $\mathbb{P}(\|\hat{w}-w\|_\infty \geq 0.01)$ (%)')
    ax2.set_title(r'(B) Le Cam Minimax LB vs Shrinkage ($\Delta\eta=0.10$)')
    ax2.set_ylim(0, 105)
    ax2.grid(True, which='both', ls='--', alpha=0.3)
    ax2.legend(loc='upper right', fontsize=7.0, frameon=True)

    # Panel C: Conditional Bounded-Shock Resolvent Guard vs Eigenvalue Guard Max Drawdown (Exp 18)
    reg_labels = ['Regime I\nBenign', 'Regime II\nNon-Normal', 'Regime III\nSuper-Crit.', 'Regime IV\nBinance L2']
    eig_dd = [r["architectures"]["Eigenvalue_Guard"]["worst_max_drawdown_usdt"] for r in d18["regimes"]]
    halt_dd = [r["architectures"]["Static_Halt"]["worst_max_drawdown_usdt"] for r in d18["regimes"]]
    kreiss_dd = [r["architectures"]["Resolvent_Guard_Kreiss"]["worst_max_drawdown_usdt"] for r in d18["regimes"]]

    x = np.arange(len(reg_labels))
    w = 0.26
    ax3.bar(x - w, eig_dd, w, color='crimson', alpha=0.85, edgecolor='black', label=r'Eigenvalue Guard ($\rho \leq 0.95$)')
    ax3.bar(x, halt_dd, w, color='darkorange', alpha=0.85, edgecolor='black', label='Static Drawdown Halt')
    ax3.bar(x + w, kreiss_dd, w, color='forestgreen', alpha=0.90, edgecolor='black', label=r'Resolvent Guard ($\mathcal{G}_{\mathrm{Kreiss}}$)')
    ax3.axhline(d18["venue_calibration"]["maintenance_margin_breach_budget_usdt"], color='black', ls='--', lw=1.8,
                label=r'Liquidation Breach ($9{,}050$ USDT)')
    ax3.set_xticks(x)
    ax3.set_xticklabels(reg_labels)
    ax3.set_ylabel('Worst-Case Max Drawdown (USDT)')
    ax3.set_title(r'(C) Bounded-Shock Solvency ($\bar{u}_{\mathrm{adm}}=4.03$)')
    ax3.set_ylim(0, 13200)
    ax3.grid(True, axis='y', ls='--', alpha=0.3)
    ax3.legend(loc='upper left', fontsize=7.0, frameon=True)

    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig6_crash_free_and_minimax_frontiers.pdf")
    plt.savefig(OUT_DIR / "fig6_crash_free_and_minimax_frontiers.png", dpi=300)
    plt.close()
    print("Figure 6 generated.")


def plot_fig7():
    r19 = json.loads(Path("breakthrough_experiments/results_exp19_historical_crash_replay.json").read_text())
    r20 = json.loads(Path("breakthrough_experiments/results_exp20_exact_l2_book_walking.json").read_text())
    r21 = json.loads(Path("breakthrough_experiments/results_exp21_empirical_multi_asset_kreiss.json").read_text())

    fig, axes = plt.subplots(1, 3, figsize=(16.5, 4.8))

    # Panel A: Historical-Data-Conditioned Crisis Stress Benchmark across 4 Events (exp19)
    ax = axes[0]
    ev_keys = [
        "Crash_I_May2021_FlashCrash",
        "Crash_II_May2022_TerraLuna",
        "Crash_III_Nov2022_FTXRun",
        "Crash_IV_Mar2023_SVBDepeg",
    ]
    ev_labels = ["May 2021\nFlash Crash", "May 2022\nTerra/LUNA", "Nov 2022\nFTX Run", "Mar 2023\nSVB/USDC"]
    x = np.arange(len(ev_keys))
    width = 0.20

    liq_ug = [r19["events"][k]["architectures"]["Unguarded"]["liquidation_rate_pct"] for k in ev_keys]
    liq_eg = [r19["events"][k]["architectures"]["Eigenvalue_Guard"]["liquidation_rate_pct"] for k in ev_keys]
    liq_sh = [r19["events"][k]["architectures"]["Static_Halt"]["liquidation_rate_pct"] for k in ev_keys]
    liq_kr = [r19["events"][k]["architectures"]["Resolvent_Guard_Kreiss"]["liquidation_rate_pct"] for k in ev_keys]

    ax.bar(x - 1.5 * width, liq_ug, width, label=r"Unguarded ($\alpha_t=1$)", color="#d62728", alpha=0.85)
    ax.bar(x - 0.5 * width, liq_eg, width, label=r"Eigenvalue Guard ($\rho \leq 0.95$)", color="#ff7f0e", alpha=0.85)
    ax.bar(x + 0.5 * width, liq_sh, width, label=r"Static Halt ($\mathcal{G}_{\mathrm{halt}}$)", color="#7f7f7f", alpha=0.85)
    ax.bar(x + 1.5 * width, liq_kr, width, label=r"Resolvent Guard ($\mathcal{G}_{\mathrm{Kreiss}}$)", color="#2ca02c", alpha=0.95)
    for xi in x:
        ax.text(xi + 1.5 * width, 2.5, "0%", ha="center", va="bottom", fontsize=8, fontweight="bold", color="#1b611b")

    ax.set_xticks(x)
    ax.set_xticklabels(ev_labels, fontsize=8.5)
    ax.set_ylabel("Stress Benchmark Liquidation Rate (%)", fontsize=10)
    ax.set_ylim(0, 115)
    ax.set_title("(A) Historical-Conditioned Stress (4 Crashes)", fontsize=10.2, fontweight="bold")
    ax.legend(loc="upper right", fontsize=7.5, framealpha=0.9)
    ax.grid(axis="y", linestyle=":", alpha=0.5)

    # Panel B: Exact 10-Level L2 Book-Walking Slippage vs Static Linear Approximation (exp20)
    ax = axes[1]
    sp = r20["book_microstructure_stats"]["sweep_profile"]
    q_keys = ["1_BTC", "5_BTC", "10_BTC", "20_BTC", "50_BTC"]
    q_vals = [sp[k]["order_size_btc"] for k in q_keys]
    static_sl = [sp[k]["static_linear_mid_approx_usdt"] for k in q_keys]
    med_sl = [sp[k]["median_buy_slippage_usdt"] for k in q_keys]
    p90_sl = [sp[k]["p90_buy_slippage_usdt"] for k in q_keys]
    p99_sl = [sp[k]["p99_buy_slippage_usdt"] for k in q_keys]

    ax.plot(q_vals, static_sl, "k--", marker="s", lw=1.8, label="Static Mid-Slope Approx.")
    ax.plot(q_vals, med_sl, color="#1f77b4", marker="o", lw=2.0, label="Exact L2 Median Slippage")
    ax.plot(q_vals, p90_sl, color="#ff7f0e", marker="^", lw=2.2, label="Exact L2 90th Pct Slippage")
    ax.plot(q_vals, p99_sl, color="#d62728", marker="D", lw=2.2, label="Exact L2 99th Pct Slippage")
    ax.set_xlabel(r"Sweep Order Size $|q|$ (BTC)", fontsize=10)
    ax.set_ylabel(r"Slippage $|\bar{p}_{\mathrm{exec},t}(q) - m_t|$ (USDT/BTC)", fontsize=10)
    ax.set_title("(B) Exact 10-Level L2 Book Walking (Jan 2023)", fontsize=10.2, fontweight="bold")
    ax.legend(loc="upper left", fontsize=8, framealpha=0.9)
    ax.grid(True, linestyle=":", alpha=0.5)

    # Panel C: 8-Asset Cross-Margined Stress Operator Drawdowns vs Maintenance Threshold (exp21)
    ax = axes[2]
    port = r21["portfolio_ledger_100_episodes"]
    archs = ["Unguarded", "Eigenvalue_Guard", "Static_Halt", "Resolvent_Guard_Kreiss"]
    alabels = ["Unguarded\n(100% Liq.)", "Eigenvalue\n(100% Liq.)", "Static Halt\n(20% Liq.)", "Resolvent Guard\n(0.0% Liq.)"]
    mean_dds = [port[a]["mean_max_drawdown_usdt"] / 1000.0 for a in archs]
    p99_dds = [port[a]["p99_max_drawdown_usdt"] / 1000.0 for a in archs]
    x3 = np.arange(len(archs))
    w3 = 0.34

    ax.bar(x3 - 0.5 * w3, mean_dds, w3, label="Mean Max Drawdown", color=["#d62728", "#ff7f0e", "#7f7f7f", "#2ca02c"], alpha=0.85)
    ax.bar(x3 + 0.5 * w3, p99_dds, w3, label="99th Pct Drawdown", color=["#8c1919", "#b85900", "#4d4d4d", "#186218"], alpha=0.9)
    ax.axhline(61.54, color="red", linestyle="--", lw=1.8, label=r"Liquidation Boundary ($B_{\mathrm{maint}} = 61.54$k)")
    ax.set_xticks(x3)
    ax.set_xticklabels(alabels, fontsize=8.5)
    ax.set_ylabel("Portfolio Drawdown ($10^3$ USDT)", fontsize=10)
    ax.set_ylim(0, 90)
    ax.set_title(r"(C) 8-Asset Stress Operator $\hat{J}_{16}^{\mathrm{stress}}$ ($E_0 = 80$k)", fontsize=10.2, fontweight="bold")
    ax.legend(loc="upper right", fontsize=7.5, framealpha=0.9)
    ax.grid(axis="y", linestyle=":", alpha=0.5)

    plt.tight_layout()
    plt.savefig(OUT_DIR / "fig7_empirical_crisis_l2_and_8asset_network.pdf")
    plt.savefig(OUT_DIR / "fig7_empirical_crisis_l2_and_8asset_network.png", dpi=300)
    plt.close()
    print("Figure 7 generated.")


if __name__ == "__main__":
    import shutil
    plot_fig1()
    plot_fig2()
    plot_fig3()
    plot_fig4()
    plot_fig5()
    plot_fig6()
    plot_fig7()
    paper_fig_dir = Path("paper/figures")
    if paper_fig_dir.exists():
        for pdf_file in OUT_DIR.glob("fig*.pdf"):
            shutil.copy2(pdf_file, paper_fig_dir / pdf_file.name)
    print("All 7 breakthrough figures generated and synchronized with paper/figures/.")


