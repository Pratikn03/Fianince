> **Research completion update, October 8:** Eleven additional mathematical results compiled: the actual cohort-to-convolution/Gaussian-record bridge and all-time pulse-margin/exact-disclosure composition. The preserved strict audit covers 122 results; five further declarations and the expanded audit await recovery from observed macOS library-load failures. Annual-dependence/equivalence sensitivities and 93,558 independent scalar sweep checks are complete. Main-source novelty, inference and observed quote-friction calibration passages are revised. Full theorem coverage, actual-account calibration and main PDF export remain unfinished. See `research_extension/research_completion_20261008/` for outputs and the compiled standalone update. Historical contrary status below is superseded at this scope.

# Current formal proof work and author dependencies

The user again assigned the central statistical proofs, spectral/coercivity arguments and remaining theorem obligations to Codex. The author is not being asked to write Lean code or repeat proofs.

The current project builds and its strict axiom audit passes for **122 named mathematical declarations**, with all **304 project constants** scanned. The only observed dependencies are propext, Classical.choice and Quot.sound. The earlier73-proof receipt and sealed review ZIP are preserved as previous snapshots.

## New completed proof components

1. Finite AR-kernel backward factorization and uniform positive-mixture Toeplitz coercivity; strict nonzero execution cost.
2. Actual probe-trader cash/inventory/fundamental-mark solvency implies the corresponding probe-energy budget.
3. Actual finite causal convolution columns have Euclidean norm at most the first column; a first pulse achieves the greatest lifetime-quantity signal norm.
4. Actual Radon-Nikodym likelihoods for scalar and product laws; equal-variance Gaussian KL for any finite observation record.
5. Lifetime-quantity KL bound and first-pulse attainment with arbitrary common deterministic baseline means.
6. Explicit uniform unit-circle transfer bound for the symmetric cohort pair.
7. Exact price-only Euclidean peak gain over every signed initial state and every time in the positive class, with time-zero attainment.

## Still assigned to Codex

The full all-horizon cohort response/convolution bridge, Gaussian minimax/Pinsker argument, induced L2/Parseval link, actual positive-cohort spectral-mixture construction and remaining realization/Kalman/passive/capacity-Jury/Kreiss-network/gate obligations are not complete. The exact map is MANUSCRIPT_COVERAGE.md and its JSON counterpart. No full-paper verification or9+ certification is made.

## Questions pending with the author

1. Current affiliations/status, contributions, research funding and conflicts for both authors.
2. Paths/links to any missing source/unit/venue/accounting records and earlier AI-use histories; not available is an acceptable factual answer.
3. Existing independent mathematical/control and econometric/microstructure reviewers, or whether the author will send the prepared requests.

Two specific reviewer-request drafts are prepared locally and have not been sent. Independent human review has not been obtained. No external submission, reviewer message, commit or push has been performed.
