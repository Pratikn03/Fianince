# October 8 proof, novelty, inference and calibration work

This is a source/evidence amendment to the preserved author/source-recovery release. The previous 52-page main PDF, 8-page evidence PDF and sealed reviewer ZIP remain unchanged. The main manuscript source has new localized passages; its new PDF export is pending the observed macOS execution failure. Do not label the old PDF as containing these latest edits.

## Delivered

- `CurrentProofs/CohortConvolution.lean`: eight additional results compiled in a successful full project build. These connect the actual economic recursion and finite price record to causal convolution and the Gaussian observation KL. Five further declarations in that source require a new build.
- `CurrentProofs/DisclosureSolvency.lean`: three additional results compiled, including an all-time counterparty margin guarantee and an arbitrarily small, solvent exact-equity distinguishing pulse.
- `NOVELTY_ARGUMENT.md`: precise observer/resource/account contribution, comparisons with closest primary research and explicit limits of the increment.
- `inference_completion.json`: annual dependence and leave-one-year-out references, annual sign enumeration, economically scaled equivalence sensitivity and explicit bias-bound scenarios.
- `displayed_book_calibration.json`: spread/depth distributions and six hypothetical side-depth sweeps per selected minute from the existing January source.
- `completion_evidence_verification.json`: independent native scalar calculations and original CSV last-minute book comparison. No object array or pickle was loaded.
- `Machine_Markets_Proof_Evidence_Update_20261008.tex`: a standalone update compiled successfully with the built-in desktop compiler; open it for the PDF preview.
- `manuscript_completion_field_verification.json`: separately binds new numeric prose/table literals to the checked result files.

## Verification and scope

The preserved strict Lean receipt covers 122 results. Eleven additional results compiled, but their expanded strict audit is pending. Five further declarations have not passed the new build. Full manuscript formalization remains incomplete; residuals are enumerated in `MANUSCRIPT_COVERAGE.md` and owned by Codex. Never treat the 138 source declarations as 138 verified results.

The calibration independently streams all 3,730,870 original CSV rows to check the 15,593 selected minute books, then reproduces all 93,558 scalar sweep records and all 17 pooled metrics/12 daily summaries. The quantity sizes remain reported units. Hypothetical displayed sweeps are not actual fills, dynamic impact calibration or an account-solvency validation.

The annual references use explicit independence/comparability or sign-symmetry assumptions. The fee comparison has one treated asset, and no identified bound on differential trends/spillovers. The manuscript resolves its claim scope by retaining association and sensitivity results; it does not assert a causal result that the data cannot establish.

## Reproduce

From the full project root, the current host's native fallback is:

```sh
/usr/bin/perl research_extension/research_completion_20261008/verify_completion_native.pl
/usr/bin/perl research_extension/research_completion_20261008/verify_manuscript_fields.pl
```

The first command needs the original CSV and the private minute-book NPZ cache on T9. Its numeric NPY parser rejects object members; it derives UTC dates from timestamps. The original calibration script is preserved with the exact source hash recorded by its output. The current Python writer changes date storage to fixed Unicode on the next run; the already generated private cache is not silently rewritten.

After local execution is restored, rebuild the expanded Lean project, run its strict verifier, rerun the existing empirical/supplement/source checks against the revised manuscript, regenerate the JF candidate, export PDFs and inspect their rendering. The remaining theorem proofs then continue against the coverage map. Missing account records and specialist feedback remain separate dependencies.

macOS rejected Python, Lean/Lake and terminal LaTeX libraries with `library load mig callout failed`. The new strict audit and PDF export are therefore not claimed to pass. No library-validation protection was disabled and no system executable was re-signed. No publication, push or reviewer message was sent.
