================================================================================
PAPER 1: COMPLETE CO-AUTHOR REVIEW & EDITING PACKAGE (NOVEMBER 2026 REVISION)
================================================================================

Title: Market Microstructure with Algorithmic Speed Asymmetry:
       Inventory Ceilings, Queue Depletion, and Stability Transitions
Authors: Pratik Niroula, Sujan Khatiwada, Prashant Niroula

This package contains all materials for the comprehensive review and direct editing 
of the updated Paper 1 manuscript.

--------------------------------------------------------------------------------
FOLDER STRUCTURE & CONTENTS:
--------------------------------------------------------------------------------

01_Editable_Word_Manuscript/
    * Paper1_Full_Manuscript.docx
      - Full, unabridged manuscript of Paper 1 converted into Microsoft Word format.
      - Includes native equations, formatted tables, section headers, and references.
      - PURPOSE: Please open this file in Word, enable "Track Changes", and make 
        direct textual edits, comments, and proof adjustments.

02_New_Paper1_PDFs/
    * Paper1_Main_Paper.pdf
      - Main research paper (clean journal article format, 54 pages).
    * Paper1_Full_Master_Manuscript_and_Supplement.pdf
      - Complete unified master PDF including the main text and technical appendices.
    * Paper1_SSRN_Submission_Version.pdf
      - Formatted SSRN working paper submission release.
    * Paper1_WFA_Anonymous_Version.pdf
      - Anonymized submission version prepared for double-blind conference review.
    * Paper1_Online_Technical_Supplement.pdf
      - Online technical supplement containing extended mathematical proofs and derivations.
    * Paper1_Feedback_Spectral_Supplement.pdf
      - Dedicated supplement on frequency-domain feedback dynamics and spectral stability.
    * Paper1_Finite_Horizon_Inventory_Supplement.pdf
      - Dedicated supplement on finite-horizon inventory trajectories and Riccati systems.
    * Paper1_Reproducibility_and_Code_Map.pdf
      - Computational map connecting all empirical figures and tables to replication scripts.

03_Questions_and_Solution_Manual/
    * Paper1_Questions_Workbook.docx
      - 30 In-Depth Master Questions covering every theorem, proposition, empirical model,
        and institutional mechanism across Paper 1.
      - Each question provides precise section references and a detailed "What to focus on"
        analysis guide to verify complete understanding and rigor.
    * Paper1_Answers_Solution_Manual.docx
      - Full reference solution manual containing rigorous mathematical and empirical answers
        to all 30 questions for cross-verification.

--------------------------------------------------------------------------------
RECOMMENDED REVIEW WORKFLOW:
--------------------------------------------------------------------------------
1. Read the updated main text in `02_New_Paper1_PDFs/Paper1_Main_Paper.pdf`.
2. Work through the 30 questions in `03_Questions_and_Solution_Manual/Paper1_Questions_Workbook.docx`.
   Verify each derivation and empirical specification against the reference manual.
3. Open `01_Editable_Word_Manuscript/Paper1_Full_Manuscript.docx`, enable "Track Changes",
   and directly record your edits, comments, and proposed text changes.
4. Return your edited Word document and question notes.
================================================================================
