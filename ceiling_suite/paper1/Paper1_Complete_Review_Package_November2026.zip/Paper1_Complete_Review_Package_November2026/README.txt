================================================================================
PAPER 1: COMPLETE CO-AUTHOR REVIEW & EDITING PACKAGE (NOVEMBER 2026 REVISION)
================================================================================

Title: Market Microstructure with Algorithmic Speed Asymmetry:
       Inventory Ceilings, Queue Depletion, and Stability Transitions
Authors: Pratik Niroula, Sujan Khatiwada, Prashant Niroula

This package contains all materials for the comprehensive review, analytical verification,
and direct editing of the updated Paper 1 manuscript.

--------------------------------------------------------------------------------
PACKAGE STRUCTURE & FILE MANIFEST:
--------------------------------------------------------------------------------

01_Editable_Word_Manuscript/
    * Paper1_Full_Manuscript.docx
      - The complete, unabridged manuscript of Paper 1 converted to Microsoft Word format.
      - Includes native Word math equations, formatted econometric tables, section headers, 
        and full bibliographic references.
      - INSTRUCTIONS: Open this document in Word, enable "Track Changes", and make your 
        direct textual edits, comments, and mathematical adjustments.

02_New_Paper1_PDFs/
    * Paper1_Main_Paper.pdf
      - Main research paper (clean journal article format, 54 pages).
    * Paper1_Full_Master_Manuscript_and_Supplement.pdf
      - Complete unified master PDF including the main text and technical appendices.
    * Paper1_SSRN_Submission_Version.pdf
      - SSRN working paper submission release.
    * Paper1_WFA_Anonymous_Version.pdf
      - Anonymized submission version prepared for double-blind conference review.
    * Paper1_Online_Technical_Supplement.pdf
      - Online technical supplement containing extended mathematical proofs and derivations.
    * Paper1_Feedback_Spectral_Supplement.pdf
      - Dedicated supplement on frequency-domain feedback dynamics and spectral stability.
    * Paper1_Finite_Horizon_Inventory_Supplement.pdf
      - Dedicated supplement on finite-horizon inventory trajectories and Riccati systems.
    * Paper1_Reproducibility_and_Code_Map.pdf
      - Computational map connecting all empirical figures and tables to replication scripts.

03_Questions_and_Solution_Manual/
    * Paper1_Questions_Workbook.docx
      - Contains 31 in-depth research questions covering every theorem, proposition,
        empirical model, and institutional mechanism across Paper 1.
      - Questions 1 to 30: Deep theoretical, empirical, and institutional questions
        with a unified "What to focus on" guidance section for rigorous study.
      - Question 31: Co-Author Section-by-Section Editorial & Revision Log. After editing
        the manuscript in Word, use Question 31 to record exactly what changes, verifications,
        and comments you made across each section of the paper.
    * Paper1_Answers_Solution_Manual.docx
      - Full reference solution manual containing complete mathematical, empirical, and
        institutional solutions to all 31 questions (including a model editorial log for Question 31).

--------------------------------------------------------------------------------
RECOMMENDED STEP-BY-STEP REVIEW WORKFLOW:
--------------------------------------------------------------------------------
Step 1: Read the updated manuscript PDF (`02_New_Paper1_PDFs/Paper1_Main_Paper.pdf`).
Step 2: Study the 30 core research questions in `03_Questions_and_Solution_Manual/Paper1_Questions_Workbook.docx` 
        to verify every mathematical step, derivation, and empirical finding. Cross-check your 
        reasoning against `Paper1_Answers_Solution_Manual.docx`.
Step 3: Open `01_Editable_Word_Manuscript/Paper1_Full_Manuscript.docx` in Word with "Track Changes" 
        enabled. Make your direct edits, revisions, and marginal comments throughout the paper.
Step 4: Under Question 31 in the workbook (or as an accompanying log), document section-by-section 
        what edits and contributions you made in the Word file.
Step 5: Send back your edited `Paper1_Full_Manuscript.docx` with tracked changes and your completed 
        Question 31 log.
================================================================================
