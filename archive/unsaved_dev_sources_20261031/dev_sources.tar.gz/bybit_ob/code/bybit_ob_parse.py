"""Rebuild a Bybit ob200 order book from a daily .data file and return 1-minute features.
Each line is a JSON message: a 'snapshot' resets the book, a 'delta' sets price levels (qty 0 = delete).
Features use the book as it stands at the END of each minute (last message with ts < minute end)."""
import json, sys, math
import numpy as np, pandas as pd

def minute_book(path, band=0.01):
    bids, asks = {}, {}
    rows = []; cur_min = None; last_u = None; gaps = 0
    def record(m):
        if not bids or not asks: return
        bb = max(bids); ba = min(asks)
        if bb >= ba: return
        mid = 0.5*(bb+ba)
        lo, hi = mid*(1-band), mid*(1+band)
        bd = sum(p*q for p,q in bids.items() if p >= lo)
        ad = sum(p*q for p,q in asks.items() if p <= hi)
        rows.append((m, mid, bb, ba, bids[bb]*bb, asks[ba]*ba, bd, ad, len(bids), len(asks)))
    with open(path) as fh:
        for line in fh:
            r = json.loads(line); ts = r['ts']; m = ts // 60000
            if cur_min is not None and m != cur_min:
                record(cur_min)   # book state at end of cur_min
            cur_min = m
            d = r['data']
            if r['type'] == 'snapshot':
                bids = {float(p): float(q) for p,q in d['b']}
                asks = {float(p): float(q) for p,q in d['a']}
            else:
                if last_u is not None and d['u'] != last_u + 1: gaps += 1
                for p,q in d['b']:
                    p=float(p); q=float(q)
                    if q == 0: bids.pop(p, None)
                    else: bids[p] = q
                for p,q in d['a']:
                    p=float(p); q=float(q)
                    if q == 0: asks.pop(p, None)
                    else: asks[p] = q
            last_u = d['u']
    record(cur_min)
    df = pd.DataFrame(rows, columns=['minute','mid','bid','ask','bid_top_usd','ask_top_usd',
                                     'bid_depth1_usd','ask_depth1_usd','n_bid','n_ask'])
    df['time'] = pd.to_datetime(df.minute*60000, unit='ms', utc=True)
    df['spread_bps'] = 1e4*(df.ask-df.bid)/df.mid
    df['depth1_usd'] = df.bid_depth1_usd + df.ask_depth1_usd
    df['imbalance'] = (df.bid_depth1_usd-df.ask_depth1_usd)/df.depth1_usd
    df.attrs['u_gaps'] = gaps
    return df

if __name__ == '__main__':
    for p in sys.argv[1:]:
        df = minute_book(p)
        day = df[df.time.dt.normalize() == df.time.dt.normalize().iloc[0]]
        print(p.split('/')[-1], 'minutes', len(day), 'u_gaps', df.attrs['u_gaps'])
        print(day[['mid','spread_bps','depth1_usd','bid_depth1_usd','ask_depth1_usd','imbalance','n_bid','n_ask']]
              .describe(percentiles=[.05,.5,.95]).round(5).to_string())
        r = np.diff(np.log(day.mid.values)); print('1-min ret std', r.std(), ' n zero-change mins', (r==0).sum())
