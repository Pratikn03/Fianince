# ============================================================================
# CELL D4 — IS THE PRICE OVERSHOOT CARRIED BY DEPTH? (mediation local projections, training days)
# y_k = p_{t+k} - p_{t-1} on u_t, with 5 lags of Δp, u, d as controls. Three versions:
#   (A) total
#   (B) + cumulative future flow u_{t+1..t+k}           (removes order-splitting persistence)
#   (C) + future flow + cumulative depth imbalance d_t + ... + d_{t+k-1}   (removes the depth channel:
#       in T6 the price path accumulates φ·Σd)
# T6 predicts: overshoot in (B) (max_{k>=1} β_k - β_0 > 0) that shrinks in (C).
# ============================================================================
H_MIN = [0, 1, 2, 3, 5, 10, 15, 30]

def lp_day_depth(df, nl=5):
    p, u, dd_, x, tot = prep(df)
    dp = np.diff(p, prepend=p[0])
    n = len(p); mk = max(H_MIN)
    t = np.arange(nl + 1, n - mk - 1)
    if not np.isfinite(dd_[t]).mean() > 0.9:
        return None
    L = np.column_stack([dp[t - j] for j in range(1, nl + 1)] + [u[t - j] for j in range(1, nl + 1)] +
                        [dd_[t - j] for j in range(1, nl + 1)])
    cu = np.concatenate([[0.0], np.cumsum(u)])
    cd = np.concatenate([[0.0], np.cumsum(np.nan_to_num(dd_))])
    out = {"A": [], "B": [], "C": []}
    for k in H_MIN:
        y = p[t + k] - p[t - 1]
        XA = np.column_stack([u[t], L])
        fut = cu[t + k + 1] - cu[t + 1]
        XB = np.column_stack([XA, fut]) if k > 0 else XA
        XC = np.column_stack([XB, cd[t + k] - cd[t]]) if k > 0 else XB
        for key, X in (("A", XA), ("B", XB), ("C", XC)):
            b = ols(y, X)
            out[key].append(b[0] if b is not None else np.nan)
    return {k: np.array(v) for k, v in out.items()}

per = [r for r in (lp_day_depth(DAYS[d]) for d in train_days) if r is not None]
R4 = rng(44); res4 = {}
for key in ("A", "B", "C"):
    M = np.array([r[key] for r in per]); M = M[np.all(np.isfinite(M), 1)]
    mean = M.mean(0)
    boots = np.array([M[R4.integers(0, len(M), len(M))].mean(0) for _ in range(1000)])
    over = boots[:, 1:].max(1) - boots[:, 0]
    res4[key] = {"beta_bp_per_musd": mean, "overshoot": float(mean[1:].max() - mean[0]),
                 "overshoot_ci": [float(np.quantile(over, .025)), float(np.quantile(over, .975))],
                 "peak_minute": H_MIN[int(np.argmax(mean))]}
    print(f"({key}) β by minute {np.round(mean, 3)}  overshoot {res4[key]['overshoot']:.3f} CI {np.round(res4[key]['overshoot_ci'], 3)}")
med = (res4["B"]["overshoot"] - res4["C"]["overshoot"]) / res4["B"]["overshoot"] if res4["B"]["overshoot"] > 0 else np.nan
record("D4_depth_mediation_train", None, "real-data", {"horizons_min": H_MIN, "versions": res4,
       "share_of_overshoot_carried_by_depth": med, "n_days": len(per)},
       note="Evidence for T6: overshoot CI > 0 in (B) and a clearly smaller overshoot in (C).")
