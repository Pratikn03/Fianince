# ============================================================================
# CELL D6 — DO T6 CONDITIONS PRECEDE LIQUIDATIONS? (training period, in-sample; liquidation data
# exist only until 2024-03-31). Reported as descriptive evidence, not as the held-out test.
# ============================================================================
lq = blocks[(blocks["split"] == "train") & blocks["liq_60"].notna()].copy()
res6 = {"n_blocks": int(len(lq))}
if len(lq) > 200:
    lq["log_liq"] = np.log1p(lq["liq_60"])
    lo, hi_ = lq["C3_hat"].quantile([0.01, 0.99])
    lq["C3w"] = lq["C3_hat"].clip(lo, hi_)
    ctrl = ["rv_60", "rv_360", "abs_ret_60", "flow_imb_60", "log_vol_60", "log_depth1", "imbalance", "oi_chg_60"]
    sub = lq.dropna(subset=ctrl + ["C3w", "log_liq"])
    X0 = np.column_stack([np.ones(len(sub)), sub[ctrl].to_numpy()])
    X1 = np.column_stack([X0, sub["C3w"].to_numpy()])
    y = sub["log_liq"].to_numpy()
    b0 = np.linalg.lstsq(X0, y, rcond=None)[0]; b1 = np.linalg.lstsq(X1, y, rcond=None)[0]
    r2_0 = 1 - np.sum((y - X0 @ b0) ** 2) / np.sum((y - y.mean()) ** 2)
    r2_1 = 1 - np.sum((y - X1 @ b1) ** 2) / np.sum((y - y.mean()) ** 2)
    # day-cluster bootstrap for the C3 coefficient
    R6 = rng(66); days_ = sub["date"].to_numpy(); ud_ = np.unique(days_); bs = []
    for _ in range(500):
        pick = R6.choice(ud_, len(ud_)); idx = np.concatenate([np.where(days_ == d)[0] for d in pick])
        bs.append(np.linalg.lstsq(X1[idx], y[idx], rcond=None)[0][-1])
    top = sub["C3w"] >= sub["C3w"].quantile(0.9)
    res6.update({"coef_C3": float(b1[-1]), "coef_C3_ci": [float(np.quantile(bs, .025)), float(np.quantile(bs, .975))],
                 "r2_controls": float(r2_0), "r2_with_C3": float(r2_1),
                 "mean_liq_musd_top_decile_C3": float(sub.loc[top, "liq_60"].mean()),
                 "mean_liq_musd_other": float(sub.loc[~top, "liq_60"].mean()),
                 "share_C3_positive": float((sub["C3_hat"] > 0).mean())})
print(json.dumps(_clean(res6), indent=1))
record("D6_liquidations_in_sample", None, "real-data", res6,
       note="In-sample only (data end 2024-03-31). Support for T6 = positive C3 coefficient with CI above 0.")
