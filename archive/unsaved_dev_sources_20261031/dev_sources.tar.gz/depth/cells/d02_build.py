# ============================================================================
# CELL D2 — DOWNLOAD, VALIDATE AND BUILD THE 1-MINUTE PANEL
# Every archive is checked against its official .CHECKSUM when one is published.
# bookDepth validation rules (fixed here, before any analysis; also pre-registered in D7):
#   V1 a snapshot needs bands -5,-2,-1,+1,+2,+5 (present in both old and new formats)
#   V2 cumulative depth must be non-decreasing with distance from mid on each side
#   V3 implied average price notional/depth at ±1% must be within 3% of the 1-min futures close
#      (drops the known Apr–May 2025 misaligned snapshots and similar anomalies)
#   V4 runs of > 10 identical consecutive snapshots (stuck feed) are dropped
#   V5 a day is used only if >= 80% of its minutes have a valid depth snapshot
# ============================================================================
KL_COLS = ["open_time", "open", "high", "low", "close", "volume", "close_time", "quote_volume",
           "count", "taker_buy_volume", "taker_buy_quote_volume", "ignore"]
DL_LOG = []

def fetch(ds, date):
    """Raw zip bytes (checksum-verified when possible) or None if the file does not exist."""
    url = ds_url(ds, date)
    code, raw = _http(url)
    if code != 200:
        return None
    sha = hashlib.sha256(raw).hexdigest()
    c2, chk = _http(url + ".CHECKSUM", timeout=30)
    verified = None
    if c2 == 200 and chk:
        official = chk.decode().split()[0]
        if official != sha:
            raise RuntimeError(f"SHA-256 mismatch {url}")
        verified = True
    DL_LOG.append({"ds": ds, "date": date, "sha256": sha, "checksum_verified": verified})
    return raw

def read_zip_csv(raw, default_cols=None):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        name = [n for n in z.namelist() if n.endswith(".csv")][0]
        txt = z.read(name).decode("utf-8", errors="ignore")
    first = txt.split("\n", 1)[0]
    has_header = bool(re.search(r"[A-Za-z_]", first.split(",")[0]))
    df = pd.read_csv(io.StringIO(txt), header=0 if has_header else None)
    if not has_header and default_cols is not None:
        df.columns = default_cols[:df.shape[1]]
    df.columns = [str(c).strip().lower() for c in df.columns]
    return df

def to_utc_seconds(col):
    s = pd.Series(col)
    if pd.api.types.is_numeric_dtype(s):
        v = s.astype("int64").to_numpy()
        return np.where(v > 1e14, v // 1_000_000, np.where(v > 1e11, v // 1000, v))
    ts = pd.to_datetime(s, utc=True)                      # resolution-independent (pandas 2 and 3)
    return ((ts - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta("1s")).astype("int64").to_numpy()

def build_minute_day(date, need_liq):
    t0 = int(pd.Timestamp(f"{date} 00:00:00", tz="UTC").timestamp())
    idx = np.arange(1440)
    out = pd.DataFrame(index=idx)
    # ---- klines 1m ----
    raw = fetch("klines", date)
    if raw is None:
        return None, {"date": date, "reason": "no klines"}
    k = read_zip_csv(raw, KL_COLS)
    tk = (to_utc_seconds(k["open_time"]) - t0) // 60
    k = k.assign(m=tk).drop_duplicates("m").set_index("m").reindex(idx)
    out["close"] = k["close"].astype(float).ffill().bfill()
    out["flow"] = (2 * k["taker_buy_quote_volume"].astype(float) - k["quote_volume"].astype(float)).fillna(0) / 1e6
    out["vol"] = k["quote_volume"].astype(float).fillna(0) / 1e6
    stats_ = {"date": date}
    # ---- bookDepth ----
    raw = fetch("bookDepth", date)
    for c in ["bid1", "ask1", "bid2", "ask2", "bid5", "ask5"]:
        out[c] = np.nan
    if raw is not None:
        b = read_zip_csv(raw)
        b["sec"] = to_utc_seconds(b["timestamp"])
        b["percentage"] = pd.to_numeric(b["percentage"], errors="coerce").round().astype("Int64")
        need = [-5, -2, -1, 1, 2, 5]
        piv_n = b.pivot_table(index="sec", columns="percentage", values="notional", aggfunc="last")
        piv_d = b.pivot_table(index="sec", columns="percentage", values="depth", aggfunc="last")
        n0 = len(piv_n)
        ok = piv_n.reindex(columns=need).notna().all(axis=1) & piv_d.reindex(columns=need).notna().all(axis=1)       # V1
        piv_n, piv_d = piv_n[ok], piv_d[ok]
        mono = ((piv_d[-2] >= piv_d[-1]) & (piv_d[-5] >= piv_d[-2]) &
                (piv_d[2] >= piv_d[1]) & (piv_d[5] >= piv_d[2]))                                         # V2
        minute = ((piv_n.index.to_numpy() - t0) // 60).clip(0, 1439)
        ref = out["close"].to_numpy()[minute]
        imp_b, imp_a = piv_n[-1] / piv_d[-1], piv_n[1] / piv_d[1]
        price_ok = (np.abs(imp_b / ref - 1) < 0.03) & (np.abs(imp_a / ref - 1) < 0.03)                   # V3
        sig = piv_n[need].round(2).astype(str).agg("|".join, axis=1)
        runid = (sig != sig.shift()).cumsum()
        runlen = sig.groupby(runid).transform("size")
        not_stale = runlen <= 10                                                                         # V4
        good = mono & price_ok & not_stale
        g = piv_n[good]
        gm = ((g.index.to_numpy() - t0) // 60).clip(0, 1439)
        snap = pd.DataFrame({"m": gm, "bid1": g[-1].to_numpy(), "ask1": g[1].to_numpy(),
                             "bid2": g[-2].to_numpy(), "ask2": g[2].to_numpy(),
                             "bid5": g[-5].to_numpy(), "ask5": g[5].to_numpy()}).groupby("m").last() / 1e6
        snap = snap.reindex(idx).ffill(limit=2)
        for c in snap.columns:
            out[c] = snap[c]
        stats_.update({"snapshots": n0, "drop_V1": int((~ok).sum()), "drop_V2": int((~mono).sum()),
                       "drop_V3": int((~price_ok).sum()), "drop_V4": int((~not_stale).sum()),
                       "minute_coverage": float(out["bid1"].notna().mean())})
    else:
        stats_.update({"snapshots": 0, "minute_coverage": 0.0})
    stats_["depth_day_ok"] = stats_["minute_coverage"] >= 0.80                                          # V5
    # ---- open interest (metrics, 5-min) ----
    raw = fetch("metrics", date)
    out["oi"] = np.nan
    if raw is not None:
        mt = read_zip_csv(raw)
        tcol = "create_time" if "create_time" in mt.columns else mt.columns[0]
        mm = ((to_utc_seconds(mt[tcol]) - t0) // 60).clip(0, 1439)
        oi = pd.Series(pd.to_numeric(mt["sum_open_interest_value"], errors="coerce").to_numpy() / 1e6, index=mm)
        out["oi"] = oi.groupby(level=0).last().reindex(idx).ffill().bfill()
    # ---- liquidations (until 2024-03-31) ----
    out["liq_long"] = np.nan; out["liq_short"] = np.nan
    if need_liq:
        raw = fetch("liquidationSnapshot", date)
        if raw is not None:
            lq = read_zip_csv(raw)
            tcol = "time" if "time" in lq.columns else lq.columns[0]
            px = pd.to_numeric(lq.get("average_price", lq.get("price")), errors="coerce")
            qty = pd.to_numeric(lq.get("accumulated_fill_quantity", lq.get("original_quantity")), errors="coerce")
            notional = (px * qty).fillna(0) / 1e6
            lm = ((to_utc_seconds(lq[tcol]) - t0) // 60).clip(0, 1439)
            side = lq["side"].astype(str).str.upper()
            out["liq_long"] = pd.Series(np.where(side == "SELL", notional, 0.0), index=lm).groupby(level=0).sum().reindex(idx).fillna(0)
            out["liq_short"] = pd.Series(np.where(side == "BUY", notional, 0.0), index=lm).groupby(level=0).sum().reindex(idx).fillna(0)
    out["date"] = date
    return out, stats_

MIN_DIR = os.path.join(FUTDATA, "minute"); os.makedirs(MIN_DIR, exist_ok=True)

def get_day(date):
    pq, js = os.path.join(MIN_DIR, f"{date}.parquet"), os.path.join(MIN_DIR, f"{date}.json")
    if os.path.exists(pq) and os.path.exists(js):
        return pd.read_parquet(pq), json.load(open(js))
    liq_last = COVERAGE.get("liquidationSnapshot", (None, None))[1]
    df, st = build_minute_day(date, need_liq=bool(liq_last and date <= liq_last))
    if df is not None:
        df.to_parquet(pq)
    json.dump(_clean(st), open(js, "w"))
    return df, st

dep_first, dep_last = COVERAGE["bookDepth"]
assert dep_first, "bookDepth not found on data.binance.vision — see D1 output"
ALL_DATES = pd.date_range(dep_first, dep_last, freq="D").strftime("%Y-%m-%d").tolist()[::DAY_STEP]
for d in EVENT_DAYS.values():          # always include the event days
    if dep_first <= d <= dep_last and d not in ALL_DATES:
        ALL_DATES.append(d)
ALL_DATES = sorted(ALL_DATES)
print(f"building {len(ALL_DATES)} days from {ALL_DATES[0]} to {ALL_DATES[-1]} (cached days are skipped)")

DAYS, VSTATS = {}, []
with ThreadPoolExecutor(max_workers=8) as ex:
    futs = {ex.submit(get_day, d): d for d in ALL_DATES}
    for i, f in enumerate(as_completed(futs), 1):
        d = futs[f]
        try:
            df, st = f.result()
            VSTATS.append(st)
            if df is not None:
                DAYS[d] = df
        except Exception as e:
            VSTATS.append({"date": d, "reason": f"error: {e}"})
        if i % 50 == 0:
            print(f"   {i}/{len(ALL_DATES)} days")
vst = pd.DataFrame(VSTATS).sort_values("date")
if "depth_day_ok" not in vst:
    vst["depth_day_ok"] = False
vst["depth_day_ok"] = vst["depth_day_ok"].fillna(False).astype(bool)
errs = vst[vst.get("reason", pd.Series(index=vst.index, dtype=object)).astype(str).str.startswith("error")] if "reason" in vst else vst.iloc[:0]
if len(errs):
    print(f"!! {len(errs)} days failed with errors, e.g.:", errs["reason"].iloc[0])
ok_days = sorted(vst.loc[vst["depth_day_ok"], "date"])
print(f"days built: {len(DAYS)}; days passing depth validation: {len(ok_days)}")
pd.DataFrame(DL_LOG).to_csv(os.path.join(RESULTS, "futures_manifest_sha256.csv"), index=False)
vsum = {k: int(vst[k].fillna(0).sum()) for k in ["snapshots", "drop_V1", "drop_V2", "drop_V3", "drop_V4"] if k in vst}
record("D2_depth_validation", None, "audit",
       {"days_requested": len(ALL_DATES), "days_built": len(DAYS), "days_valid_depth": len(ok_days),
        "snapshot_drops": vsum,
        "failed_days": vst.loc[~vst["depth_day_ok"], "date"].tolist()[:200], "n_error_days": int(len(errs))},
       note="Report these counts in the data section. V3 drops show where Binance's depth archive is misaligned.")
