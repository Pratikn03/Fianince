# ============================================================================
# CELL D9 — EVENT STUDIES (SVB 2023, Aug 2024, Apr 2025, Oct 2025 where data exist)
# For each event day: hourly C3_hat, MAE_60, OI drop; percentile of C3_hat in the hours before
# the worst hour, relative to all training blocks. Descriptive; the Oct 2025 and Apr 2025
# events are in the held-out period.
# ============================================================================
trC = blocks.loc[blocks["split"] == "train", "C3_hat"].dropna().to_numpy()
evres = {}
for name, d in EVENT_DAYS.items():
    b = blocks[blocks["date"] == d].sort_values("hour")
    if b.empty:
        evres[name] = "no valid depth data for this day"
        continue
    worst = int(b.loc[b["MAE_60"].idxmax(), "hour"])
    before = b[(b["hour"] < worst) & (b["hour"] >= worst - 3)]
    evres[name] = {"date": d, "worst_hour_utc": worst, "worst_MAE_60_bp": float(b["MAE_60"].max()),
                   "C3_hat_by_hour": dict(zip(b["hour"].astype(int), b["C3_hat"].round(4))),
                   "C3_percentile_3h_before_worst": [float(stats.percentileofscore(trC, v)) for v in before["C3_hat"].dropna()],
                   "OI_drop_worst_hour_pct": float(b.loc[b["hour"] == worst, "OI_drop_60"].iloc[0])}
print(json.dumps(_clean(evres), indent=1)[:3000])
record("D9_event_studies", None, "real-data", evres,
       note="Support for T6 = C3_hat in a high percentile in the hours before the worst hour, across events.")

# ============================================================================
# CELL D10 — SUMMARY AND DOWNLOAD (Part 2)
# ============================================================================
rows = []
for fp in sorted(glob.glob(os.path.join(RESULTS, "D*.json"))):
    r = json.load(open(fp)); rows.append({"test": r["test_id"], "status": r["status"], "kind": r["kind"]})
print(pd.DataFrame(rows).to_string(index=False))
zp = os.path.join(BASE, "depth_results.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "D*.json")) + glob.glob(os.path.join(RESULTS, "futures_manifest_sha256.csv")) \
              + glob.glob(os.path.join(PREREG, "*depth*")):
        z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp)
if IN_COLAB:
    from google.colab import files
    files.download(zp)
