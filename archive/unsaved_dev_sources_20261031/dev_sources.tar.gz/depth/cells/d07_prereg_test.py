# ============================================================================
# CELL D7 — PRE-REGISTRATION OF THE HELD-OUT DEPTH TEST (run BEFORE D8; commit the file to GitHub)
# ============================================================================
PREREG_DEPTH = {
    "question": "Does the T6 amplification statistic C3_hat, estimated from the previous 6 hours of "
                "futures depth, flow and price, predict the next hour's maximum adverse excursion beyond controls?",
    "data": "Binance USD-M BTCUSDT daily klines(1m), bookDepth, metrics; validation rules V1-V5 of cell D2",
    "unit": "hourly blocks, hours 6-23 UTC; features from minutes [t-360, t); outcomes from (t, t+60]",
    "primary_outcome": "MAE_60 (bp)", "secondary_outcomes": ["OI_drop_60", "depth_collapse_60"],
    "controls": ["rv_60", "rv_360", "abs_ret_60", "flow_imb_60", "log_vol_60", "log_depth1", "imbalance", "oi_chg_60"],
    "candidate": "C3_hat winsorized at train 1%/99%", "secondary_candidate": "peak_ratio_hat (same winsorizing)",
    "train": f"days <= {TRAIN_END}", "test": f"days >= {TEST_START}",
    "model": "OLS; tail = outcome above train 90th percentile; score = fitted value",
    "inference": "Clark-West (Newey-West 6 lags, blocks in time order); day-block bootstrap 2,000 for ΔR², ΔAUC",
    "success": "primary: Clark-West one-sided p < 0.05 AND bootstrap 95% CI of ΔR² excludes 0",
    "multiple_testing": "secondary outcomes/candidate reported with Holm-adjusted p-values",
}
spec_txt = json.dumps(PREREG_DEPTH, indent=2, sort_keys=True)
DEPTH_HASH = hashlib.sha256(spec_txt.encode()).hexdigest()
pd_path = os.path.join(PREREG, "P2_depth.json")
if not os.path.exists(pd_path):
    open(pd_path, "w").write(spec_txt); print("pre-registration written:", pd_path)
elif hashlib.sha256(open(pd_path).read().encode()).hexdigest() != DEPTH_HASH:
    print("!! WARNING: spec differs from the registered file. Disclose any change made after seeing results.")
print("spec SHA-256:", DEPTH_HASH)

# ============================================================================
# CELL D8 — HELD-OUT TEST ON 2025-2026 (gate G2-depth). Every evaluation is counted.
# ============================================================================
CTRL_D = PREREG_DEPTH["controls"]
trD = blocks[blocks["split"] == "train"].copy(); teD = blocks[blocks["split"] == "test"].copy()
for cand in ["C3_hat", "peak_ratio_hat"]:
    lo, hi_ = trD[cand].quantile([0.01, 0.99])
    trD[cand + "_w"] = trD[cand].clip(lo, hi_); teD[cand + "_w"] = teD[cand].clip(lo, hi_)

def unlock_depth():
    pth = os.path.join(PREREG, "test_set_unlocks_depth.json")
    n = json.load(open(pth))["n"] + 1 if os.path.exists(pth) else 1
    json.dump({"n": n, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": DEPTH_HASH}, open(pth, "w"))
    return n

def ols_fit_pred(cols, A, B, y):
    Xa = np.column_stack([np.ones(len(A)), A[cols].to_numpy()])
    b = np.linalg.lstsq(Xa, A[y].to_numpy(), rcond=None)[0]
    return np.column_stack([np.ones(len(B)), B[cols].to_numpy()]) @ b

def auc_(y, s):
    pos, neg = s[y == 1], s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return np.nan
    rk = stats.rankdata(np.concatenate([pos, neg]))
    return (rk[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))

def cw_test(y, fs, fb, lags=6):
    adj = (y - fs) ** 2 - ((y - fb) ** 2 - (fs - fb) ** 2)
    m = adj.mean(); e = adj - m; n = len(adj)
    lrv = e @ e / n + 2 * sum((1 - l / (lags + 1)) * (e[l:] @ e[:-l]) / n for l in range(1, lags + 1))
    t_ = m / np.sqrt(lrv / n)
    return float(t_), float(1 - stats.norm.cdf(t_))

def eval_depth(outcome, cand):
    cols_all = CTRL_D + [cand, outcome]
    A = trD.dropna(subset=cols_all); B = teD.dropna(subset=cols_all).sort_values(["date", "hour"])
    y = B[outcome].to_numpy()
    fb = ols_fit_pred(CTRL_D, A, B, outcome); ff = ols_fit_pred(CTRL_D + [cand], A, B, outcome)
    sst = np.sum((y - A[outcome].mean()) ** 2)
    r2b, r2f = 1 - np.sum((y - fb) ** 2) / sst, 1 - np.sum((y - ff) ** 2) / sst
    t_, p_ = cw_test(y, fb, ff)
    tail = (y > A[outcome].quantile(0.9)).astype(int)
    Rb = rng(88); dd = B["date"].to_numpy(); ud_ = np.unique(dd); dR2, dA = [], []
    for _ in range(2000):
        pick = Rb.choice(ud_, len(ud_)); idx = np.concatenate([np.where(dd == d)[0] for d in pick])
        s_ = np.sum((y[idx] - A[outcome].mean()) ** 2)
        dR2.append((np.sum((y[idx] - fb[idx]) ** 2) - np.sum((y[idx] - ff[idx]) ** 2)) / s_)
        dA.append(auc_(tail[idx], ff[idx]) - auc_(tail[idx], fb[idx]))
    return {"n_train": len(A), "n_test": len(B), "r2_base": r2b, "r2_full": r2f, "delta_r2": r2f - r2b,
            "delta_r2_ci": [float(np.nanquantile(dR2, .025)), float(np.nanquantile(dR2, .975))],
            "auc_base": auc_(tail, fb), "auc_full": auc_(tail, ff),
            "delta_auc_ci": [float(np.nanquantile(dA, .025)), float(np.nanquantile(dA, .975))],
            "clark_west_t": t_, "clark_west_p": p_}

assert os.path.exists(pd_path), "run D7 first"
n_unl = unlock_depth()
primary = eval_depth("MAE_60", "C3_hat_w")
secondary = {f"{o}|{c}": eval_depth(o, c) for o in ["MAE_60", "OI_drop_60", "depth_collapse_60"]
             for c in ["C3_hat_w", "peak_ratio_hat_w"] if not (o == "MAE_60" and c == "C3_hat_w")}
ps = sorted([(v["clark_west_p"], k) for k, v in secondary.items()])
holm = {k: min(1.0, p * (len(ps) - i)) for i, (p, k) in enumerate(ps)}
for k in secondary:
    secondary[k]["holm_p"] = holm[k]
print(json.dumps(_clean(primary), indent=1))
print(pd.DataFrame(secondary).T[["delta_r2", "clark_west_p", "holm_p"]].round(5).to_string())
g2d = primary["clark_west_p"] < 0.05 and primary["delta_r2_ci"][0] > 0
record("D8_depth_test_G2", bool(g2d), "real-data",
       {"primary": primary, "secondary": secondary, "prereg_sha256": DEPTH_HASH, "test_set_unlocks": n_unl},
       criterion=PREREG_DEPTH["success"],
       note="Held-out 2025-2026. Report whatever it shows; test_set_unlocks > 1 must be disclosed.")

# Volatility flag vs T6 flag on the test set (each flags 10% of train blocks)
A = trD.dropna(subset=["C3_hat_w", "rv_60", "MAE_60"]); B = teD.dropna(subset=["C3_hat_w", "rv_60", "MAE_60"])
tail = (B["MAE_60"] > A["MAE_60"].quantile(0.9)).to_numpy()
fw = (B["C3_hat_w"] > A["C3_hat_w"].quantile(0.9)).to_numpy(); fv = (B["rv_60"] > A["rv_60"].quantile(0.9)).to_numpy()
def pr_(f):
    tp = np.sum(f & tail); return {"flag_rate": f.mean(), "precision": tp / max(f.sum(), 1), "recall": tp / max(tail.sum(), 1)}
record("D8b_flag_comparison", None, "real-data", {"T6_flag": pr_(fw), "vol_flag": pr_(fv), "either": pr_(fw | fv),
       "n_tail_events": int(tail.sum())}, note="Does the T6 flag catch tail hours that a volatility flag misses?")
