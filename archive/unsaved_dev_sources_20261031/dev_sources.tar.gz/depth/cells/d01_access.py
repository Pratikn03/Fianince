# ============================================================================
# CELL D1 — DATA ACCESS AND INVENTORY (what actually exists on data.binance.vision)
# Datasets (USD-M futures, daily files):
#   klines 1m      price + signed taker flow
#   bookDepth      cumulative depth/notional at ±1..5% bands, ~30 s snapshots (undocumented format)
#   metrics        open interest (5-min)
#   liquidationSnapshot   forced orders (published only until 2024-03-31)
# This cell probes availability and finds the first/last date of each dataset.
# ============================================================================
ROOT_URL = "https://data.binance.vision/data/futures/um/daily"
def ds_url(ds, date, sym=SYMBOL):
    if ds == "klines":
        return f"{ROOT_URL}/klines/{sym}/1m/{sym}-1m-{date}.zip"
    return f"{ROOT_URL}/{ds}/{sym}/{sym}-{ds}-{date}.zip"

def _http(url, method="GET", timeout=60, tries=3):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, method=method, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, (r.read() if method == "GET" else b"")
        except urllib.error.HTTPError as e:
            if e.code in (403, 404):
                return e.code, b""
            last = e
        except Exception as e:
            last = e
        time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"network error {url}: {last}")

def exists(ds, date):
    return _http(ds_url(ds, date), "HEAD", timeout=20)[0] == 200

def first_last_date(ds, anchors, lo="2019-09-01", hi=None):
    """First/last available daily file, by binary search on each side of a date known to exist.
    Assumes coverage is contiguous around the anchor (gaps are handled day by day later)."""
    hi = hi or time.strftime("%Y-%m-%d", time.gmtime(time.time() - 2 * 86400))
    anchor = next((d for d in anchors if exists(ds, d)), None)
    if anchor is None:
        return None, None
    left = pd.date_range(lo, anchor, freq="D").strftime("%Y-%m-%d").tolist()
    a, b = 0, len(left) - 1                  # first day that exists (left side: F..F T..T)
    while a < b:
        m = (a + b) // 2
        if exists(ds, left[m]):
            b = m
        else:
            a = m + 1
    right = pd.date_range(anchor, hi, freq="D").strftime("%Y-%m-%d").tolist()
    c, e = 0, len(right) - 1                 # last day that exists (right side: T..T F..F)
    while c < e:
        m = (c + e + 1) // 2
        if exists(ds, right[m]):
            c = m
        else:
            e = m - 1
    return left[a], right[c]

PROBE_DATES = ["2021-05-19", "2022-11-08", "2023-01-15", "2023-03-11", "2023-06-01", "2024-03-15",
               "2024-04-15", "2024-08-05", "2025-04-07", "2025-05-10", "2025-10-10", "2026-06-01"]
DATASETS = ["klines", "bookDepth", "metrics", "liquidationSnapshot"]
inv = pd.DataFrame({ds: [exists(ds, d) for d in PROBE_DATES] for ds in DATASETS}, index=PROBE_DATES)
print(inv.replace({True: "yes", False: "-"}).to_string())

COVERAGE = {ds: first_last_date(ds, [d for d in PROBE_DATES if inv.loc[d, ds]]) for ds in DATASETS}
for ds, (a, b) in COVERAGE.items():
    print(f"{ds:20s} first {a}  last {b}")
record("D1_inventory", None, "audit", {"probe": inv.astype(int).to_dict(), "coverage": COVERAGE},
       note="Coverage found by binary search; gaps inside a range are handled day by day later.")
