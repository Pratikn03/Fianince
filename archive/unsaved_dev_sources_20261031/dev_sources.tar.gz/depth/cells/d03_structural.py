# ============================================================================
# CELL D3 — ESTIMATE THE T6 MODEL ON REAL DEPTH DATA (training days only)
# 1-minute bars.  p = log price (bp), u = signed taker flow ($1M),
# d = (bid1 - ask1)/(bid1 + ask1) = depth imbalance within 1% of mid (unit-free),
# x = p - EMA_60min(p).
#   price:    Δp_t = c + κ u_t + φ d_{t-1} - (1-a) x_{t-1} + e     (Δp on the left: no EMA mechanics)
#   depth:    d_t  = c + (1-r) d_{t-1} + ε u_t + e
#   momentum: u_t  = c + (1-η) u_{t-1} + ηq x_{t-1} + e
# T6 conditions (bp per $1M):  C2 = φε - (1-a)κ ;  C3 = φε + κ²ηq - (1-a)κ.   Amplification <=> C > 0.
# Also the implied impulse response: peak ratio max_k h_k / h_0 and peak minute.
# These are reduced-form estimates (u_t is contemporaneous); label them so in the paper.
# ============================================================================
def prep(df):
    p = np.log(df["close"].to_numpy()) * 1e4
    u = df["flow"].to_numpy()
    tot = (df["bid1"] + df["ask1"]).to_numpy()
    d = ((df["bid1"] - df["ask1"]) / (df["bid1"] + df["ask1"])).to_numpy()
    x = p - pd.Series(p).ewm(span=60, adjust=False).mean().to_numpy()
    return p, u, d, x, tot

def ols(y, X):
    ok = np.all(np.isfinite(X), 1) & np.isfinite(y)
    if ok.sum() < X.shape[1] + 20:
        return None
    X1 = np.column_stack([np.ones(ok.sum()), X[ok]])
    return np.linalg.lstsq(X1, y[ok], rcond=None)[0][1:]

def fit_t6(p, u, d, x):
    dp = np.diff(p, prepend=np.nan)
    bp = ols(dp[1:], np.column_stack([u[1:], d[:-1], x[:-1]]))
    bd = ols(d[1:], np.column_stack([d[:-1], u[1:]]))
    bm = ols(u[1:], np.column_stack([u[:-1], x[:-1]]))
    if bp is None or bd is None or bm is None:
        return None
    kappa, phi, a = bp[0], bp[1], 1 + bp[2]
    rho_d, eps = bd[0], bd[1]
    eta = 1 - bm[0]
    q = bm[1] / eta if abs(eta) > 1e-6 else np.nan
    C2 = phi * eps - (1 - a) * kappa
    C3 = phi * eps + kappa ** 2 * eta * q - (1 - a) * kappa
    h = impulse_t6(a, phi, kappa, 1 - rho_d, eps, eta, q)
    ok = np.all(np.isfinite(h)) and abs(h[0]) > 1e-12
    return {"kappa": kappa, "phi": phi, "a": a, "r": 1 - rho_d, "eps": eps, "eta": eta, "q": q,
            "C2": C2, "C3": C3,
            "peak_ratio": float(np.max(h) / h[0]) if ok else np.nan,
            "peak_minute": int(np.argmax(h)) if ok else -1}

def impulse_t6(a, phi, kappa, r, eps, eta, q, L=120):
    x = np.zeros(L); dd = np.zeros(L); f = np.zeros(L)
    for t in range(L):
        if t > 0:
            f[t] = (1 - eta) * f[t - 1] + eta * q * x[t - 1]
        tot = (1.0 if t == 0 else 0.0) + f[t]
        x[t] = (a * x[t - 1] + phi * dd[t - 1] if t else 0) + kappa * tot
        dd[t] = ((1 - r) * dd[t - 1] if t else 0) + eps * tot
        if abs(x[t]) > 1e9:
            return np.full(L, np.nan)
    return x

train_days = [d for d in ok_days if d <= TRAIN_END]
rows = []
for d in train_days:
    p, u, dd_, x, tot = prep(DAYS[d])
    est = fit_t6(p, u, dd_, x)
    if est:
        est.update({"date": d, "rv": float(np.nanstd(np.diff(p))), "depth1_musd": float(np.nanmedian(tot))})
        rows.append(est)
d3 = pd.DataFrame(rows)
hi = d3["rv"] >= d3["rv"].quantile(0.9)
R3 = rng(33)
summ = {}
for lab, sub in [("all_train_days", d3), ("high_vol_days(top10%)", d3[hi]), ("other_days", d3[~hi])]:
    summ[lab] = {"n_days": len(sub),
                 **{f"median_{k}": float(sub[k].median()) for k in ["kappa", "phi", "a", "r", "eps", "eta", "q", "C2", "C3", "peak_ratio"]},
                 "mean_C3": float(sub["C3"].mean()), "mean_C3_ci": boot_ci(sub["C3"], R3),
                 "share_C3_pos": float((sub["C3"] > 0).mean()), "share_C2_pos": float((sub["C2"] > 0).mean()),
                 "median_peak_minute": float(sub["peak_minute"].median())}
ev = {k: d3.loc[d3["date"] == v].drop(columns=["date"]).to_dict("records") for k, v in EVENT_DAYS.items()
      if (d3["date"] == v).any()}
print(pd.DataFrame(summ).T.round(4).to_string())
print("event days:", json.dumps(_clean(ev))[:800])
record("D3_T6_structural_train", None, "real-data", {"summary": summ, "event_days": ev, "n_days": len(d3)},
       note="C3 > 0 means the estimated market sits in T6's amplification region. Compare high-vol days with others.")
