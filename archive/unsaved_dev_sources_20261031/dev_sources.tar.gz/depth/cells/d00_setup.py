# ============================================================================
# CELL D0 — SETUP (self-contained; run first)
# Part 2 of the test suite: order-book depth, open interest and liquidations
# from Binance USD-M futures public archives. Writes to the same results/ folder
# as Part 1 when USE_DRIVE = True (recommended: these downloads take a while).
# ============================================================================
import os, sys, json, time, math, glob, re, io, zipfile, hashlib, subprocess, warnings, itertools
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed

IN_COLAB = "google.colab" in sys.modules
for _p, _m in [("pyarrow", "pyarrow")]:
    try:
        __import__(_m)
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", _p], check=True)

import numpy as np
import pandas as pd
from scipy import stats, linalg
warnings.filterwarnings("ignore", category=RuntimeWarning)

USE_DRIVE = True
if IN_COLAB and USE_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = "/content/drive/MyDrive/ceiling_suite"
elif IN_COLAB:
    BASE = "/content/ceiling_suite"
else:
    BASE = os.path.abspath("ceiling_suite_local")
RESULTS, PREREG = os.path.join(BASE, "results"), os.path.join(BASE, "prereg")
FUTDATA = os.path.join(BASE, "data_futures")
for _d in (RESULTS, PREREG, FUTDATA):
    os.makedirs(_d, exist_ok=True)

SEED = 20261018
def rng(offset=0):
    return np.random.default_rng(SEED + offset)

def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o

def record(test_id, passed, kind, metrics, criterion="", note=""):
    assert kind in {"theorem-check", "simulation", "real-data", "audit"}, kind
    status = "REPORT" if passed is None else ("PASS" if passed else "FAIL")
    out = {"test_id": test_id, "status": status, "kind": kind, "criterion": criterion, "note": note,
           "metrics": _clean(metrics), "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "seed": SEED}
    with open(os.path.join(RESULTS, f"{test_id}.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(f"[{status}] {test_id} ({kind})" + (f" — {criterion}" if criterion else ""))
    if note:
        print("        note:", note)
    return out

def boot_ci(v, R, B=2000, stat=np.mean):
    v = np.asarray(v, float); v = v[np.isfinite(v)]
    if len(v) < 3:
        return [np.nan, np.nan]
    bs = [stat(v[R.integers(0, len(v), len(v))]) for _ in range(B)]
    return [float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))]

# ---- Sample design (fixed BEFORE looking at any futures data) --------------
SYMBOL = "BTCUSDT"
TRAIN_END = "2024-12-31"        # exploration + estimation allowed on dates <= this
TEST_START = "2025-01-01"       # untouched: evaluated once, after pre-registration (cell D8)
DAY_STEP = 1                    # 1 = every day; 2 = every other day (halves download time)
EVENT_DAYS = {"SVB2023": "2023-03-11", "Aug2024": "2024-08-05",
              "Apr2025": "2025-04-07", "Oct2025": "2025-10-10"}
print("BASE =", BASE)
