# ============================================================================
# CELL D5 — HOURLY BLOCKS: causal features and future outcomes
# For each day and hour t = 6..23 (minute 60h): features use minutes [t-360, t) only.
#   candidate (primary):  C3_hat from the rolling 6-hour T6 estimate (winsorized at train 1%/99%)
#   candidate (secondary): peak_ratio_hat
#   controls: rv_60, rv_360, abs_ret_60, flow_imb_60, log_vol_60, log_depth1, imbalance, oi_chg_60
#   outcomes over (t, t+60]: MAE_60 (bp), OI_drop_60 (%), depth_collapse_60 (%), liq_60 ($M, until 2024-03)
# ============================================================================
def block_features(df, t):
    p, u, dd_, x, tot = prep(df)
    w = slice(t - 360, t); h = slice(t - 60, t)
    est = fit_t6(p[w], u[w], dd_[w], x[w])
    r60 = np.diff(p[h]); r360 = np.diff(p[w])
    oi = df["oi"].to_numpy()
    return {"C3_hat": est["C3"] if est else np.nan,
            "peak_ratio_hat": est["peak_ratio"] if est else np.nan,
            "rv_60": np.nanstd(r60), "rv_360": np.nanstd(r360),
            "abs_ret_60": abs(p[t - 1] - p[t - 60]),
            "flow_imb_60": np.nansum(u[h]) / (np.nansum(np.abs(u[h])) + 1e-12),
            "log_vol_60": np.log1p(np.nansum(df["vol"].to_numpy()[h])),
            "log_depth1": np.log(tot[t - 1]) if np.isfinite(tot[t - 1]) and tot[t - 1] > 0 else np.nan,
            "imbalance": dd_[t - 1],
            "oi_chg_60": (oi[t - 1] / oi[t - 60] - 1) * 100 if np.isfinite(oi[t - 60]) and oi[t - 60] > 0 else np.nan}

def block_outcomes(df, t):
    p, u, dd_, x, tot = prep(df)
    f = slice(t, min(t + 61, len(p)))
    oi = df["oi"].to_numpy(); liq = (df["liq_long"] + df["liq_short"]).to_numpy()
    return {"MAE_60": float(np.nanmax(np.abs(p[f] - p[t - 1]))),
            "OI_drop_60": float((oi[t - 1] - np.nanmin(oi[f])) / oi[t - 1] * 100) if oi[t - 1] > 0 else np.nan,
            "depth_collapse_60": float((1 - np.nanmin(tot[f]) / tot[t - 1]) * 100) if tot[t - 1] > 0 else np.nan,
            "liq_60": float(np.nansum(liq[t:t + 60])) if np.isfinite(liq[t:t + 60]).any() else np.nan}

BLK_PATH = os.path.join(FUTDATA, f"blocks_step{DAY_STEP}.parquet")
if os.path.exists(BLK_PATH) and set(pd.read_parquet(BLK_PATH)["date"]) >= set(ok_days):
    blocks = pd.read_parquet(BLK_PATH)
else:
    rows = []
    for i, d in enumerate(ok_days):
        df = DAYS[d]
        for hr in range(6, 24):
            t = hr * 60
            if t + 1 >= 1440:
                continue
            r_ = block_features(df, t); r_.update(block_outcomes(df, t)); r_.update({"date": d, "hour": hr})
            rows.append(r_)
        if (i + 1) % 100 == 0:
            print(f"   blocks: {i+1}/{len(ok_days)} days")
    blocks = pd.DataFrame(rows)
    blocks.to_parquet(BLK_PATH)
blocks["split"] = np.where(blocks["date"] <= TRAIN_END, "train", np.where(blocks["date"] >= TEST_START, "test", "gap"))
print(blocks.groupby("split").size().to_dict())

# leakage test: scramble everything from t on, features must not change
Rl = rng(55); fails = 0
for _ in range(30):
    d = Rl.choice(ok_days); t = int(Rl.integers(6, 23)) * 60
    a_ = block_features(DAYS[d], t)
    df2 = DAYS[d].copy()
    for c in ["close", "flow", "vol", "bid1", "ask1", "oi"]:
        v = df2[c].to_numpy().copy(); v[t:] = v[t:][::-1] * 1.7; df2[c] = v
    b_ = block_features(df2, t)
    fails += any((np.isfinite(a_[k]) or np.isfinite(b_[k])) and not np.isclose(a_[k], b_[k], equal_nan=True) for k in a_)
record("D5_no_lookahead", fails == 0, "audit", {"trials": 30, "failures": fails},
       criterion="hourly features unchanged when all data from t onward are scrambled")
