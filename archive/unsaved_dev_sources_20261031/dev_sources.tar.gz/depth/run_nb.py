import json, os, time, traceback
os.chdir('/home/claude/depth')
nb = json.load(open('Depth_Liquidation_Tests.ipynb')); g = {'__name__': '__main__'}
for i, c in enumerate(nb['cells']):
    if c['cell_type'] != 'code': continue
    src = ''.join(c['source'])
    if 'CELL D1 ' in src: src = src.replace("def _http(", "def _http_real(")
    print('### cell', i, src.split('\n')[1][:60], flush=True)
    try: exec(compile(src, f'c{i}', 'exec'), g)
    except Exception: traceback.print_exc(); break
    if 'CELL D0 ' in src: exec(open('debug_fake_binance.py').read(), g)
