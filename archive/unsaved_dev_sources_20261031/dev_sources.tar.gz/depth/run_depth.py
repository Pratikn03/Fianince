import os, sys, time, traceback, glob
os.chdir('/home/claude/depth')
g = {'__name__': '__main__'}
cells = sorted(glob.glob('/home/claude/depth/cells/d*.py'))
for c in cells:
    src = open(c).read()
    if 'd01_access' in c:
        src = src.replace("def _http(", "def _http_real(")
    print('\n####', os.path.basename(c), flush=True); t = time.time()
    try:
        exec(compile(src, c, 'exec'), g)
    except Exception:
        traceback.print_exc(); break
    print(f'-- {time.time()-t:.1f}s', flush=True)
    if 'd00_setup' in c:
        exec(open('/home/claude/depth/debug_fake_binance.py').read(), g)
