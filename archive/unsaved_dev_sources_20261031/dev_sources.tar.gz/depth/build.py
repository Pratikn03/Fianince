import json, re, os
C = "/home/claude/depth/cells"
order = [
 ("md", """# Part 2 — Depth, Open Interest and Liquidation Tests (Binance USD-M futures)
This notebook tests **T6 on the data it is actually about**: order-book depth. Part 1 used spot klines (price and trades only), which cannot see depth.

**What it does**
1. **D1** finds which futures archives exist (klines, `bookDepth`, open interest, liquidations) and their date ranges.
2. **D2** downloads every day, checks each file against Binance's published checksum, and cleans the depth data with fixed rules V1–V5. Binance's depth archive has known bad periods, such as misaligned prices in Apr–May 2025 and partial days.
3. **D3–D6** use **training days only (≤ 2024-12-31)**: they estimate the T6 model, test whether the price overshoot is carried by depth, and relate T6 to liquidations.
4. **D7** writes a **new pre-registration** before the 2025–2026 data are evaluated.
5. **D8** runs the **held-out test on 2025–2026**. That period has never been looked at; every evaluation is counted.
6. **D9** covers the event days, including Apr 2025 and Oct 2025.

**Before running:** keep `USE_DRIVE = True` (cell D0). The first run downloads about 4 years of daily files (roughly 30–90 min); later runs use the cache. `DAY_STEP = 2` halves the time.

**Rules:** do not change D7's spec after running D8. If you must, disclose it; the unlock counter records every evaluation. Whatever D8 shows goes in the paper."""),
 "d00_setup.py", "d01_access.py", "d02_build.py",
 ("md", "## Training-period analysis (≤ 2024-12-31): exploration and estimation are allowed here"),
 "d03_structural.py", "d04_mediation.py", "d05_blocks.py", "d06_liquidations.py",
 ("md", "## Held-out test (2025–2026): pre-register first, then evaluate once"),
 "d07_prereg_test.py", "d09_events.py",
 ("md", """## How to read the results
| Test | Supports T6 if | If not |
|---|---|---|
| D3 | C3 > 0 on most days, larger on high-volatility days | the estimated market is outside the amplification region; T6 stays theory |
| D4 | overshoot CI > 0 in (B) and much smaller in (C) | the overshoot is not carried by depth |
| D6 | C3 coefficient on liquidations > 0, CI above 0 (in-sample) | no link to forced selling |
| **D8** | Clark–West p < 0.05 and ΔR² CI > 0 on 2025–26 | report the null; T6 does not forecast at hourly horizon |
| D9 | C3 in a high percentile before the worst hours | events do not show the signature |

Send me `depth_results.zip` when it finishes."""),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"},
      "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/depth/Depth_Liquidation_Tests.ipynb", "w"), indent=1)
print(len(cells), "cells")
