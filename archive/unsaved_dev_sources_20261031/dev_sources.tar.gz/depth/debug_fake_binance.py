# LOCAL DEBUG ONLY — format-faithful fake of data.binance.vision futures archives.
# Never part of the notebook. Lets the sandbox exercise parsing, validation and analysis.
import io as _io, zipfile as _zf, hashlib as _hl
_COV = {"klines": ("2019-09-08", "2026-10-15"), "bookDepth": ("2023-01-01", "2026-10-15"),
        "metrics": ("2021-12-01", "2026-10-15"), "liquidationSnapshot": ("2021-01-01", "2024-03-31")}
_CACHE = {}

def _zip(name, text):
    b = _io.BytesIO()
    with _zf.ZipFile(b, "w") as z:
        z.writestr(name, text)
    return b.getvalue()

def _day_sim(date):
    rr = np.random.default_rng(abs(hash(date)) % 2**32)
    n = 1440
    stress = 3.0 if date in EVENT_DAYS.values() else 1.0
    phi, eps, r, kap, a = 4.0, 0.08, 0.15, 1.2, 0.97
    x = np.zeros(n); d = np.zeros(n); u = np.zeros(n); p = np.zeros(n)
    for t in range(1, n):
        u[t] = 0.3 * u[t - 1] + rr.normal(0, 1.5 * stress)
        d[t] = (1 - r) * d[t - 1] + eps * u[t] + rr.normal(0, 0.03)
        d[t] = np.clip(d[t], -0.9, 0.9)
        dp = kap * u[t] + phi * d[t - 1] - (1 - a) * x[t - 1] + rr.normal(0, 3 * stress)
        p[t] = p[t - 1] + dp
        x[t] = p[t] - (0.967 * (p[t - 1] - x[t - 1]) + 0.033 * p[t])
    price = 30000 * np.exp(p / 1e4)
    return price, u, d

def _gen(ds, date):
    key = (ds, date)
    if key in _CACHE:
        return _CACHE[key]
    price, u, d = _day_sim(date)
    t0 = int(pd.Timestamp(f"{date}", tz="UTC").timestamp())
    if ds == "klines":
        vq = np.abs(u) * 1e6 + 5e6
        tbq = (vq + u * 1e6) / 2
        lines = ["open_time,open,high,low,close,volume,close_time,quote_volume,count,taker_buy_volume,taker_buy_quote_volume,ignore"]
        for m in range(1440):
            lines.append(f"{(t0+60*m)*1000},{price[m]:.1f},{price[m]*1.0005:.1f},{price[m]*0.9995:.1f},{price[m]:.1f},"
                         f"{vq[m]/price[m]:.3f},{(t0+60*m+59)*1000+999},{vq[m]:.2f},100,{tbq[m]/price[m]:.3f},{tbq[m]:.2f},0")
        txt = "\n".join(lines)
    elif ds == "bookDepth":
        bands = [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5] if date < "2025-06-01" else [-5, -2, -1, 1, 2, 5]
        bad = "2025-04-21" <= date <= "2025-05-19"
        lines = ["timestamp,percentage,depth,notional"]
        for s in range(0, 86400, 30):
            m = s // 60
            base = 60e6
            bid1 = base * (1 + d[m]); ask1 = base * (1 - d[m])
            ts = pd.Timestamp(t0 + s, unit="s").strftime("%Y-%m-%d %H:%M:%S")
            for b in bands:
                side = bid1 if b < 0 else ask1
                notional = side * abs(b) ** 0.8
                px = price[m] * (1 - 0.003 * b) * (0.82 if bad else 1.0)
                lines.append(f"{ts},{b},{notional/px:.3f},{notional:.4f}")
        txt = "\n".join(lines)
    elif ds == "metrics":
        lines = ["create_time,symbol,sum_open_interest,sum_open_interest_value,count_toptrader_long_short_ratio,"
                 "sum_toptrader_long_short_ratio,count_long_short_ratio,sum_taker_long_short_vol_ratio"]
        oi = 8e9 * np.exp(np.cumsum(np.random.default_rng(1).normal(0, 0.001, 288)))
        for k in range(288):
            ts = pd.Timestamp(t0 + 300 * k, unit="s").strftime("%Y-%m-%d %H:%M:%S")
            lines.append(f"{ts},BTCUSDT,{oi[k]/price[k*5]:.3f},{oi[k]:.2f},1.1,1.2,1.3,1.0")
        txt = "\n".join(lines)
    elif ds == "liquidationSnapshot":
        lines = ["time,side,order_type,time_in_force,original_quantity,price,average_price,order_status,last_fill_quantity,accumulated_fill_quantity"]
        rr = np.random.default_rng(7)
        for m in range(1440):
            for _ in range(rr.poisson(0.5 + max(0, -d[m]) * 5)):
                q = rr.exponential(0.5)
                lines.append(f"{(t0+60*m+rr.integers(0,60))*1000},{rr.choice(['SELL','BUY'])},LIMIT,IOC,{q:.3f},"
                             f"{price[m]:.1f},{price[m]:.1f},FILLED,{q:.3f},{q:.3f}")
        txt = "\n".join(lines)
    raw = _zip(f"BTCUSDT-{ds}-{date}.csv", txt)
    _CACHE[key] = raw
    return raw

def _http(url, method="GET", timeout=60, tries=3):
    m = re.search(r"/daily/(\w+)/BTCUSDT/(?:1m/)?BTCUSDT-(?:1m|\w+)-(\d{4}-\d{2}-\d{2})\.zip(\.CHECKSUM)?$", url)
    if not m:
        return 404, b""
    ds, date, chk = m.group(1), m.group(2), m.group(3)
    lo, hi = _COV[ds]
    if not (lo <= date <= hi) or date == "2024-06-15":          # one missing day inside the range
        return 404, b""
    if method == "HEAD":
        return 200, b""
    raw = _gen(ds, date)
    if chk:
        return 200, f"{_hl.sha256(raw).hexdigest()}  file.zip".encode()
    return 200, raw

DAY_STEP = 14     # local speed only
print("!! DEBUG: fake Binance futures archive injected (sandbox test only)")
