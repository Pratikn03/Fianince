# ============================================================================
# CELL E3 — W4/W6: WHICH SIMPLE RULE WORKS WHEN THE REGULATOR CANNOT SEE θ?
# States differ in fire-sale feedback θ (unobserved), from none up to near the cascade boundary.
# Every rule has ONE number, chosen to maximise average welfare across states.
#   Leverage rules (refill at market level):  static leverage cap ℓ̂ | volatility cap σ_x <= v̂ | wedge cap G <= Ḡ
#   Refill rules (leverage free):              fixed refill subsidy r̂ | wedge-targeted maker obligation
#                                              (market makers must refill enough that G <= Ḡ)
# Score: average welfare as a share of the state-by-state optimum (constrained for leverage rules,
# full planner for refill rules). Uses: with G increasing in ℓ̄ and a unique equilibrium, a leverage
# cap L gives equilibrium min(ℓ_eq, L) (checked in E2 W3).
# ============================================================================
def l2_on_grid(par, r, lgrid, L=1500):
    As = np.stack([system_matrix(par, lb, r)[0] for lb in lgrid]); s0 = system_matrix(par, lgrid[0], r)[1].astype(complex)
    w, V = np.linalg.eig(As); out = np.full(len(lgrid), np.inf); st = np.max(np.abs(w), 1) < 1
    if st.any():
        c = np.linalg.solve(V[st], np.broadcast_to(s0, (st.sum(), 3))[..., None])[..., 0]
        h = np.real(np.sum((w[st][:, None, :] ** np.arange(L)[None, :, None]) * (V[st][:, 0, :] * c)[:, None, :], 2))
        out[st] = np.sqrt((h ** 2).sum(1))
    return out

def theta_boundary(par, r):
    lo, hi = 0.0, 0.01
    for _ in range(60):
        m = (lo + hi) / 2
        lo, hi = (m, hi) if np.isfinite(gain(dict(par, theta=m), BASE_PAR["lmax"], r)) else (lo, m)
    return lo

FG = np.linspace(LGRID[0], BASE_PAR["lmax"], 800)
def run_rules(par_base, label):
    rM = r_market(par_base)
    tmax = theta_boundary(par_base, rM)
    thetas = np.linspace(0.0, 0.98 * tmax, 7)
    S_ = [dict(par_base, theta=t) for t in thetas]
    leq = np.array([eq_c(p, rM)[0] for p in S_])
    Wc = np.array([planner_c(p, rM)[1] for p in S_])
    Gg = [np.array([gain(p, l, rM) for l in FG]) for p in S_]
    Vg = [l2_on_grid(p, rM, FG) for p in S_]
    def W_at(caps):
        return np.array([welfare(p, min(le, cp), rM) for p, le, cp in zip(S_, leq, caps)])
    def cap_from(arr, v):
        ok = FG[arr <= v]; return float(ok.max()) if len(ok) else FG[0]
    best = {}
    best["no_rule"] = W_at([BASE_PAR["lmax"]] * len(S_))
    cands = {"static_leverage_cap": (FG[::8], lambda i, v: v),
             "volatility_cap": (np.unique(np.concatenate([v[np.isfinite(v)] for v in Vg]))[::10], lambda i, v: cap_from(Vg[i], v)),
             "wedge_cap": (np.unique(np.concatenate([g[np.isfinite(g)] for g in Gg]))[::10], lambda i, v: cap_from(Gg[i], v))}
    chosen = {}
    for name, (vals, fn) in cands.items():
        top = (-np.inf, None, None)
        for v in vals:
            Ws = W_at([fn(i, v) for i in range(len(S_))])
            if Ws.mean() > top[0]:
                top = (Ws.mean(), v, Ws)
        best[name] = top[2]; chosen[name] = top[1]
    lev = {k: float(np.mean(v) / np.mean(Wc)) for k, v in best.items()}
    # refill rules vs full planner
    Wf = np.array([full_planner_c(p)["W"] for p in S_])
    def W_refill(rs):
        return np.array([welfare(p, eq_c(p, r_)[0], r_) for p, r_ in zip(S_, rs)])
    sub_best = max(((W_refill([r_] * len(S_)).mean(), r_) for r_ in RGRID[::3]), key=lambda t: t[0])
    def r_for_wedge(p, Gbar):
        for r_ in RGRID:
            if r_ >= rM and gain(p, eq_c(p, r_)[0], r_) <= Gbar:
                return r_
        return RGRID[-1]
    gvals = np.quantile(np.concatenate([g[np.isfinite(g)] for g in Gg]), np.linspace(0.02, 0.6, 12))
    obl_best = max(((W_refill([r_for_wedge(p, gb) for p in S_]).mean(), gb) for gb in gvals), key=lambda t: t[0])
    ref = {"no_rule": float(np.mean(W_refill([rM] * len(S_))) / np.mean(Wf)),
           "fixed_refill_subsidy": float(sub_best[0] / np.mean(Wf)),
           "wedge_targeted_obligation": float(obl_best[0] / np.mean(Wf))}
    out = {"regime": label, "thetas": thetas, "leverage_rules_share_of_constrained_optimum": lev,
           "refill_rules_share_of_full_optimum": ref,
           "chosen": {**chosen, "refill_subsidy_r": sub_best[1], "obligation_Gbar": obl_best[1]}}
    print(json.dumps(_clean(out), indent=1))
    return out

res_base = run_rules(par0, "calibrated")
res_stress = run_rules(dict(par0, S=60.0, lam=9.0), "high-stress (large shocks, costly liquidations)")
lev_ok = all(r["leverage_rules_share_of_constrained_optimum"]["wedge_cap"] >=
             max(r["leverage_rules_share_of_constrained_optimum"]["static_leverage_cap"],
                 r["leverage_rules_share_of_constrained_optimum"]["volatility_cap"]) - 1e-9 for r in (res_base, res_stress))
ref_ok = all(r["refill_rules_share_of_full_optimum"]["wedge_targeted_obligation"] >=
             r["refill_rules_share_of_full_optimum"]["fixed_refill_subsidy"] - 1e-9 for r in (res_base, res_stress))
record("W4_leverage_rules", bool(lev_ok), "simulation", {"calibrated": res_base, "stress": res_stress},
       criterion="the one-number wedge cap does at least as well as the best static or volatility cap, in both regimes",
       note="If FAIL, report which rule wins; the policy claim must follow this result.")
record("W6_refill_rules", bool(ref_ok), "simulation", {"calibrated": res_base, "stress": res_stress},
       criterion="a wedge-targeted maker obligation does at least as well as the best fixed refill subsidy",
       note="Shares near 1 mean a simple rule gets close to the planner even though θ is unobserved.")
