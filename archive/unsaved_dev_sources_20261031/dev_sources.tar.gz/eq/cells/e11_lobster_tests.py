# ============================================================================
# CELL R2 — T6 ON NASDAQ ORDER BOOKS: structural estimate + depth mediation
# Bars of BAR_SEC seconds (10 s for one-day samples; 60 s works for multi-day data).
#   p = log mid (bp); u = signed executed dollar volume ($1M; executions of sell limit orders are
#   buyer-initiated, so sign = -direction); d = (B - A)/(B + A), B and A = dollar depth in the top 5 levels.
# Same estimators as Part 2 (D3 structural fit, D4 mediation), applied per stock-day.
# Inference: moving-block bootstrap over bars (blocks of 30 bars) within each stock-day.
# ============================================================================
BAR_SEC = 10
NLEV = 5

def load_lobster_bars(pair, bar=BAR_SEC):
    msg = pd.read_csv(pair["msg"], header=None).iloc[:, :6]
    msg.columns = ["time", "type", "oid", "size", "price", "dir"]
    ob = pd.read_csv(pair["ob"], header=None)
    nl = min(NLEV, ob.shape[1] // 4)
    askp = ob.iloc[:, [4 * i for i in range(nl)]].to_numpy() / 1e4
    asks = ob.iloc[:, [4 * i + 1 for i in range(nl)]].to_numpy()
    bidp = ob.iloc[:, [4 * i + 2 for i in range(nl)]].to_numpy() / 1e4
    bids = ob.iloc[:, [4 * i + 3 for i in range(nl)]].to_numpy()
    valid_a = (askp > 0) & (askp < 1e5); valid_b = (bidp > 0) & (bidp < 1e5)
    A = np.where(valid_a, askp * asks, 0).sum(1); B = np.where(valid_b, bidp * bids, 0).sum(1)
    mid = np.where(valid_a[:, 0] & valid_b[:, 0], (askp[:, 0] + bidp[:, 0]) / 2, np.nan)
    t = msg["time"].to_numpy()
    ex = msg["type"].isin([4, 5]).to_numpy()
    flow = np.where(ex, -msg["dir"].to_numpy() * msg["size"].to_numpy() * msg["price"].to_numpy() / 1e4, 0.0) / 1e6
    b = ((t - 34200) // bar).astype(int)
    keep = (b >= 0) & (t <= 57600)
    df = pd.DataFrame({"b": b[keep], "mid": mid[keep], "flow": flow[keep], "A": A[keep], "B": B[keep]})
    g = df.groupby("b").agg(mid=("mid", "last"), flow=("flow", "sum"), A=("A", "last"), B=("B", "last"))
    g = g.reindex(np.arange(int(23400 // bar))).ffill()
    g["flow"] = g["flow"].fillna(0.0)
    return g.dropna()

def prep_l(g, span_bars):
    p = np.log(g["mid"].to_numpy()) * 1e4
    u = g["flow"].to_numpy()
    d = ((g["B"] - g["A"]) / (g["B"] + g["A"])).to_numpy()
    x = p - pd.Series(p).ewm(span=span_bars, adjust=False).mean().to_numpy()
    return p, u, d, x

def ols1(y, X):
    ok = np.all(np.isfinite(X), 1) & np.isfinite(y)
    if ok.sum() < X.shape[1] + 20:
        return None
    return np.linalg.lstsq(np.column_stack([np.ones(ok.sum()), X[ok]]), y[ok], rcond=None)[0][1:]

def impulse3(a, phi, kap, r, eps, eta, q, L=200):
    A_, s0 = system_matrix({"a": a, "phi": phi, "kappa": kap, "eps": eps, "eta": eta, "q0": q, "theta": 0.0}, 0.0, r)
    h, s = [], s0.astype(float)
    for _ in range(L):
        h.append(s[0]); s = A_ @ s
        if abs(s[0]) > 1e9:
            return np.full(L, np.nan)
    return np.array(h)

def fit_t6_l(p, u, d, x):
    dp = np.diff(p, prepend=np.nan)
    bp = ols1(dp[1:], np.column_stack([u[1:], d[:-1], x[:-1]]))
    bd = ols1(d[1:], np.column_stack([d[:-1], u[1:]]))
    bm = ols1(u[1:], np.column_stack([u[:-1], x[:-1]]))
    if bp is None or bd is None or bm is None:
        return None
    kap, phi, a = bp[0], bp[1], 1 + bp[2]; r = 1 - bd[0]; eps = bd[1]; eta = 1 - bm[0]
    q = bm[1] / eta if abs(eta) > 1e-6 else np.nan
    h = impulse3(a, phi, kap, r, eps, eta, q)
    ok = np.all(np.isfinite(h)) and abs(h[0]) > 1e-12
    return {"kappa": kap, "phi": phi, "a": a, "r": r, "eps": eps, "eta": eta, "q": q,
            "C2": phi * eps - (1 - a) * kap, "C3": phi * eps + kap ** 2 * eta * q - (1 - a) * kap,
            "peak_ratio": float(np.max(h) / h[0]) if ok else np.nan, "peak_bar": int(np.argmax(h)) if ok else -1}

H_BARS = [0, 1, 2, 3, 6, 12, 18, 30]
def lp_l(p, u, d, nl=5):
    dp = np.diff(p, prepend=p[0]); n = len(p); t = np.arange(nl + 1, n - max(H_BARS) - 1)
    L = np.column_stack([dp[t - j] for j in range(1, nl + 1)] + [u[t - j] for j in range(1, nl + 1)] + [d[t - j] for j in range(1, nl + 1)])
    cu = np.concatenate([[0.0], np.cumsum(u)]); cd = np.concatenate([[0.0], np.cumsum(np.nan_to_num(d))])
    out = {"A": [], "B": [], "C": []}
    for k in H_BARS:
        y = p[t + k] - p[t - 1]
        XA = np.column_stack([u[t], L])
        XB = np.column_stack([XA, cu[t + k + 1] - cu[t + 1]]) if k else XA
        XC = np.column_stack([XB, cd[t + k] - cd[t]]) if k else XB
        for key, X in (("A", XA), ("B", XB), ("C", XC)):
            b_ = ols1(y, X); out[key].append(b_[0] if b_ is not None else np.nan)
    return {k: np.array(v) for k, v in out.items()}

def block_boot(fn, n, B=300, block=30, R=None):
    R = R or rng(77); nb = int(np.ceil(n / block)); outs = []
    for _ in range(B):
        starts = R.integers(0, n - block, nb)
        idx = np.concatenate([np.arange(s, s + block) for s in starts])[:n]
        outs.append(fn(np.sort(idx)))
    return outs

res_r = {}
for pair in PAIRS:
    g = load_lobster_bars(pair)
    if len(g) < 500:
        continue
    p, u, d, x = prep_l(g, span_bars=int(3600 / BAR_SEC))
    est = fit_t6_l(p, u, d, x)
    lp = lp_l(p, u, d)
    over = {k: float(np.nanmax(v[1:]) - v[0]) for k, v in lp.items()}
    # block bootstrap of C3 and of the (B) and (C) overshoots
    def stat(idx):
        e_ = fit_t6_l(p[idx], u[idx], d[idx], x[idx])
        return e_["C3"] if e_ else np.nan
    C3b = np.array(block_boot(stat, len(p)))
    key = f"{pair['ticker']}_{pair['date']}"
    res_r[key] = {"bars": len(g), "estimates": est, "C3_ci": [float(np.nanquantile(C3b, .025)), float(np.nanquantile(C3b, .975))],
                  "lp_beta_bp_per_musd": lp, "overshoot": over,
                  "mediation_share": (over["B"] - over["C"]) / over["B"] if over["B"] > 0 else np.nan}
    print(f"{key}: C3 = {est['C3']:.4f} CI {np.round(res_r[key]['C3_ci'], 4)}; peak ratio {est['peak_ratio']:.3f}; "
          f"overshoot (B) {over['B']:.3f} -> (C) {over['C']:.3f}")
if res_r:
    share_pos = float(np.mean([v["C3_ci"][0] > 0 for v in res_r.values()]))
    record("R2_T6_regulated_markets", None, "real-data", {"bar_seconds": BAR_SEC, "stock_days": res_r,
           "share_C3_CI_above_zero": share_pos},
           note="Regulated-market replication. With free samples this is a few stock-days: descriptive, not a test. "
                "With licensed multi-day data, report by stock with day-clustered CIs.")
else:
    print("No LOBSTER stock-days processed (see R1).")
