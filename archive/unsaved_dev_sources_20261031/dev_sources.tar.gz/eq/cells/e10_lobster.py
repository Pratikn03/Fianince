# ============================================================================
# CELL R1 — REGULATED-MARKET DATA (Nasdaq limit order books, LOBSTER format)
# Works with (a) LOBSTER's free sample files (a few stocks, one day) and (b) full LOBSTER data
# your university library may license (any number of stock-days). Put the .zip/.7z files in
#   /content  or  <BASE>/data_lobster
# Free samples: lobsterdata.com → Data Samples (download in your browser, then upload here).
# File pairs: TICKER_DATE_34200000_57600000_message_N.csv / ..._orderbook_N.csv (no header).
#   message:   time (s after midnight), type (1 submit, 2 partial cancel, 3 delete, 4 exec visible,
#              5 exec hidden, 7 halt), order id, size, price (×10000), direction (1 buy LO, -1 sell LO)
#   orderbook: per level: ask price, ask size, bid price, bid size (prices ×10000)
# ============================================================================
_pip_needed = []
try:
    import py7zr
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "py7zr"], check=False)
    try:
        import py7zr
    except ImportError:
        py7zr = None

def find_lobster_archives():
    pats = []
    for d in ["/content", LOBDIR, os.getcwd()]:
        pats += glob.glob(os.path.join(d, "*.zip")) + glob.glob(os.path.join(d, "*.7z"))
    return sorted({p for p in pats if re.search(r"(?i)lobster|_message_|orderbook|\d{4}-\d{2}-\d{2}", os.path.basename(p))})

def extract_all(paths):
    out = os.path.join(LOBDIR, "extracted"); os.makedirs(out, exist_ok=True)
    for p in paths:
        try:
            if p.endswith(".zip"):
                with zipfile.ZipFile(p) as z:
                    z.extractall(out)
            elif p.endswith(".7z") and py7zr is not None:
                with py7zr.SevenZipFile(p, "r") as z:
                    z.extractall(out)
        except Exception as e:
            print("  ! could not extract", p, e)
    pairs = []
    for m in glob.glob(os.path.join(out, "**", "*_message_*.csv"), recursive=True):
        ob = m.replace("_message_", "_orderbook_")
        if os.path.exists(ob):
            tk = re.match(r"([A-Z.]+)_(\d{4}-\d{2}-\d{2})", os.path.basename(m))
            pairs.append({"ticker": tk.group(1) if tk else "?", "date": tk.group(2) if tk else "?", "msg": m, "ob": ob})
    return sorted(pairs, key=lambda d: (d["ticker"], d["date"]))

ARCH = find_lobster_archives()
PAIRS = extract_all(ARCH)
print(f"archives found: {len(ARCH)}; stock-days found: {len(PAIRS)}")
for p_ in PAIRS[:20]:
    print("  ", p_["ticker"], p_["date"])
if not PAIRS:
    print("\nNo LOBSTER files yet. Download the free samples from lobsterdata.com (Data Samples page) "
          "or ask your library for LOBSTER/TAQ access, upload the zip files to /content, and re-run this cell.")
