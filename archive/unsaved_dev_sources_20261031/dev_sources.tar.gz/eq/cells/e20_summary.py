# ============================================================================
# CELL Z3 — SUMMARY AND DOWNLOAD (Part 3)
# ============================================================================
rows = []
for fp in sorted(glob.glob(os.path.join(RESULTS, "W*.json")) + glob.glob(os.path.join(RESULTS, "R2_*.json"))):
    r = json.load(open(fp)); rows.append({"test": r["test_id"], "status": r["status"], "kind": r["kind"],
                                          "criterion": r["criterion"][:90]})
pd.set_option("display.max_colwidth", 95)
print(pd.DataFrame(rows).to_string(index=False))
print("calibration source:", CAL_SOURCE)
zp = os.path.join(BASE, "equilibrium_results.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "W*.json")) + glob.glob(os.path.join(RESULTS, "R2_*.json")):
        z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp)
if IN_COLAB:
    from google.colab import files
    files.download(zp)
