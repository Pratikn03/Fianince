# ============================================================================
# CELL E2 — EQUILIBRIUM AND WELFARE CHECKS (W1–W3, W5) over 120 random parameter draws
#   W1 the competitive equilibrium is unique
#   W2 traders over-lever relative to the constrained planner when θ > 0 (fire-sale feedback),
#      and the gap vanishes when θ = 0
#   W3 a wedge limit at Ḡ* = G(ℓ_planner, r) implements the constrained planner's allocation
#   W5 market makers under-provide refill (r_eq < r_planner); a refill subsidy raises welfare
# Equilibria and optima are solved continuously (grid search, then root-finding / refinement).
# ============================================================================
def br_c(par, G, lcap=None):
    hi = BASE_PAR["lmax"] if lcap is None else min(BASE_PAR["lmax"], lcap)
    if hi <= LGRID[0]:
        return hi
    grid = np.linspace(LGRID[0], hi, 400)
    j = int(np.argmax(utility(par, grid, G)))
    lo_, hi_ = grid[max(j - 1, 0)], grid[min(j + 1, len(grid) - 1)]
    res = optimize.minimize_scalar(lambda l: -float(utility(par, l, G)), bounds=(lo_, hi_), method="bounded",
                                   options={"xatol": 1e-7})
    return float(res.x)

def eq_c(par, r, lcap=None):
    hi = BASE_PAR["lmax"] if lcap is None else min(BASE_PAR["lmax"], lcap)
    f = lambda lb: br_c(par, gain(par, lb, r), lcap) - lb
    xs = np.linspace(LGRID[0], hi, 120); fs = np.array([f(x) for x in xs])
    roots = []
    for i in range(len(xs) - 1):
        if np.sign(fs[i]) != np.sign(fs[i + 1]):
            try:
                roots.append(optimize.brentq(f, xs[i], xs[i + 1], xtol=1e-7))
            except ValueError:
                pass
    if fs[-1] >= 0:
        roots.append(hi)                            # corner: everyone at the cap
    merged = []
    for x in sorted(roots):
        if not merged or x - merged[-1] > 1e-3:
            merged.append(x)
    return merged

def planner_c(par, r):
    W = lambda l: -welfare(par, l, r)
    grid = np.linspace(LGRID[0], BASE_PAR["lmax"], 400)
    j = int(np.argmin([W(l) for l in grid]))
    res = optimize.minimize_scalar(W, bounds=(grid[max(j - 1, 0)], grid[min(j + 1, 399)]), method="bounded",
                                   options={"xatol": 1e-7})
    return float(res.x), -float(res.fun)

def full_planner_c(par):
    best = (-np.inf, None, None)
    for r in RGRID:
        l, w = planner_c(par, r)
        if w > best[0]:
            best = (w, l, r)
    return {"W": best[0], "l": best[1], "r": best[2]}

def draw(R):
    while True:
        p = dict(BASE_PAR, theta=R.uniform(0, 0.0005), S=R.uniform(40, 200), lam=R.uniform(2, 10),
                 mu=R.uniform(0.3, 1.0), gamma=R.uniform(0.01, 0.05), s=R.uniform(0.2, 1.5), c=R.uniform(2, 8))
        if 0.05 <= p["s"] / p["c"] <= 0.6 and np.isfinite(gain(p, 1.0, r_market(p))):
            return p

TOL = 1e-3
R2 = rng(200); rows = []
for i in range(120):
    p = draw(R2)
    if i < 20:
        p["theta"] = 0.0                           # control group: no fire-sale feedback
    r = r_market(p)
    eqs = eq_c(p, r); le = eqs[0] if eqs else np.nan
    lp, Wp = planner_c(p, r)
    Gstar = gain(p, lp, r)
    # leverage allowed by the wedge cap: largest ℓ with G(ℓ, r) <= Ḡ*  (fine grid + bisection)
    fine = np.linspace(LGRID[0], BASE_PAR["lmax"], 2000)
    okk = fine[np.array([gain(p, l, r) for l in fine]) <= Gstar + 1e-12]
    Lcap = float(okk.max()) if len(okk) else 0.0
    eqs_cap = eq_c(p, r, lcap=Lcap); lce = eqs_cap[0] if eqs_cap else np.nan
    fp = full_planner_c(p)
    eqs_sub = eq_c(p, fp["r"])
    rows.append({"theta": p["theta"], "n_equilibria": len(eqs), "l_eq": le, "l_planner": lp,
                 "W_eq": welfare(p, le, r), "W_planner_c": Wp, "l_cap_eq": lce, "W_cap": welfare(p, lce, r),
                 "r_eq": r, "r_planner": fp["r"], "W_planner_full": fp["W"],
                 "W_subsidy": welfare(p, eqs_sub[0], fp["r"]) if eqs_sub else np.nan})
E = pd.DataFrame(rows)
fb = E["theta"] > 0
gap = E["l_eq"] - E["l_planner"]
w1 = float((E["n_equilibria"] == 1).mean())
w2_over = float((gap[fb] > -TOL).mean()); w2_ctrl = float((gap[~fb].abs() < TOL).mean())
w3 = float((E["W_cap"] >= E["W_planner_c"] - 1e-6).mean())
w5_r = float((E["r_eq"] <= E["r_planner"] + 1e-9).mean())
w5_gain = float((E["W_subsidy"] >= E["W_eq"] - 1e-6).mean())
summary = {"W1_share_unique": w1, "W2_share_overlever_given_feedback": w2_over,
           "W2_share_no_gap_without_feedback": w2_ctrl, "W3_share_cap_reaches_planner": w3,
           "W5_share_refill_underprovided": w5_r, "W5_share_subsidy_improves": w5_gain,
           "median_leverage_gap_feedback": float(gap[fb].median()),
           "median_welfare_loss_leverage_externality": float((E["W_planner_c"] - E["W_eq"]).median()),
           "median_welfare_loss_vs_full_planner": float((E["W_planner_full"] - E["W_eq"]).median()),
           "median_refill_gap": float((E["r_planner"] - E["r_eq"]).median())}
print(json.dumps(_clean(summary), indent=1))
record("W1_unique_equilibrium", w1 >= 0.95, "simulation", {"share_unique": w1},
       criterion=">= 95% of draws have one competitive equilibrium")
record("W2_overleverage", w2_over >= 0.95 and w2_ctrl >= 0.95, "simulation",
       {"overlever_share": w2_over, "control_no_gap_share": w2_ctrl, "median_gap": summary["median_leverage_gap_feedback"]},
       criterion="ℓ_eq >= ℓ_planner when θ > 0 and ℓ_eq = ℓ_planner when θ = 0 (tol 1e-3), >= 95% of draws")
record("W3_wedge_cap_efficiency", w3 >= 0.95, "simulation", {"share": w3},
       criterion="a wedge cap at Ḡ* reaches the constrained planner's welfare in >= 95% of draws")
record("W5_refill_externality", w5_r >= 0.95 and w5_gain >= 0.95, "simulation",
       {"underprovision_share": w5_r, "subsidy_improves_share": w5_gain, "median_refill_gap": summary["median_refill_gap"]},
       criterion="r_eq <= r_planner and a refill subsidy raises welfare in >= 95% of draws")
record("W_summary", None, "simulation", {"summary": summary, "draws": E.to_dict("list")},
       note="Compare the two welfare losses: which externality (leverage or refill) is large in the calibrated model?")
