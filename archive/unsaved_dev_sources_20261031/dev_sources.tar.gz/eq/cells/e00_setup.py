# ============================================================================
# CELL E0 — SETUP (self-contained; run first)
# Part 3: (E) equilibrium and welfare model with optimizing agents, calibrated to the
# Part 2 depth estimates when available; (R) regulated-market replication on Nasdaq
# order-book data (LOBSTER). Writes to the same results/ folder as Parts 1-2.
# ============================================================================
import os, sys, json, time, glob, re, io, zipfile, subprocess, warnings, urllib.request
import numpy as np
import pandas as pd
from scipy import stats, optimize
warnings.filterwarnings("ignore", category=RuntimeWarning)

IN_COLAB = "google.colab" in sys.modules
USE_DRIVE = True
if IN_COLAB and USE_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = "/content/drive/MyDrive/ceiling_suite"
elif IN_COLAB:
    BASE = "/content/ceiling_suite"
else:
    BASE = os.path.abspath("ceiling_suite_local")
RESULTS = os.path.join(BASE, "results"); LOBDIR = os.path.join(BASE, "data_lobster")
for _d in (RESULTS, LOBDIR):
    os.makedirs(_d, exist_ok=True)

SEED = 20261018
def rng(o=0):
    return np.random.default_rng(SEED + o)

def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o

def record(test_id, passed, kind, metrics, criterion="", note=""):
    status = "REPORT" if passed is None else ("PASS" if passed else "FAIL")
    out = {"test_id": test_id, "status": status, "kind": kind, "criterion": criterion, "note": note,
           "metrics": _clean(metrics), "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "seed": SEED}
    json.dump(out, open(os.path.join(RESULTS, f"{test_id}.json"), "w"), indent=2)
    print(f"[{status}] {test_id} ({kind})" + (f" — {criterion}" if criterion else ""))
    if note:
        print("        note:", note)
print("BASE =", BASE)
