# ============================================================================
# CELL E1 — THE EQUILIBRIUM MODEL (stylized; every result below is a numerical check, not a proof)
#
# Market (T6 book with momentum, 1-minute steps):
#   x_t = a x_{t-1} + φ d_{t-1} + κ (u_t + f_t)            price displacement (bp)
#   d_t = (1 - r) d_{t-1} + ε (u_t + f_t)                  depth imbalance; r = refill rate
#   f_t = (1 - η) f_{t-1} + η q x_{t-1}                    forced / momentum flow
# Fire-sale feedback: forced flow grows with aggregate leverage,  q = q0 + θ · ℓ̄.
# Transient gain G(ℓ̄, r) = max_k h_k  (peak price response to a $1M flow shock, bp; ∞ if unstable).
#
# Leveraged traders (continuum, price-takers): choose leverage ℓ to maximise
#   U(ℓ) = μ ℓ - (γ/2) ℓ² - λ ℓ · P(ℓ, G),   P(ℓ, G) = 2 Φ( -(10⁴/ℓ) / (S · G) )
#   (liquidated if the stress move S·G bp exceeds the 1/ℓ margin; λ = deadweight loss per liquidation).
#   Each trader takes G as given, so it ignores that its leverage raises q and hence G for everyone.
# Market makers (competitive): choose refill r to maximise s·r - (c/2) r²  ->  r_eq = s / c,
#   ignoring that refill lowers G and so lowers everyone's liquidation losses.
# Planner: maximise W(ℓ, r) = μℓ - γℓ²/2 - λℓ P(ℓ, G(ℓ, r)) + s r - c r²/2.
# Wedge limit: the regulator caps system gain at Ḡ through the maximum leverage it allows,
#   L(Ḡ, r) = max{ℓ : G(ℓ, r) <= Ḡ}.
# ============================================================================
DEFAULT_CAL = {"a": 0.97, "phi": 4.0, "kappa": 1.2, "r": 0.15, "eps": 0.08, "eta": 0.7}
CAL_SOURCE = "defaults (Part 2 D3 results not found)"
_d3 = os.path.join(RESULTS, "D3_T6_structural_train.json")
if os.path.exists(_d3):
    s_ = json.load(open(_d3))["metrics"]["summary"]["all_train_days"]
    cand = {k: s_.get(f"median_{k}") for k in DEFAULT_CAL}
    if all(v is not None and np.isfinite(v) for v in cand.values()) and 0 < cand["a"] < 1 \
            and 0 < cand["r"] < 1 and 0 < cand["eta"] < 1:
        DEFAULT_CAL = cand; CAL_SOURCE = "Part 2 D3 medians (real Binance depth data)"
print("calibration:", CAL_SOURCE, {k: round(v, 4) for k, v in DEFAULT_CAL.items()})

BASE_PAR = dict(DEFAULT_CAL, q0=0.0005, theta=0.0002, mu=0.6, gamma=0.02, lam=6.0, S=100.0, s=1.0, c=4.0, lmax=50.0)
LGRID = np.linspace(0.5, BASE_PAR["lmax"], 300)
RGRID = np.linspace(0.02, 0.95, 40)

def system_matrix(par, lbar, r):
    """State s_t = (x_t, d_t, f_t); a flow shock u_0 = 1 gives s_0 = (κ, ε, 0)."""
    q = par["q0"] + par["theta"] * lbar
    a, phi, kap, eps, eta = par["a"], par["phi"], par["kappa"], par["eps"], par["eta"]
    A = np.array([[a + kap * eta * q, phi, kap * (1 - eta)],
                  [eps * eta * q, 1 - r, eps * (1 - eta)],
                  [eta * q, 0.0, 1 - eta]])
    return A, np.array([kap, eps, 0.0])

_GGRID = {}
def _pkey(par):
    return tuple(round(par[k], 12) for k in sorted(par))

def gains_on_grid(par, r, lgrid=None, L=1500):
    """G(ℓ̄, r) for every ℓ̄ in lgrid at once (batched eigen-decomposition)."""
    lgrid = LGRID if lgrid is None else np.asarray(lgrid, float)
    key = (_pkey(par), round(float(r), 9), len(lgrid), float(lgrid[0]), float(lgrid[-1]))
    if key in _GGRID:
        return _GGRID[key]
    As = np.stack([system_matrix(par, lb, r)[0] for lb in lgrid])
    s0 = system_matrix(par, lgrid[0], r)[1].astype(complex)
    w, V = np.linalg.eig(As)
    G = np.full(len(lgrid), np.inf)
    stable = np.max(np.abs(w), axis=1) < 1
    if stable.any():
        Vs, ws = V[stable], w[stable]
        c = np.linalg.solve(Vs, np.broadcast_to(s0, (len(ws), 3))[..., None])[..., 0]
        coef = Vs[:, 0, :] * c                                   # (n,3)
        k = np.arange(L)[None, :, None]
        h = np.real(np.sum((ws[:, None, :] ** k) * coef[:, None, :], axis=2))
        G[stable] = h.max(axis=1)
    _GGRID[key] = G
    return G

def gain(par, lbar, r):
    return float(gains_on_grid(par, r, [float(lbar)])[0])

def p_liq(par, l, G):
    l = np.asarray(l, float); G = np.asarray(G, float)
    with np.errstate(divide="ignore", invalid="ignore"):
        z = -(1e4 / l) / (par["S"] * G)
    return np.where(np.isfinite(G), 2 * stats.norm.cdf(z), 1.0)

def utility(par, l, G):
    l = np.asarray(l, float)
    return par["mu"] * l - 0.5 * par["gamma"] * l ** 2 - par["lam"] * l * p_liq(par, l, G)

def equilibria(par, r, lcap=None):
    """Fixed points ℓ̄ = BR(G(ℓ̄, r)) on the grid; BR restricted to ℓ <= lcap under a leverage cap."""
    Gg = gains_on_grid(par, r)
    jmax = len(LGRID) if lcap is None else int(np.searchsorted(LGRID, lcap + 1e-12, side="right"))
    if jmax == 0:
        return [0.0]
    grid = LGRID[:jmax]
    U = utility(par, grid[None, :], Gg[:jmax, None])          # rows: aggregate ℓ̄, cols: own ℓ
    br = grid[np.argmax(U, axis=1)]
    gap = br - grid
    fps = [float(grid[i]) for i in range(len(grid) - 1) if gap[i] == 0 or np.sign(gap[i]) != np.sign(gap[i + 1])]
    if gap[-1] >= 0:
        fps.append(float(grid[-1]))
    return sorted(set(np.round(fps, 6)))

def welfare(par, l, r):
    return float(utility(par, l, gain(par, l, r))) + par["s"] * r - 0.5 * par["c"] * r ** 2

def planner(par, r_fixed=None):
    best = (-np.inf, None, None)
    for r in ([r_fixed] if r_fixed is not None else RGRID):
        W = utility(par, LGRID, gains_on_grid(par, r)) + par["s"] * r - 0.5 * par["c"] * r ** 2
        i = int(np.argmax(W))
        if W[i] > best[0]:
            best = (float(W[i]), float(LGRID[i]), float(r))
    return {"W": best[0], "l": best[1], "r": best[2]}

def max_leverage_for_cap(par, Gbar, r):
    ok = LGRID[gains_on_grid(par, r) <= Gbar]
    return float(ok.max()) if len(ok) else 0.0

def r_market(par):
    return float(np.clip(par["s"] / par["c"], RGRID[0], RGRID[-1]))

par0 = dict(BASE_PAR)
r0 = r_market(par0)
eq0 = equilibria(par0, r0)
pl0 = planner(par0, r_fixed=r0); plf0 = planner(par0)
print(f"market refill r_eq = {r0:.3f}; competitive equilibria ℓ̄ = {eq0}")
print(f"constrained planner ℓ = {pl0['l']:.2f};  full planner ℓ = {plf0['l']:.2f}, r = {plf0['r']:.3f}")
