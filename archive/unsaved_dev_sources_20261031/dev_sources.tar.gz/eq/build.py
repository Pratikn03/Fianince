import json, re, os
C = "/home/claude/eq/cells"
order = [
 ("md", """# Part 3 — Equilibrium & Welfare Model + Regulated-Market Replication
These are the two pieces of the "9+" step that code can deliver. The other two pieces, a senior co-author and licensed regulated-market data at scale, have to come from people and institutions; see the last cell.

**E. Equilibrium and welfare (no data needed; about 20–30 min)**
- Leveraged traders choose leverage and market makers choose how fast to refill depth. Forced selling makes the market's momentum grow with total leverage (a fire-sale feedback).
- Each trader ignores how its leverage raises everyone's transient gain G, and each market maker ignores how its refill lowers G for everyone. These are two externalities.
- Checks: W1 the equilibrium is unique; W2 traders over-lever; W3 a wedge cap restores the constrained optimum; W5 refill is under-provided; W4/W6 which one-number rule works best when the regulator can't see the feedback strength.
- **Calibration:** if Part 2 has run (D3 results in Drive), the model uses your real Binance depth estimates; otherwise it uses defaults and says so.

**R. Regulated markets (Nasdaq, LOBSTER format)**
- Upload LOBSTER zip files to `/content`: the free samples from lobsterdata.com, or licensed data from your library.
- The same T6 estimate and depth-mediation test as Part 2 are run on stock order books.

**Labels:** every E result is a *numerical check of a stylized model*. It shows what to prove, not a proof. Every R result is *real data*. With free samples it is descriptive only (a few stock-days)."""),
 "e00_setup.py", "e01_model.py",
 ("md", "## E. Equilibrium checks"), "e02_checks.py", "e03_rules.py",
 ("md", "## R. Regulated-market replication (upload LOBSTER files first)"), "e10_lobster.py", "e11_lobster_tests.py",
 ("md", "## Summary"), "e20_summary.py",
 ("md", """## What turns these results into a top-journal paper (cannot be coded)
1. **Proofs.** W1–W6 are numerical. A paper needs theorems: existence and uniqueness, the over-leverage and under-refill inequalities from the first-order conditions, and the wedge cap implementing the constrained optimum. The planner's first-order condition has an extra term, −λℓ·∂P/∂G·∂G/∂ℓ̄, that the trader ignores. That term is the whole proof idea for W2.
2. **Licensed data at scale.** Ask the MNSU library, or a finance professor, about LOBSTER, TAQ or CME data. Free samples only show the pipeline works.
3. **A senior co-author** in market microstructure, who will check the model's assumptions and say what referees will attack. Email them once Part 2 and Part 3 results are in, with a one-page summary.
4. **A natural experiment.** A Binance or exchange rule change that shifted refill (tick size, maker rebates, margin tiers), tested before and after.

Send me `equilibrium_results.zip` and I will check it and draft the model section."""),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"},
      "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/eq/Equilibrium_Welfare_RegulatedMarkets.ipynb", "w"), indent=1)
print(len(cells), "cells")
