import os, time, shutil
W = '/home/claude/p10/run'; os.chdir(W); shutil.rmtree(os.path.join(W, 'ceiling_suite_local'), ignore_errors=True)
g = {'__name__': '__main__'}; C = '/home/claude/p10/cells/'
def run(name):
    t = time.time(); print('\n####', name, flush=True)
    exec(compile(open(C + name).read(), name, 'exec'), g); print(f'-- {time.time()-t:.1f}s', flush=True)
src = open(C + 't00_setup.py').read(); i = src.index('code, _ = _http(')
exec(compile(src[:i], 't00a', 'exec'), g); exec(open('/home/claude/p10/fake_tardis.py').read(), g); exec(compile(src[i:], 't00b', 'exec'), g)
g['COINS'] = ['ACH', 'API3', 'CELR', 'ZEN']
for c in ['t01_functions.py', 't02_prereg.py', 't03_build.py', 't04_blocks.py', 't05_test.py']:
    run(c)
