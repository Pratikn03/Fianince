import gzip as _gz, zlib as _zl
def _sim10(key, date):
    rr = np.random.default_rng(_zl.crc32(f"{key}{date}".encode())); n = 1440
    u = np.zeros(n); x = np.zeros(n); p = np.zeros(n); d = np.zeros(n)
    for t in range(1, n):
        u[t] = 0.3 * u[t-1] + 0.02 * x[t-1] + rr.normal(0, 1)
        d[t] = np.clip(0.9 * d[t-1] - 0.02 * u[t] + rr.normal(0, 0.05), -0.9, 0.9)
        p[t] = p[t-1] + 2 * u[t] + 3 * d[t-1] - 0.03 * x[t-1] + rr.normal(0, 3)
        x[t] = p[t] - (0.967 * (p[t-1] - x[t-1]) + 0.033 * p[t])
    return 0.5 * np.exp(p / 1e4), u, d
def _http(url, method="GET", timeout=60, tries=3):
    m = re.search(r"/v1/([a-z\-]+)/(trades|book_snapshot_25)/(\d{4})/(\d{2})/(\d{2})/([A-Z0-9\-]+)\.csv\.gz$", url)
    if not m:
        return 404, b""
    venue, dt, y, mo, dd, sym = m.groups(); date = f"{y}-{mo}-{dd}"
    if sym.startswith("ZEN"):
        return 404, b""
    px, u, d = _sim10(venue + sym, date); t0 = int(pd.Timestamp(date, tz="UTC").value // 1000)
    rr = np.random.default_rng(1)
    if dt == "trades":
        mm = np.repeat(np.arange(1440), 4); ts = t0 + mm * 60_000_000 + rr.integers(0, 59_000_000, len(mm))
        buy = rr.random(len(mm)) < 0.5 + 0.2 * np.tanh(u[mm])
        df = pd.DataFrame({"exchange": venue, "symbol": sym, "timestamp": ts, "local_timestamp": ts, "id": np.arange(len(mm)),
                           "side": np.where(buy, "buy", "sell"), "price": px[mm], "amount": rr.exponential(200, len(mm))})
    else:
        mm = np.repeat(np.arange(1440), 3); ts = t0 + mm * 60_000_000 + np.tile([0, 20_000_000, 40_000_000], 1440)
        cols = {"exchange": venue, "symbol": sym, "timestamp": ts, "local_timestamp": ts}
        for k in range(25):
            cols[f"asks[{k}].price"] = px[mm] * (1 + 0.0005 * (k + 1)); cols[f"asks[{k}].amount"] = 1000 * (1 - d[mm])
            cols[f"bids[{k}].price"] = px[mm] * (1 - 0.0005 * (k + 1)); cols[f"bids[{k}].amount"] = 1000 * (1 + d[mm])
        df = pd.DataFrame(cols)
    return 200, _gz.compress(df.to_csv(index=False).encode())
