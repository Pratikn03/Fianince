# ============================================================================
# CELL T4 — HOURLY BLOCKS (no outcome is looked at here)
# ============================================================================
assert SYMBOLS, "no venue-coin passed the inclusion rule; tell Claude"
BLK10 = os.path.join(TDIR, f"blocks_p10_{len(SYMBOLS)}.parquet")
if os.path.exists(BLK10) and set(map(tuple, pd.read_parquet(BLK10)[["symbol", "date"]].drop_duplicates().to_numpy())) >= set(OK):
    TB = pd.read_parquet(BLK10)
else:
    rows = []
    for i, (s, d) in enumerate(OK):
        rows += day_blocks9(s, d, FLOW_SCALE[s])
        if (i + 1) % 100 == 0:
            print(f"   blocks: {i+1}/{len(OK)}")
    TB = pd.DataFrame(rows); TB.to_parquet(BLK10)
TB["venue"] = TB["symbol"].str.split(":").str[0]
TB["split"] = np.where(TB["date"] <= TRAIN_END, "train", "test")
TB["kappa_sq"] = TB["kappa_hat"] ** 2
TB = winsor_train(TB, IMPACT + ["rv_15", "rv_day", "ewma_vol", "mae_lag60"])
print(TB.groupby(["venue", "split"]).size().unstack())
record("T3_blocks", None, "audit", {"blocks": TB.groupby(["venue", "split"]).size().unstack().to_dict(),
       "coverage": {c: float(TB[c].notna().mean()) for c in ["C3_hat", "S60", "log_depth1", "imbalance", "ewma_vol"]}})
