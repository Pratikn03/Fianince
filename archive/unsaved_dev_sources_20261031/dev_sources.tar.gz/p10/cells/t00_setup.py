# ============================================================================
# CELL T0 — SETUP (self-contained; run first)
# Part 10 (Paper 2): SECOND AND THIRD VENUES WITH REAL DEPTH. Free Tardis.dev datasets (the first day of every month is
# free without an API key): full top-25 order-book snapshots and trades for Bybit (USDT perpetuals) and OKX (swaps).
# The 1st of the month was never a test day in Parts 4-9. Same statistic, same baseline as Part 9.
# ============================================================================
import os, sys, json, time, math, glob, re, io, zipfile, hashlib, subprocess, warnings, zlib
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
import xml.etree.ElementTree as ET

IN_COLAB = "google.colab" in sys.modules
try:
    import pyarrow  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pyarrow"], check=True)
import numpy as np
import pandas as pd
from scipy import stats, optimize
warnings.filterwarnings("ignore", category=RuntimeWarning)

USE_DRIVE = True
if IN_COLAB and USE_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = "/content/drive/MyDrive/ceiling_suite"
elif IN_COLAB:
    BASE = "/content/ceiling_suite"
else:
    BASE = os.path.abspath("ceiling_suite_local")
RESULTS, PREREG = os.path.join(BASE, "results"), os.path.join(BASE, "prereg")
XDATA = os.path.join(BASE, "data_xsec")
for _d in (RESULTS, PREREG, XDATA):
    os.makedirs(_d, exist_ok=True)

SEED = 20261025
def rng(offset=0):
    return np.random.default_rng(SEED + offset)

def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o

def record(test_id, passed, kind, metrics, criterion="", note=""):
    assert kind in {"theorem-check", "simulation", "real-data", "audit"}, kind
    status = "REPORT" if passed is None else ("PASS" if passed else "FAIL")
    out = {"test_id": test_id, "status": status, "kind": kind, "criterion": criterion, "note": note,
           "metrics": _clean(metrics), "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "seed": SEED}
    with open(os.path.join(RESULTS, f"{test_id}.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(f"[{status}] {test_id} ({kind})" + (f" — {criterion}" if criterion else ""))
    if note:
        print("        note:", note)
    return out

def boot_ci(v, R, B=2000, stat=np.mean):
    v = np.asarray(v, float); v = v[np.isfinite(v)]
    if len(v) < 3:
        return [np.nan, np.nan]
    bs = [stat(v[R.integers(0, len(v), len(v))]) for _ in range(B)]
    return [float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))]

# ---- Design ------------------------------------------------------------------------------------
TARDIS = "https://datasets.tardis.dev/v1"
VENUES = {"bybit": lambda c: f"{c}USDT", "okex-swap": lambda c: f"{c}-USDT-SWAP"}
COINS = ["ACH", "ALICE", "API3", "ARPA", "CELR", "CHR", "CVX", "GTC", "HOT", "ICX", "IOST", "IOTX", "LIT", "OGN", "QNT",
         "RLC", "SPELL", "T", "WOO", "ZEN"]                      # the 20 Binance thin-set coins of Parts 6 and 9
TRAIN_D = [f"{y}-{m:02d}-01" for y in (2023, 2024) for m in range(1, 13)]
TEST_D = [f"{y}-{m:02d}-01" for y in (2025, 2026) for m in range(1, 13) if f"{y}-{m:02d}-01" <= "2026-10-01"]
TRAIN_END = "2024-12-31"
THREADS = 6
TDIR = os.path.join(BASE, "data_tardis"); os.makedirs(TDIR, exist_ok=True)
print("BASE =", BASE, "| train days", len(TRAIN_D), "| test days", len(TEST_D))
def _http(url, method="GET", timeout=120, tries=3):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, method=method, headers={"User-Agent": "Mozilla/5.0", "Accept-Encoding": "identity"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            if e.code in (400, 401, 403, 404):
                return e.code, b""
            last = e
        except Exception as e:
            last = e
        time.sleep(2 * (i + 1))
    raise RuntimeError(f"network error {url}: {last}")
code, _ = _http(f"{TARDIS}/bybit/trades/2024/06/01/ACHUSDT.csv.gz", timeout=120)
print("Tardis free datasets reachable:", code == 200, f"(HTTP {code})")
assert code == 200, "datasets.tardis.dev not reachable from this runtime; tell Claude."
DL_LOG = []
