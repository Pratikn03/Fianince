# ============================================================================
# CELL T2 — PRE-REGISTRATION (before any test day is downloaded; T3 refuses to run without it)
# E-mail prereg/P10_tardis.json to yourself before running T3.
# ============================================================================
CTRL10 = [c for c in CTRL if c != "oi_chg_60"]                 # Tardis free files carry no open interest
BASE10 = CTRL10 + IMPACT + VOLBENCH
PREREG_P10 = {
    "question": "Second and third venues with real depth: in thin coins on Bybit and OKX, does C3_hat forecast next-hour MAE "
                "beyond the Part 9 baseline (volatility forecasting, price impact, hour effects)?",
    "data": "Tardis.dev free datasets (first day of each month, no API key): trades and book_snapshot_25. Minute bars: mid of the "
            "last snapshot in each minute, signed taker notional, notional volume, bid/ask notional within 1% of mid. Day kept if "
            ">= 80% of minutes have a snapshot.",
    "venues": {"bybit": "<COIN>USDT linear perpetual", "okex-swap": "<COIN>-USDT-SWAP"},
    "coins": COINS, "train": TRAIN_D, "test": TEST_D,
    "inclusion": "a venue-coin enters if it has >= 18 valid training days and >= 16 valid test days",
    "unit": "symbol-hour blocks, hours 6-23 UTC; features from minutes before t on the same day; outcome MAE over (t, t+60]",
    "baseline": BASE10 + ["venue-coin fixed effects"],
    "primary": {"sample": "all included venue-coins, both venues pooled", "outcome": "MAE_60", "candidate": "C3_hat",
                "success": "Clark-West one-sided p < 0.05 AND 95% date-block bootstrap CI of dR2 above 0"},
    "secondary": ["bybit only: MAE | C3_hat", "okex-swap only: MAE | C3_hat", "pooled: MAE | S60", "pooled: MAE | C3_flow",
                  "pooled: MAE | term_reversion", "pooled: MAE | term_momentum", "pooled: MAE | gain_multiple"],
    "inference": "Clark-West (Newey-West 6 lags); 2,000 date-block bootstrap draws (all symbols on a date together); secondary Holm-adjusted",
    "runs": "T5 is run once; every run is counted in prereg/test_set_unlocks_p10.json",
    "previous_hashes": {"part6": "65acda36186147bd6e959ce8c56b9958b7a7f94a01f8784bc82f2b1512360215",
                        "part9": "71983f1a9d2ca23cafe5ce4de5d5d9ddb406529ceaf5aec57a7dee81a75f846d"},
}
spec_txt10 = json.dumps(PREREG_P10, indent=2, sort_keys=True)
P10_HASH = hashlib.sha256(spec_txt10.encode()).hexdigest()
p10_path = os.path.join(PREREG, "P10_tardis.json")
if not os.path.exists(p10_path):
    open(p10_path, "w").write(spec_txt10); print("pre-registration written:", p10_path)
elif hashlib.sha256(open(p10_path).read().encode()).hexdigest() != P10_HASH:
    raise RuntimeError("The spec differs from the registered file. Do not edit the spec after registering it.")
print("spec SHA-256:", P10_HASH)
if IN_COLAB:
    from google.colab import files
    files.download(p10_path)
print("Keep a dated copy of P10_tardis.json (e-mail it to yourself) BEFORE running T3.")
