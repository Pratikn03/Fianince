# ============================================================================
# CELL T3 — DOWNLOAD AND BUILD (cached in Drive; reruns skip finished days). Takes a while.
# ============================================================================
assert os.path.exists(p10_path) and hashlib.sha256(open(p10_path).read().encode()).hexdigest() == P10_HASH, "run T2 first"
jobs = [(v, c, d) for v in VENUES for c in COINS for d in TRAIN_D + TEST_D]
print(f"{len(jobs)} venue-coin-days")
PANEL, VST = {}, []
with ThreadPoolExecutor(THREADS) as ex:
    futs = {ex.submit(get_day_tardis, v, c, d): (v, c, d) for v, c, d in jobs}
    for i, f in enumerate(as_completed(futs), 1):
        v, c, d = futs[f]
        try:
            df, st = f.result(); VST.append(st)
            if df is not None and st.get("depth_day_ok"):
                PANEL[(f"{v}:{c}", d)] = df
        except Exception as e:
            VST.append({"symbol": f"{v}:{c}", "date": d, "reason": f"error: {e}"})
        if i % 100 == 0:
            print(f"   {i}/{len(jobs)}")
vst = pd.DataFrame(VST)
ntr = {k: sum(1 for (s, d) in PANEL if s == k and d <= TRAIN_END) for k in {s for s, _ in PANEL}}
nte = {k: sum(1 for (s, d) in PANEL if s == k and d > TRAIN_END) for k in {s for s, _ in PANEL}}
SYMBOLS = sorted(k for k in ntr if ntr[k] >= 18 and nte.get(k, 0) >= 16)
GROUP = {s: "thin" for s in SYMBOLS}
OK = sorted((s, d) for (s, d) in PANEL if s in SYMBOLS)
FLOW_SCALE = {}
for s in SYMBOLS:
    v = [np.nanmedian(np.abs(PANEL[(s, d)]["flow"].to_numpy())) for d in TRAIN_D if (s, d) in PANEL]
    v = [x for x in v if np.isfinite(x) and x > 0]
    FLOW_SCALE[s] = float(np.median(v)) if v else 1.0
print(f"included venue-coins: {len(SYMBOLS)}", SYMBOLS)
pd.DataFrame(DL_LOG).to_csv(os.path.join(RESULTS, "p10_manifest_sha256.csv"), index=False)
record("T2_build", None, "audit", {"requested": len(jobs), "valid": len(PANEL), "train_days": ntr, "test_days": nte,
       "included": SYMBOLS, "flow_scale": FLOW_SCALE})
