import zlib as _zl
def _http(url, method="GET", timeout=60, tries=3):
    m = re.search(r"/klines/([A-Z]+)/1s/[A-Z]+-1s-(\d{4}-\d{2}-\d{2})\.zip(\.CHECKSUM)?$", url)
    if not m:
        return 404, b""
    if m.group(3):
        return 404, b""
    s, date = m.group(1), m.group(2)
    rr = np.random.default_rng(_zl.crc32(f"{s}{date}".encode())); n = 86400
    btc = 1.0 if (s == "BTCUSDT" and (("2022-07-08" <= date < "2023-03-22"))) else 0.0
    f = np.zeros(n); e = rr.normal(0, 1, n)
    for t in range(1, n):
        f[t] = 0.3 * f[t - 1] + e[t]
    p = 100 * np.exp(np.cumsum(2e-5 * f + rr.normal(0, 1e-5, n)))
    qv = (np.abs(f) + 1) * 1e4 * (1.8 if btc else 1.0); tb = qv * (0.5 + 0.2 * np.tanh(f))
    t0 = int(pd.Timestamp(date, tz="UTC").timestamp() * 1000) * (1000 if date >= "2025-01-01" else 1)
    step = 1000 * (1000 if date >= "2025-01-01" else 1)
    df = pd.DataFrame({"a": t0 + step * np.arange(n), "o": p, "h": p, "l": p, "c": p, "v": qv / p, "ct": t0, "qv": qv, "n": 5,
                       "tbv": tb / p, "tbq": tb, "i": 0})
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr(f"{s}-1s-{date}.csv", df.to_csv(header=False, index=False))
    return 200, b.getvalue()
