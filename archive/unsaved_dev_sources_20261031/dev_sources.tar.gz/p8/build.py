import json, re, os
C = "/home/claude/p8/cells"
order = [
 ("md", """# Part 8 — Paper 1: re-running the old real-data tables from raw files
Several Paper 1 tables came from scripts of the earlier version that no longer exist, so the paper labels them "earlier scripts". This notebook rebuilds them from Binance's public 1-second spot klines, so every real-data number in Paper 1 becomes reproducible. It also adds:
- a **placebo pipeline** for every pair;
- a **second fee event**: BTC zero fees started on 2022-07-08 and ended on 2023-03-22, so the fee test now has an "on" and an "off" event.

No pre-registration is needed: these are re-runs of existing designs, not new hypotheses.

**Run all cells in order.** Expected time: about 1–2 hours, for about 1,400 daily 1-second files."""),
 "v00_setup.py", "v01_functions.py",
 ("md", "## The 96-date x 8-pair panel"), "v02_panel.py",
 ("md", "## Two fee events (this cell zips and downloads the results)"), "v03_fee.py",
 ("md", "Send me `p8_results.zip`."),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/outputs/Part8_Paper1_SpotPanel_FeeEvents.ipynb", "w"), indent=1)
print(len(cells), "cells")
