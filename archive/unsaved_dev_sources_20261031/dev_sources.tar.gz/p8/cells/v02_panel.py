# ============================================================================
# CELL V2 — THE 96-DATE x 8-PAIR SPOT PANEL (Tables "panel" and "assets" of Paper 1)
# ============================================================================
U = run_units([(s, d) for s in PAIRS for d in PANEL_D])
U = U[U["coverage"] >= 0.8]
print(f"units: {len(U)} of {len(PAIRS) * len(PANEL_D)}")
mech = 1 - 2 / (EMA_W / BAR + 1)
panel = {c: {"Q": date_mean_ci(U, f"{c}_Q"), "S": date_mean_ci(U, f"{c}_S"), "J11": date_mean_ci(U, f"{c}_J11")}
         for c in ["forward", "observed", "raw_return", "observed_q30", "placebo"]}
assets = U.groupby("symbol")[["forward_Q", "observed_Q", "observed_q30_Q", "observed_S", "placebo_Q"]].mean().to_dict("index")
rows = [{"construction": c, "Q": round(v["Q"]["mean"], 7), "Q_CI": np.round(v["Q"]["ci"], 7).tolist(), "S": round(v["S"]["mean"], 5),
         "J11": round(v["J11"]["mean"], 5), "share Q>0": round(v["Q"]["share_units_pos"], 3)} for c, v in panel.items()]
print(pd.DataFrame(rows).to_string(index=False)); print("mechanical persistence 29/31 =", round(mech, 5))
print(pd.DataFrame(assets).T.round(7).to_string())
record("V2_spot_panel", None, "real-data", {"panel": panel, "assets": assets, "n_units": len(U),
       "n_transitions": int(U["n_bars"].sum() - len(U)), "mechanical_J11": mech},
       note="Re-run of the earlier version's spot panel from raw 1-second klines; adds a placebo pipeline.")
