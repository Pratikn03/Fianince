# ============================================================================
# CELL V3 — FEE-SCHEDULE TEST WITH TWO EVENTS
# BTCUSDT spot fees went to zero on 2022-07-08 and came back on 2023-03-22. Seven other pairs are controls.
# Y_it = a_i + g_t + b * (BTC_i x ZeroFee_t) + e, separately for each event and pooled; date-clustered SEs.
# Outcomes: log quote volume (a first stage: fees should move volume) and observed-flow Q.
# ============================================================================
fee_jobs, ev_of = [], {}
for ev, d0 in FEE_EVENTS.items():
    for k_ in range(-FEE_WIN, FEE_WIN):
        d = (pd.Timestamp(d0) + pd.Timedelta(days=k_)).strftime("%Y-%m-%d")
        ev_of[d] = (ev, k_ >= 0); fee_jobs += [(s, d) for s in PAIRS]
FU = run_units(fee_jobs); FU = FU[FU["coverage"] >= 0.8].copy()
FU["event"] = FU["date"].map(lambda d: ev_of[d][0]); FU["post"] = FU["date"].map(lambda d: ev_of[d][1])
FU["btc"] = (FU["symbol"] == "BTCUSDT").astype(float)
FU["zero_fee"] = np.where(FU["event"] == "zero_fee_on", FU["post"], ~FU["post"]).astype(float) * FU["btc"]
FU["log_qv"] = np.log(FU["quote_volume_musd"])
def twfe(D, y):
    D = D.dropna(subset=[y]); X = pd.get_dummies(D[["symbol", "date"]], drop_first=True).astype(float)
    X.insert(0, "treat", D["zero_fee"].to_numpy()); X.insert(0, "const", 1.0)
    b, *_ = np.linalg.lstsq(X.to_numpy(), D[y].to_numpy(), rcond=None); e = D[y].to_numpy() - X.to_numpy() @ b
    Xm = X.to_numpy(); XtXi = np.linalg.pinv(Xm.T @ Xm); meat = np.zeros_like(XtXi)
    for _, idx in D.reset_index(drop=True).groupby("date").groups.items():
        s_ = Xm[idx].T @ e[idx]; meat += np.outer(s_, s_)
    G = D["date"].nunique(); V = XtXi @ meat @ XtXi * G / max(G - 1, 1); se = np.sqrt(V[1, 1])
    t_ = b[1] / se; p_ = 2 * (1 - stats.t.cdf(abs(t_), G - 1))
    return {"beta": float(b[1]), "se": float(se), "ci": [float(b[1] - stats.t.ppf(.975, G - 1) * se), float(b[1] + stats.t.ppf(.975, G - 1) * se)],
            "p": float(p_), "n": len(D), "dates": int(G)}
fee = {}
for ev in list(FEE_EVENTS) + ["pooled"]:
    D = FU if ev == "pooled" else FU[FU["event"] == ev]
    fee[ev] = {"log_quote_volume": twfe(D, "log_qv"), "observed_Q": twfe(D, "observed_Q")}
    print(ev, {k: {kk: round(vv, 5) if isinstance(vv, float) else vv for kk, vv in v.items()} for k, v in fee[ev].items()})
record("V3_fee_events", None, "real-data", {"by_event": fee, "window_days": FEE_WIN, "events": FEE_EVENTS},
       note="b = effect of zero fees on BTCUSDT relative to 7 control pairs; date-clustered. A volume effect "
            "with no Q effect says fees move activity but not measured feedback.")
zp8 = os.path.join(BASE, "p8_results.zip")
pd.DataFrame(DL_LOG).to_csv(os.path.join(RESULTS, "p8_manifest_sha256.csv"), index=False)
with zipfile.ZipFile(zp8, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "V*.json")) + [os.path.join(RESULTS, "p8_manifest_sha256.csv")]:
        z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp8)
if IN_COLAB:
    from google.colab import files
    files.download(zp8)
