# ============================================================================
# CELL V1 — FUNCTIONS
# ============================================================================
KCOLS = ["open_time", "open", "high", "low", "close", "volume", "close_time", "quote_volume", "count",
         "taker_buy_volume", "taker_buy_quote_volume", "ignore"]
def bars10(sym, date):
    """10-second bars from 1-second klines: last close (filled), signed taker quote flow, quote volume."""
    raw = fetch_1s(sym, date)
    if raw is None:
        return None
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        txt = z.read([n for n in z.namelist() if n.endswith(".csv")][0])
    k = pd.read_csv(io.BytesIO(txt), header=None, names=KCOLS)
    if not str(k.iloc[0, 0]).replace(".", "").isdigit():
        k = k.iloc[1:]
    t = pd.to_numeric(k["open_time"]).to_numpy(); t = np.where(t > 1e14, t // 1000, t)       # microseconds -> ms
    t0 = pd.Timestamp(date, tz="UTC").value // 10 ** 6
    b = ((t - t0) // (1000 * BAR)).astype(int); nb = 86400 // BAR; ok = (b >= 0) & (b < nb)
    qv = pd.to_numeric(k["quote_volume"]).to_numpy(); tb = pd.to_numeric(k["taker_buy_quote_volume"]).to_numpy()
    c = pd.to_numeric(k["close"]).to_numpy()
    D = pd.DataFrame({"b": b[ok], "c": c[ok], "f": (2 * tb - qv)[ok], "qv": qv[ok]})
    g = D.groupby("b"); idx = np.arange(nb)
    out = pd.DataFrame({"close": g["c"].last().reindex(idx).ffill().bfill(), "flow": g["f"].sum().reindex(idx).fillna(0.0),
                        "qv": g["qv"].sum().reindex(idx).fillna(0.0)})
    return out, float(g.size().reindex(idx).notna().mean())

def var_indices(X, F, extra=None):
    """VAR(1) of z_t = (X_t, F_t) on z_{t-1} (+ optional exogenous lags): Q, S, L and J."""
    Y = np.column_stack([X[1:], F[1:]]); R = [np.ones(len(Y)), X[:-1], F[:-1]]
    if extra is not None:
        R += [e[:-1] for e in extra]
    Z = np.column_stack(R); ok = np.all(np.isfinite(Y), 1) & np.all(np.isfinite(Z), 1)
    if ok.sum() < 500:
        return None
    B = np.linalg.lstsq(Z[ok], Y[ok], rcond=None)[0]; J = B[1:3].T
    if abs(1 - J[1, 1]) < 1e-9:
        return None
    Q = J[0, 1] * J[1, 0] / (1 - J[1, 1])
    return {"Q": float(Q), "S": float(J[0, 0] + Q), "J11": float(J[0, 0]), "J22": float(J[1, 1]),
            "L": float(Q / (1 - J[0, 0])) if abs(1 - J[0, 0]) > 1e-9 else np.nan}

def unit_stats(sym, date, seed=0):
    r = bars10(sym, date)
    if r is None:
        return None
    B, cover = r
    p = np.log(B["close"].to_numpy()); f = B["flow"].to_numpy() / 1e6
    al = 2 / (EMA_W / BAR + 1); m = pd.Series(p).ewm(alpha=al, adjust=False).mean().to_numpy(); x = p - m
    ret = np.r_[np.nan, np.diff(p)]
    f_next = np.r_[f[1:], np.nan]
    lags30 = [np.r_[np.full(j, np.nan), f[:-j]] for j in range(1, 31)]
    rr = np.random.default_rng(zlib.crc32(f"{sym}{date}{seed}".encode()))
    pl = np.cumsum(rr.normal(0, np.nanstd(np.diff(p)), len(p))); ml = pd.Series(pl).ewm(alpha=al, adjust=False).mean().to_numpy()
    out = {"symbol": sym, "date": date, "coverage": cover, "quote_volume_musd": float(B["qv"].sum() / 1e6), "n_bars": len(p)}
    for name, (X, F, ex) in {"forward": (x, f_next, None), "observed": (x, f, None), "raw_return": (ret, f, None),
                             "observed_q30": (x, f, lags30), "placebo": (pl - ml, f, None)}.items():
        v = var_indices(X, F, ex)
        for kk, vv in (v or {}).items():
            out[f"{name}_{kk}"] = vv
    return out

def date_mean_ci(U, col):
    """Equal-weight asset means within date, then the mean over dates with a Student t interval."""
    d = U.groupby("date")[col].mean().dropna(); n = len(d)
    if n < 3:
        return {"mean": np.nan, "ci": [np.nan, np.nan], "n_dates": n}
    se = d.std(ddof=1) / np.sqrt(n); t = stats.t.ppf(0.975, n - 1)
    return {"mean": float(d.mean()), "ci": [float(d.mean() - t * se), float(d.mean() + t * se)], "n_dates": n,
            "share_units_pos": float((U[col] > 0).mean())}
UNIT_DIR = os.path.join(SPOT_DIR, "units"); os.makedirs(UNIT_DIR, exist_ok=True)
def get_unit(sym, date):
    fp = os.path.join(UNIT_DIR, f"{sym}_{date}.json")
    if os.path.exists(fp):
        return json.load(open(fp))
    u = unit_stats(sym, date)
    json.dump(_clean(u) if u else {"symbol": sym, "date": date, "missing": True}, open(fp, "w"))
    return u
def run_units(jobs):
    rows = []
    with ThreadPoolExecutor(THREADS) as ex:
        futs = {ex.submit(get_unit, s, d): (s, d) for s, d in jobs}
        for i, f in enumerate(as_completed(futs), 1):
            try:
                u = f.result()
                if u and not u.get("missing"):
                    rows.append(u)
            except Exception as e:
                print("  !", futs[f], e)
            if i % 100 == 0:
                print(f"   {i}/{len(jobs)}")
    return pd.DataFrame(rows)
