import os, time, shutil
W = '/home/claude/p8/run'; os.makedirs(W, exist_ok=True); os.chdir(W); shutil.rmtree(os.path.join(W, 'ceiling_suite_local'), ignore_errors=True)
g = {'__name__': '__main__'}; C = '/home/claude/p8/cells/'
def run(name):
    t = time.time(); print('\n####', name, flush=True)
    exec(compile(open(C + name).read(), name, 'exec'), g); print(f'-- {time.time()-t:.1f}s', flush=True)
run('v00_setup.py'); exec(open('/home/claude/p8/fake_spot.py').read(), g)
g['PAIRS'] = g['PAIRS'][:3]; g['PANEL_D'] = g['PANEL_D'][::12]; g['FEE_WIN'] = 4
for c in ['v01_functions.py', 'v02_panel.py', 'v03_fee.py']:
    run(c)
