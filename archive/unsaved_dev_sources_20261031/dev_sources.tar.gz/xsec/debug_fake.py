# LOCAL DEBUG ONLY — format-faithful fake of data.binance.vision (futures, many symbols).
import io as _io, zipfile as _zf, hashlib as _hl, zlib as _zl
_SYMS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "ADAUSDT", "DOGEUSDT", "ZILUSDT", "ONTUSDT", "KNCUSDT", "BATUSDT", "QTUMUSDT"]
_LIQ = {s: 10 ** (2.5 - 0.35 * i) for i, s in enumerate(_SYMS)}        # depth within 1% ($M)
_PX = {s: [30000, 2000, 50, 0.5, 0.08, 0.02, 0.2, 0.6, 0.2, 2.5][i] for i, s in enumerate(_SYMS)}
_TICK = {s: [0.1, 0.01, 0.001, 0.0001, 0.00001, 0.00001, 0.0001, 0.0001, 0.0001, 0.001][i] for i, s in enumerate(_SYMS)}
_CACHE = {}
def _zip(name, text):
    b = _io.BytesIO()
    with _zf.ZipFile(b, "w") as z:
        z.writestr(name, text)
    return b.getvalue()
def _tick(s, date):
    t = _TICK[s]
    return t * 10 if (s == "ADAUSDT" and date >= "2024-03-05") else t
def _sim(s, date):
    key = ("sim", s, date)
    if key in _CACHE:
        return _CACHE[key]
    rr = np.random.default_rng(_zl.crc32(f"{s}{date}".encode()))
    thin = _SYMS.index(s) >= 5
    phi, eps, r, kap, a = (6.0, 0.25, 0.10, 2.0, 0.97) if thin else (1.0, -0.02, 0.15, 1.0, 0.97)
    n = 1440; x = np.zeros(n); d = np.zeros(n); u = np.zeros(n); p = np.zeros(n)
    for t in range(1, n):
        u[t] = 0.3 * u[t - 1] + rr.normal(0, 1.5)
        d[t] = np.clip((1 - r) * d[t - 1] + eps * u[t] + rr.normal(0, 0.03), -0.9, 0.9)
        dp = kap * u[t] + phi * d[t - 1] - (1 - a) * x[t - 1] + rr.normal(0, 3)
        p[t] = p[t - 1] + dp
        x[t] = p[t] - (0.967 * (p[t - 1] - x[t - 1]) + 0.033 * p[t])
    tk = _tick(s, date)
    price = np.round(_PX[s] * np.exp(p / 1e4) / tk) * tk
    _CACHE[key] = (price, u, d); return _CACHE[key]
def _gen(ds, s, date):
    price, u, d = _sim(s, date); tk = _tick(s, date)
    t0 = int(pd.Timestamp(date, tz="UTC").timestamp()); scale = _LIQ[s] / 50
    dec = max(0, -int(np.floor(np.log10(tk)))) + 1
    if ds == "klines":
        vq = (np.abs(u) * 1e6 + 5e6) * scale; tbq = (vq + u * 1e6 * scale) / 2
        L = ["open_time,open,high,low,close,volume,close_time,quote_volume,count,taker_buy_volume,taker_buy_quote_volume,ignore"]
        rr = np.random.default_rng(5)
        for m in range(1440):
            hi = price[m] + tk * rr.integers(0, 4); lo = price[m] - tk * rr.integers(0, 4); op = price[m - 1] if m else price[0]
            L.append(f"{(t0+60*m)*1000},{op:.{dec}f},{hi:.{dec}f},{lo:.{dec}f},{price[m]:.{dec}f},{vq[m]/price[m]:.3f},"
                     f"{(t0+60*m+59)*1000+999},{vq[m]:.2f},100,{tbq[m]/price[m]:.3f},{tbq[m]:.2f},0")
        return "\n".join(L)
    if ds == "bookDepth":
        L = ["timestamp,percentage,depth,notional"]
        for sec in range(0, 86400, 30):
            m = sec // 60; base = _LIQ[s] * 1e6 / 2
            b1, a1 = base * (1 + d[m]), base * (1 - d[m]); ts = pd.Timestamp(t0 + sec, unit="s").strftime("%Y-%m-%d %H:%M:%S")
            for b in [-5, -2, -1, 1, 2, 5]:
                side = b1 if b < 0 else a1; nt = side * abs(b) ** 0.8; px = price[m] * (1 - 0.003 * b)
                L.append(f"{ts},{b},{nt/px:.4f},{nt:.4f}")
        return "\n".join(L)
    if ds == "metrics":
        L = ["create_time,symbol,sum_open_interest,sum_open_interest_value,count_toptrader_long_short_ratio,"
             "sum_toptrader_long_short_ratio,count_long_short_ratio,sum_taker_long_short_vol_ratio"]
        rr = np.random.default_rng(_zl.crc32(f"m{s}{date}".encode())); nt = na = 0.0
        for k in range(288):
            m = min(5 * k + 4, 1439); ret = (np.log(price[m]) - np.log(price[max(m - 5, 0)])) * 1e4
            nt = 0.9 * nt + 0.004 * ret + rr.normal(0, 0.01); na = 0.6 * na + 0.002 * ret + rr.normal(0, 0.01)
            Rt, Ra = (1 + nt) / (1 - nt), (1 + na) / (1 - na)
            ts = pd.Timestamp(t0 + 300 * k, unit="s").strftime("%Y-%m-%d %H:%M:%S")
            L.append(f"{ts},{s},{1e6:.3f},{1e8*scale:.2f},{Rt*1.01:.4f},{Rt:.4f},{Ra:.4f},1.0")
        return "\n".join(L)
    if ds == "aggTrades":
        rr = np.random.default_rng(_zl.crc32(f"a{s}{date}".encode())); L = ["agg_trade_id,price,quantity,first_trade_id,last_trade_id,transact_time,is_buyer_maker"]
        i = 0
        for sec in range(0, 86400, 3):
            m = sec // 60
            for _ in range(rr.poisson(2)):
                buy = rr.random() < 0.5 + 0.1 * np.tanh(u[m]); q = rr.exponential(1e4 * scale) / price[m]
                L.append(f"{i},{price[m]:.{dec}f},{q:.4f},{i},{i},{(t0+sec)*1000+rr.integers(0,3000)},{'false' if buy else 'true'}"); i += 1
        return "\n".join(L)
def _http(url, method="GET", timeout=60, tries=3):
    if "s3-ap-northeast-1" in url:
        x = "".join(f"<CommonPrefixes><Prefix>data/futures/um/daily/bookDepth/{s}/</Prefix></CommonPrefixes>" for s in _SYMS + ["BTCUSDT_250926"])
        return 200, f'<?xml version="1.0"?><ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/"><IsTruncated>false</IsTruncated>{x}</ListBucketResult>'.encode()
    mm = re.search(r"/daily/(\w+)/([A-Z0-9_]+)/(?:1m/)?[A-Z0-9_]+-(?:1m|\w+)-(\d{4}-\d{2}-\d{2})\.zip(\.CHECKSUM)?$", url)
    if not mm:
        return 404, b""
    ds, s, date, chk = mm.groups()
    if s not in _SYMS or date > "2026-10-15" or (ds == "bookDepth" and date < "2023-01-01") or date == "2024-06-24":
        return 404, b""
    if method == "HEAD":
        return 200, b""
    key = (ds, s, date)
    if key not in _CACHE:
        _CACHE[key] = _zip(f"{s}-{ds}-{date}.csv", _gen(ds, s, date))
    raw = _CACHE[key]
    return (200, f"{_hl.sha256(raw).hexdigest()}  f.zip".encode()) if chk else (200, raw)
N_SYMBOLS = 8
_pd_real = panel_dates
def panel_dates(start=PANEL_START, end=PANEL_END):
    return _pd_real(start, end)[::3]
print("!! DEBUG: fake archive injected")
