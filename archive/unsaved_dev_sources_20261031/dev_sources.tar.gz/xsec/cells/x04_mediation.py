# ============================================================================
# CELL X4 — IS THERE A DEPTH-CARRIED OVERSHOOT IN THIN BOOKS? (training days)
# Local projections per symbol-day, as in Part 2 (D4): y_k = p_{t+k} - p_{t-1} on u_t
# (flow in units of the symbol's typical |flow|), 5 lags of Δp, u, d as controls:
#   (A) total; (B) + cumulative future flow; (C) + future flow and cumulative depth imbalance.
# Averaged by liquidity tercile. Overshoot = max_{k>=1} β_k - β_0, also relative to β_0 (unit-free).
# T6 predicts: overshoot > 0 in (B) in thin books, smaller in (C).
# ============================================================================
H_MIN = [0, 1, 2, 3, 5, 10, 15, 30]
def lp_day(df, flow_scale, nl=5):
    p, u, dd_, x, tot = prep(df, flow_scale)
    dp = np.diff(p, prepend=p[0]); n = len(p); t = np.arange(nl + 1, n - max(H_MIN) - 1)
    if not np.isfinite(dd_[t]).mean() > 0.9:
        return None
    L = np.column_stack([dp[t - j] for j in range(1, nl + 1)] + [u[t - j] for j in range(1, nl + 1)] +
                        [dd_[t - j] for j in range(1, nl + 1)])
    cu = np.concatenate([[0.0], np.cumsum(u)]); cd = np.concatenate([[0.0], np.cumsum(np.nan_to_num(dd_))])
    out = {"A": [], "B": [], "C": []}
    for k in H_MIN:
        y = p[t + k] - p[t - 1]
        XA = np.column_stack([u[t], L])
        XB = np.column_stack([XA, cu[t + k + 1] - cu[t + 1]]) if k else XA
        XC = np.column_stack([XB, cd[t + k] - cd[t]]) if k else XB
        for key, X in (("A", XA), ("B", XB), ("C", XC)):
            b = ols(y, X); out[key].append(b[0] if b is not None else np.nan)
    return {k: np.array(v) for k, v in out.items()}

LP = {}
for (s, d) in OK:
    if d <= TRAIN_END and s in TERCILE:
        r_ = lp_day(PANEL[(s, d)], FLOW_SCALE[s])
        if r_ is not None:
            LP[(s, d)] = r_
R4 = rng(44); res4 = {}
for terc in ["thick", "mid", "thin"]:
    keys = [k for k in LP if TERCILE[k[0]] == terc]
    res4[terc] = {"n_symbol_days": len(keys)}
    for v in ("A", "B", "C"):
        M = np.array([LP[k][v] for k in keys]); M = M[np.all(np.isfinite(M), 1)] if len(M) else M
        if len(M) < 20:
            continue
        mean = M.mean(0)
        boots = np.array([M[R4.integers(0, len(M), len(M))].mean(0) for _ in range(1000)])
        over = boots[:, 1:].max(1) - boots[:, 0]; rel = over / boots[:, 0]
        res4[terc][v] = {"beta": mean, "overshoot": float(mean[1:].max() - mean[0]),
                         "overshoot_ci": [float(np.quantile(over, .025)), float(np.quantile(over, .975))],
                         "overshoot_rel": float((mean[1:].max() - mean[0]) / mean[0]),
                         "overshoot_rel_ci": [float(np.quantile(rel, .025)), float(np.quantile(rel, .975))],
                         "peak_minute": H_MIN[int(np.argmax(mean))]}
        print(f"{terc:5s} ({v}) β {np.round(mean, 3)} overshoot/β0 {res4[terc][v]['overshoot_rel']:.3f} "
              f"CI {np.round(res4[terc][v]['overshoot_rel_ci'], 3)}")
record("X4_mediation_by_liquidity", None, "real-data", {"horizons_min": H_MIN, "by_tercile": res4},
       note="Support for T6 in thin books = (B) overshoot CI above 0 in the thin tercile, smaller in (C).")
