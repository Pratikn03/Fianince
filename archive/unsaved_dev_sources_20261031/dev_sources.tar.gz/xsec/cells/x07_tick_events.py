# ============================================================================
# CELL X7 — NATURAL EXPERIMENT: TICK-SIZE CHANGES (exploratory, events found from the data)
# The exchange occasionally changes a contract's price tick. A coarser tick changes queue
# lengths and hence how fast depth refills (r). We do not hard-code dates: the tick is inferred
# every day from the price grid (X2), changes are located on the panel, then dated exactly by
# a binary search over daily kline files.
# Design: 10 days before vs 10 days after (event day dropped), treated symbol vs up to 4 control
# symbols of similar liquidity whose tick did not change. Difference-in-differences, day bootstrap.
# T6 link: refill r governs the height and duration of any overshoot; the amplification condition
# C3 > 0 depends on φ, ε, κ, a, η, q, which a tick change may also move.
# ============================================================================
EVENT_WIN, MAX_EVENTS, N_CTRL = 10, 12, 4
TK = vst.dropna(subset=["tick"])[["symbol", "date", "tick"]].sort_values(["symbol", "date"])

def daily_tick(s, d):
    raw = fetch("klines", s, d)
    return np.nan if raw is None else infer_tick(read_zip_csv(raw, KL_COLS))

events = []
for s, g in TK.groupby("symbol"):
    v, dts = g["tick"].to_numpy(), g["date"].tolist()
    for i in range(2, len(v) - 1):
        ratio = v[i] / v[i - 1]
        if (ratio >= 2 or ratio <= 0.5) and v[i - 2] == v[i - 1] and v[i + 1] == v[i]:
            days = pd.date_range(dts[i - 1], dts[i], freq="D").strftime("%Y-%m-%d").tolist()
            lo, hi = 0, len(days) - 1            # first day carrying the new tick
            while lo < hi:
                m = (lo + hi) // 2
                tm = daily_tick(s, days[m])
                if np.isfinite(tm) and np.isclose(tm, v[i]):
                    hi = m
                else:
                    lo = m + 1
            events.append({"symbol": s, "event_date": days[lo], "tick_before": float(v[i - 1]),
                           "tick_after": float(v[i]), "ratio": float(ratio)})
events = sorted(events, key=lambda e: e["event_date"])[:MAX_EVENTS]
print(f"tick changes found: {len(events)}")
for e in events:
    print("  ", e)

liq_rank = {s: i for i, s in enumerate(sym.index)}         # X3 ranking (deep -> thin)
def stable_tick(s, d0, days=60):
    g = TK[(TK["symbol"] == s) & (TK["date"] >= (pd.Timestamp(d0) - pd.Timedelta(days=days)).strftime("%Y-%m-%d")) &
           (TK["date"] <= (pd.Timestamp(d0) + pd.Timedelta(days=days)).strftime("%Y-%m-%d"))]["tick"]
    return len(g) >= 3 and g.nunique() == 1

def daily_stats(s, d):
    df, st = get_day(s, d)
    if df is None or not st.get("depth_day_ok"):
        return None
    p, u, dd_, x, tot = prep(df, FLOW_SCALE.get(s, 1.0))
    est = fit_t6(p, u, dd_, x)
    if est is None:
        return None
    return {"r": est["r"], "eps": est["eps"], "phi": est["phi"], "C3": est["C3"], "peak_ratio": est["peak_ratio"],
            "log_depth1": float(np.log(np.nanmedian(tot))), "rv": float(np.nanstd(np.diff(p))),
            "rel_tick_bp": float(st["tick"] / np.nanmedian(df["close"]) * 1e4) if np.isfinite(st.get("tick", np.nan)) else np.nan}

OUTS = ["r", "eps", "phi", "C3", "peak_ratio", "log_depth1", "rv", "rel_tick_bp"]
res7 = []
for e in events:
    s, d0 = e["symbol"], e["event_date"]
    ctrls = sorted([c for c in SYMBOLS if c != s and c in liq_rank and stable_tick(c, d0)],
                   key=lambda c: abs(liq_rank[c] - liq_rank.get(s, 0)))[:N_CTRL]
    rel = [k for k in range(-EVENT_WIN, EVENT_WIN + 1) if k != 0]
    dates = {k: (pd.Timestamp(d0) + pd.Timedelta(days=k)).strftime("%Y-%m-%d") for k in rel}
    panel_e = []
    with ThreadPoolExecutor(THREADS) as ex:
        futs = {ex.submit(daily_stats, c, dates[k]): (c, k) for c in [s] + ctrls for k in rel}
        for f in as_completed(futs):
            c, k = futs[f]
            try:
                r_ = f.result()
            except Exception:
                r_ = None
            if r_:
                panel_e.append({**r_, "symbol": c, "k": k, "treated": c == s, "post": k > 0})
    P = pd.DataFrame(panel_e)
    if P.empty or P["treated"].sum() < 8 or (~P["treated"]).sum() < 8:
        res7.append({**e, "status": "insufficient valid days"}); continue
    Rb = rng(70); did, ci = {}, {}
    def did_of(Q):
        out = {}
        for o in OUTS:
            m = Q.groupby(["treated", "post"])[o].mean()
            try:
                out[o] = (m[(True, True)] - m[(True, False)]) - (m[(False, True)] - m[(False, False)])
            except KeyError:
                out[o] = np.nan
        return out
    did = did_of(P)
    ks = P["k"].unique(); boots = []
    for _ in range(1000):
        pick = Rb.choice(ks, len(ks)); boots.append(did_of(pd.concat([P[P["k"] == k] for k in pick])))
    B = pd.DataFrame(boots)
    ci = {o: [float(B[o].quantile(.025)), float(B[o].quantile(.975))] for o in OUTS}
    res7.append({**e, "controls": ctrls, "n_obs": len(P), "did": did, "did_ci": ci})
    print(s, d0, {o: round(did[o], 4) for o in ["rel_tick_bp", "r", "eps", "C3", "peak_ratio"]})

ok7 = [x for x in res7 if "did" in x]
summary7 = {}
if len(ok7) >= 3:
    dr = np.array([x["did"]["r"] for x in ok7]); dpk = np.array([x["did"]["peak_ratio"] for x in ok7])
    summary7 = {"n_events": len(ok7),
                "spearman_dr_vs_dpeak": float(stats.spearmanr(dr, dpk).statistic),
                "share_events_r_up_after_coarser_tick": float(np.mean([x["did"]["r"] > 0 for x in ok7 if x["ratio"] > 1])) if any(x["ratio"] > 1 for x in ok7) else None}
record("X7_tick_natural_experiment", None, "real-data", {"events": res7, "summary": summary7},
       note="Exploratory: events are found from the data, not pre-registered. With few events, report each one. "
            "T6 predicts that a rise in r lowers any overshoot (negative Spearman of Δr vs Δpeak).")
