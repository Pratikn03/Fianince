# ============================================================================
# CELL X9 — DISCLOSURE TEST FOR PAPER 1 (class-level positions in Binance `metrics`)
# Binance publishes, every 5 minutes, long/short ratios for its "top trader" group (by position
# and by account) and for all accounts. These are class-tagged position data, the kind of
# disclosure Paper 1's Proposition (tagged flow) is about.
#   Tagged model, class c:  n_c,t = r_c n_c,t-1 + w_c ret_t + e,   n = (R-1)/(R+1) from the L/S ratio R.
#   Price-only model:       f_t = Σ_{m=1..12} k_m ret_{t-m} + e    (5-min signed taker flow),
#                           then k_m = w1 r1^(m-1) + w2 r2^(m-1)   (two memory rates from prices and flow only).
# Day-block bootstrap (training days). Paper 1 predicts: rates are pinned down tightly with tagged
# data and loosely without it; the ratio of CI widths measures what disclosure buys.
# ============================================================================
DISC_SYMS = [s for s in ["BTCUSDT", "ETHUSDT"] if s in TERCILE] + [s for s in sym.index if TERCILE[s] == "thin"][-2:]
CLASSES = {"top_position": "top_pos_ratio", "top_account": "top_acc_ratio", "all_accounts": "acc_ratio"}

def five_min(df, s):
    m = df.index[df["top_pos_ratio"].notna() | df["acc_ratio"].notna()].to_numpy()
    m = m[m >= 5]
    if len(m) < 100:
        return None
    p = np.log(df["close"].to_numpy()) * 1e4; fl = df["flow"].to_numpy() / FLOW_SCALE[s]
    cf = np.concatenate([[0.0], np.cumsum(fl)])
    out = pd.DataFrame({"m": m, "ret": p[m] - p[m - 5], "flow": cf[m + 1] - cf[m - 4]})
    for c, col in CLASSES.items():
        R = df[col].to_numpy()[m]
        out[c] = (R - 1) / (R + 1)
    return out

def tagged_fit(days5, c):
    Y, X = [], []
    for g in days5:
        n = g[c].to_numpy(); r = g["ret"].to_numpy()
        y, x1, x2 = n[1:], n[:-1], r[1:]
        ok = np.isfinite(y) & np.isfinite(x1) & np.isfinite(x2)
        if ok.sum() < 30:
            continue
        Y.append(y[ok] - y[ok].mean()); X.append(np.column_stack([x1[ok] - x1[ok].mean(), x2[ok] - x2[ok].mean()]))
    if not Y:
        return np.nan, np.nan
    b = np.linalg.lstsq(np.vstack(X), np.concatenate(Y), rcond=None)[0]
    return float(b[0]), float(b[1])

def kernel_fit(days5, L=12):
    Y, X = [], []
    for g in days5:
        f, r = g["flow"].to_numpy(), g["ret"].to_numpy()
        if len(f) <= L + 10:
            continue
        Xl = np.column_stack([r[L - m:len(r) - m] for m in range(1, L + 1)]); y = f[L:]
        ok = np.all(np.isfinite(Xl), 1) & np.isfinite(y)
        Y.append(y[ok] - y[ok].mean()); X.append(Xl[ok] - Xl[ok].mean(0))
    k = np.linalg.lstsq(np.vstack(X), np.concatenate(Y), rcond=None)[0]
    m = np.arange(L)
    def resid(th):
        w1, r1, w2, r2 = th
        return w1 * r1 ** m + w2 * r2 ** m - k
    best = None
    for r1, r2 in [(0.2, 0.8), (0.1, 0.6), (0.4, 0.95), (0.05, 0.3)]:
        try:
            sol = optimize.least_squares(resid, [k[0] / 2, r1, k[0] / 2, r2],
                                         bounds=([-np.inf, 0, -np.inf, 0], [np.inf, 0.99, np.inf, 0.99]))
            if best is None or sol.cost < best.cost:
                best = sol
        except Exception:
            pass
    w1, r1, w2, r2 = best.x
    if r1 > r2:
        w1, r1, w2, r2 = w2, r2, w1, r1
    return {"k": k, "r_fast": r1, "r_slow": r2, "w_fast": w1, "w_slow": w2}

res9 = {}
for s in DISC_SYMS:
    days5 = [g for g in (five_min(PANEL[(s2, d)], s) for (s2, d) in OK if s2 == s and d <= TRAIN_END) if g is not None]
    if len(days5) < 15:
        print(s, "too few days with metrics"); continue
    R9 = rng(90); n = len(days5)
    point = {c: tagged_fit(days5, c) for c in CLASSES}; kp = kernel_fit(days5)
    bt = {c: [] for c in CLASSES}; bk = []
    for _ in range(200):
        pick = [days5[i] for i in R9.integers(0, n, n)]
        for c in CLASSES:
            bt[c].append(tagged_fit(pick, c))
        try:
            kk = kernel_fit(pick); bk.append((kk["r_fast"], kk["r_slow"]))
        except Exception:
            pass
    q = lambda v: [float(np.nanquantile(v, .025)), float(np.nanquantile(v, .975))]
    tag = {c: {"r": point[c][0], "w": point[c][1], "r_ci": q([b[0] for b in bt[c]]), "w_ci": q([b[1] for b in bt[c]])} for c in CLASSES}
    diff = np.array([b[0] for b in bt["top_position"]]) - np.array([b[0] for b in bt["all_accounts"]])
    bk = np.array(bk)
    pr = {"r_fast": kp["r_fast"], "r_slow": kp["r_slow"], "r_fast_ci": q(bk[:, 0]), "r_slow_ci": q(bk[:, 1]), "kernel": kp["k"]}
    w_tag = np.mean([tag[c]["r_ci"][1] - tag[c]["r_ci"][0] for c in CLASSES])
    w_pr = np.mean([pr["r_fast_ci"][1] - pr["r_fast_ci"][0], pr["r_slow_ci"][1] - pr["r_slow_ci"][0]])
    res9[s] = {"n_days": n, "tagged": tag, "top_minus_all_rate_ci": q(diff), "price_only": pr,
               "mean_rate_ci_width_tagged": float(w_tag), "mean_rate_ci_width_price_only": float(w_pr),
               "width_ratio_price_only_over_tagged": float(w_pr / w_tag) if w_tag > 0 else np.nan}
    print(f"{s}: rate CI width tagged {w_tag:.4f} vs price-only {w_pr:.4f} (ratio {w_pr / w_tag:.1f}); "
          f"top-minus-all rate CI {np.round(q(diff), 4)}")
record("X9_disclosure_metrics", None, "real-data", {"by_symbol": res9},
       note="Paper 1 predicts a width ratio well above 1: class-tagged data pin down memory rates that "
            "price and flow data alone leave loose. The top-minus-all CI shows whether classes differ.")
