# ============================================================================
# CELL X6 — HELD-OUT TEST, 2025-2026 (every evaluation is counted)
# ============================================================================
CTRL = ["rv_60", "rv_360", "abs_ret_60", "flow_imb_60", "log_vol_60", "log_depth1", "imbalance", "oi_chg_60"]

def unlock_x():
    pth = os.path.join(PREREG, "test_set_unlocks_xsec.json")
    n = json.load(open(pth))["n"] + 1 if os.path.exists(pth) else 1
    json.dump({"n": n, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": X_HASH}, open(pth, "w"))
    return n

def auc_(y, s):
    pos, neg = s[y == 1], s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return np.nan
    rk = stats.rankdata(np.concatenate([pos, neg]))
    return (rk[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))

def cw_test(y, fb, ff, lags=6):
    adj = (y - fb) ** 2 - ((y - ff) ** 2 - (fb - ff) ** 2)
    m = adj.mean(); e = adj - m; n = len(adj)
    lrv = e @ e / n + 2 * sum((1 - l / (lags + 1)) * (e[l:] @ e[:-l]) / n for l in range(1, lags + 1))
    t_ = m / np.sqrt(lrv / n)
    return float(t_), float(1 - stats.norm.cdf(t_))

def design(D, cols, syms):
    X = [np.ones(len(D))] + [D[c].to_numpy() for c in cols] + [(D["symbol"] == s).to_numpy(float) for s in syms[1:]]
    return np.column_stack(X)

def evaluate(sub, outcome, cand):
    A0 = sub[sub["split"] == "train"].copy(); B0 = sub[sub["split"] == "test"].copy()
    lo, hi = A0[cand].quantile([0.01, 0.99]); A0["cand_w"] = A0[cand].clip(lo, hi); B0["cand_w"] = B0[cand].clip(lo, hi)
    need = CTRL + ["cand_w", outcome]
    A = A0.dropna(subset=need); B = B0.dropna(subset=need).sort_values(["date", "symbol", "hour"])
    if len(A) < 200 or len(B) < 200 or A[outcome].std() < 1e-8 or A["cand_w"].std() < 1e-8:
        return {"skipped": "too few blocks or no variation in outcome/candidate", "n_train": len(A), "n_test": len(B),
                "clark_west_p": np.nan, "delta_r2": np.nan, "delta_r2_ci": [np.nan, np.nan]}
    B = B[B["symbol"].isin(set(A["symbol"]))]
    syms = sorted(A["symbol"].unique()); y = B[outcome].to_numpy()
    bb = np.linalg.lstsq(design(A, CTRL, syms), A[outcome].to_numpy(), rcond=None)[0]
    bf = np.linalg.lstsq(design(A, CTRL + ["cand_w"], syms), A[outcome].to_numpy(), rcond=None)[0]
    fb = design(B, CTRL, syms) @ bb; ff = design(B, CTRL + ["cand_w"], syms) @ bf
    ybar = A[outcome].mean(); sst = np.sum((y - ybar) ** 2)
    t_, p_ = cw_test(y, fb, ff)
    tail = (y > A[outcome].quantile(0.9)).astype(int)
    Rb = rng(88); dd = B["date"].to_numpy(); ud = np.unique(dd)
    pos = {d: np.where(dd == d)[0] for d in ud}; dR2, dA = [], []
    for _ in range(2000):
        idx = np.concatenate([pos[d] for d in Rb.choice(ud, len(ud))])
        s_ = np.sum((y[idx] - ybar) ** 2)
        dR2.append((np.sum((y[idx] - fb[idx]) ** 2) - np.sum((y[idx] - ff[idx]) ** 2)) / s_)
        dA.append(auc_(tail[idx], ff[idx]) - auc_(tail[idx], fb[idx]))
    return {"n_train": len(A), "n_test": len(B), "n_symbols": len(syms),
            "r2_base": 1 - np.sum((y - fb) ** 2) / sst, "r2_full": 1 - np.sum((y - ff) ** 2) / sst,
            "delta_r2": (np.sum((y - fb) ** 2) - np.sum((y - ff) ** 2)) / sst,
            "delta_r2_ci": [float(np.nanquantile(dR2, .025)), float(np.nanquantile(dR2, .975))],
            "auc_base": auc_(tail, fb), "auc_full": auc_(tail, ff),
            "delta_auc_ci": [float(np.nanquantile(dA, .025)), float(np.nanquantile(dA, .975))],
            "clark_west_t": t_, "clark_west_p": p_, "coef_candidate_train": float(bf[len(CTRL) + 1])}

assert os.path.exists(px_path), "run X5 first"
n_unl = unlock_x()
thin = XB[XB["tercile"] == "thin"]
primary = evaluate(thin, "MAE_60", "C3_hat")
secondary = {"thin: MAE_60 | peak_ratio_hat": evaluate(thin, "MAE_60", "peak_ratio_hat"),
             "thin: depth_collapse_60 | C3_hat": evaluate(thin, "depth_collapse_60", "C3_hat"),
             "thin: OI_drop_60 | C3_hat": evaluate(thin, "OI_drop_60", "C3_hat"),
             "mid: MAE_60 | C3_hat": evaluate(XB[XB["tercile"] == "mid"], "MAE_60", "C3_hat"),
             "thick: MAE_60 | C3_hat": evaluate(XB[XB["tercile"] == "thick"], "MAE_60", "C3_hat"),
             "all symbols: MAE_60 | C3_hat": evaluate(XB, "MAE_60", "C3_hat")}
ps = sorted([(v["clark_west_p"] if np.isfinite(v["clark_west_p"]) else 1.0, k) for k, v in secondary.items()])
for i, (p_, k) in enumerate(ps):
    secondary[k]["holm_p"] = min(1.0, max(p2 * (len(ps) - j) for j, (p2, _) in enumerate(ps[:i + 1])))
print(json.dumps(_clean(primary), indent=1))
print(pd.DataFrame(secondary).T[["delta_r2", "delta_r2_ci", "clark_west_p", "holm_p"]].to_string())
gx = bool(np.isfinite(primary["clark_west_p"]) and primary["clark_west_p"] < 0.05 and primary["delta_r2_ci"][0] > 0)
record("X6_xsec_test_G2", bool(gx), "real-data",
       {"primary": primary, "secondary": secondary, "prereg_sha256": X_HASH, "test_set_unlocks": n_unl},
       criterion=PREREG_X["success"], note="Report whatever it shows; unlocks > 1 must be disclosed.")

# flags in the thin tercile: high C3 vs high volatility (each flags 10% of training blocks)
A = thin[thin["split"] == "train"].dropna(subset=["C3_hat", "rv_60", "MAE_60"])
B = thin[thin["split"] == "test"].dropna(subset=["C3_hat", "rv_60", "MAE_60"])
tail = (B["MAE_60"] > A["MAE_60"].quantile(0.9)).to_numpy()
def pr_(f):
    tp = np.sum(f & tail); return {"flag_rate": f.mean(), "precision": tp / max(f.sum(), 1), "recall": tp / max(tail.sum(), 1)}
fw = (B["C3_hat"] > A["C3_hat"].quantile(0.9)).to_numpy(); fv = (B["rv_60"] > A["rv_60"].quantile(0.9)).to_numpy()
record("X6b_thin_flags", None, "real-data", {"C3_flag": pr_(fw), "vol_flag": pr_(fv), "either": pr_(fw | fv),
       "n_tail_events": int(tail.sum())}, note="Thin books: does the C3 flag catch tail hours a volatility flag misses?")
