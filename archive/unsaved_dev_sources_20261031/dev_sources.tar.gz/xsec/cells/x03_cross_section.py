# ============================================================================
# CELL X3 — T6 ACROSS THE CROSS-SECTION (training days only, <= 2024-12-31)
# Same day-by-day estimator as Part 2 (D3), on every symbol:
#   price:    Δp_t = κ u_t + φ d_{t-1} - (1-a) x_{t-1} + e
#   depth:    d_t  = (1-r) d_{t-1} + ε u_t + e
#   momentum: u_t  = (1-η) u_{t-1} + ηq x_{t-1} + e
#   C3 = φε + κ²ηq - (1-a)κ  (amplification iff C3 > 0 in the 2-state case with η q = 0)
# Flow u is scaled by the symbol's median 1-minute |flow| so κ, φ, ε are comparable across symbols
# (C3's sign does not depend on this scaling).
# Also: the feedback loop gain Q of Paper 1 (VAR on x and next-minute flow) and its placebo.
# Liquidity = median depth within 1% of mid (bid1 + ask1, $M) on training days.
# ============================================================================
def prep(df, flow_scale):
    p = np.log(df["close"].to_numpy()) * 1e4
    u = df["flow"].to_numpy() / flow_scale
    tot = (df["bid1"] + df["ask1"]).to_numpy()
    d = ((df["bid1"] - df["ask1"]) / (df["bid1"] + df["ask1"])).to_numpy()
    x = p - pd.Series(p).ewm(span=60, adjust=False).mean().to_numpy()
    return p, u, d, x, tot

def ols(y, X):
    ok = np.all(np.isfinite(X), 1) & np.isfinite(y)
    if ok.sum() < X.shape[1] + 20:
        return None
    return np.linalg.lstsq(np.column_stack([np.ones(ok.sum()), X[ok]]), y[ok], rcond=None)[0][1:]

def impulse_t6(a, phi, kappa, r, eps, eta, q, L=120):
    x = np.zeros(L); dd = np.zeros(L); f = np.zeros(L)
    for t in range(L):
        if t > 0:
            f[t] = (1 - eta) * f[t - 1] + eta * q * x[t - 1]
        tot = (1.0 if t == 0 else 0.0) + f[t]
        x[t] = (a * x[t - 1] + phi * dd[t - 1] if t else 0) + kappa * tot
        dd[t] = ((1 - r) * dd[t - 1] if t else 0) + eps * tot
        if abs(x[t]) > 1e9:
            return np.full(L, np.nan)
    return x

def fit_t6(p, u, d, x):
    dp = np.diff(p, prepend=np.nan)
    bp = ols(dp[1:], np.column_stack([u[1:], d[:-1], x[:-1]]))
    bd = ols(d[1:], np.column_stack([d[:-1], u[1:]]))
    bm = ols(u[1:], np.column_stack([u[:-1], x[:-1]]))
    if bp is None or bd is None or bm is None:
        return None
    kappa, phi, a = bp[0], bp[1], 1 + bp[2]
    r, eps, eta = 1 - bd[0], bd[1], 1 - bm[0]
    q = bm[1] / eta if abs(eta) > 1e-6 else np.nan
    h = impulse_t6(a, phi, kappa, r, eps, eta, q)
    ok = np.all(np.isfinite(h)) and abs(h[0]) > 1e-12
    return {"kappa": kappa, "phi": phi, "a": a, "r": r, "eps": eps, "eta": eta, "q": q,
            "C2": phi * eps - (1 - a) * kappa, "C3": phi * eps + kappa ** 2 * eta * q - (1 - a) * kappa,
            "peak_ratio": float(np.max(h) / h[0]) if ok else np.nan, "peak_minute": int(np.argmax(h)) if ok else -1}

def loop_gain(p, u, span=30):
    x = p - pd.Series(p).ewm(span=span, adjust=False).mean().to_numpy()
    f = np.roll(u, -1)[:-1]; x = x[:-1]
    Z = np.column_stack([x, f])
    Y, X = Z[1:], np.column_stack([np.ones(len(Z) - 1), Z[:-1]])
    ok = np.all(np.isfinite(Y), 1) & np.all(np.isfinite(X), 1)
    if ok.sum() < 100:
        return np.nan
    J = np.linalg.lstsq(X[ok], Y[ok], rcond=None)[0][1:].T
    return float(J[0, 1] * J[1, 0] / (1 - J[1, 1])) if abs(1 - J[1, 1]) > 1e-9 else np.nan

FLOW_SCALE = {}
for s in SYMBOLS:
    v = [np.nanmedian(np.abs(PANEL[(s2, d)]["flow"].to_numpy())) for (s2, d) in OK if s2 == s and d <= TRAIN_END]
    FLOW_SCALE[s] = float(np.nanmedian(v)) if v and np.nanmedian(v) > 0 else 1.0

Rq = rng(31)
def symday_row(s, d):
    df = PANEL[(s, d)]
    p, u, dd_, x, tot = prep(df, FLOW_SCALE[s])
    est = fit_t6(p, u, dd_, x)
    if est is None:
        return None
    rv = float(np.nanstd(np.diff(p)))
    pl = np.cumsum(np.random.default_rng(zlib.crc32(f"{s}{d}".encode())).normal(0, rv, len(p)))   # placebo walk
    est.update({"symbol": s, "date": d, "rv": rv, "depth1_musd": float(np.nanmedian(tot)),
                "Q": loop_gain(p, u), "Q_placebo": loop_gain(pl, u)})
    return est

rows = [r for r in (symday_row(s, d) for (s, d) in OK) if r]
XS = pd.DataFrame(rows)
XS["split"] = np.where(XS["date"] <= TRAIN_END, "train", "test")
XS.to_parquet(os.path.join(XDATA, "symbol_days.parquet"))
tr = XS[XS["split"] == "train"]
sym = tr.groupby("symbol").agg(depth1=("depth1_musd", "median"), C3_mean=("C3", "mean"), C3_median=("C3", "median"),
                               share_C3_pos=("C3", lambda v: float((v > 0).mean())), share_C2_pos=("C2", lambda v: float((v > 0).mean())),
                               phi=("phi", "median"), eps=("eps", "median"), r=("r", "median"),
                               peak_ratio=("peak_ratio", "median"), share_peak_gt1=("peak_ratio", lambda v: float((v > 1.0001).mean())),
                               Q=("Q", "mean"), Q_placebo=("Q_placebo", "mean"), n_days=("C3", "size"))
sym = sym[sym["n_days"] >= 10].sort_values("depth1", ascending=False)
# liquidity terciles fixed on TRAINING depth (used unchanged in X5/X6)
sym["tercile"] = pd.qcut(sym["depth1"].rank(method="first"), 3, labels=["thin", "mid", "thick"]).astype(str)
TERCILE = sym["tercile"].to_dict()
print(sym.round(4).to_string())

Rb = rng(32); S = sym.reset_index()
def spearman_boot(col):
    rho0 = stats.spearmanr(np.log(S["depth1"]), S[col]).statistic
    bs = [stats.spearmanr(np.log(S["depth1"].iloc[i]), S[col].iloc[i]).statistic
          for i in (Rb.integers(0, len(S), len(S)) for _ in range(2000))]
    return {"rho": float(rho0), "ci": [float(np.nanquantile(bs, .025)), float(np.nanquantile(bs, .975))]}
terc = {t: {"n_symbols": int((sym["tercile"] == t).sum()),
            "share_C3_pos_pooled": float((tr[tr["symbol"].map(TERCILE) == t]["C3"] > 0).mean()),
            "mean_C3_pooled": float(tr[tr["symbol"].map(TERCILE) == t]["C3"].mean()),
            "mean_C3_ci": boot_ci(tr[tr["symbol"].map(TERCILE) == t]["C3"], Rb),
            "median_phi": float(tr[tr["symbol"].map(TERCILE) == t]["phi"].median()),
            "median_eps": float(tr[tr["symbol"].map(TERCILE) == t]["eps"].median()),
            "share_eps_pos": float((tr[tr["symbol"].map(TERCILE) == t]["eps"] > 0).mean()),
            "mean_Q": float(tr[tr["symbol"].map(TERCILE) == t]["Q"].mean()),
            "mean_Q_ci": boot_ci(tr[tr["symbol"].map(TERCILE) == t]["Q"], Rb)}
        for t in ["thick", "mid", "thin"]}
print(pd.DataFrame(terc).T.to_string())
record("X3_T6_cross_section", None, "real-data",
       {"by_symbol": sym.to_dict("index"), "by_tercile": terc,
        "spearman_logdepth_vs_C3": spearman_boot("C3_mean"),
        "spearman_logdepth_vs_shareC3pos": spearman_boot("share_C3_pos"),
        "spearman_logdepth_vs_Q": spearman_boot("Q"),
        "n_symbol_days_train": len(tr), "flow_scale_musd": FLOW_SCALE},
       note="T6 predicts higher C3 in thinner books: negative Spearman with log depth, CI below 0. "
            "Q vs placebo per symbol is Paper 1's feedback cross-section.")
