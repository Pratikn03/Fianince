# ============================================================================
# CELL X10 — SUMMARY AND DOWNLOAD (Part 4)
# ============================================================================
rows = []
for fp in sorted(glob.glob(os.path.join(RESULTS, "X*.json"))):
    r = json.load(open(fp)); rows.append({"test": r["test_id"], "status": r["status"], "kind": r["kind"]})
print(pd.DataFrame(rows).to_string(index=False))
zp = os.path.join(BASE, "xsec_results.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "X*.json")) + [os.path.join(RESULTS, "xsec_manifest_sha256.csv")] + \
              glob.glob(os.path.join(PREREG, "P4_*.json")) + glob.glob(os.path.join(PREREG, "test_set_unlocks_xsec.json")):
        if os.path.exists(fp):
            z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp)
if IN_COLAB:
    from google.colab import files
    files.download(zp)
