# ============================================================================
# CELL X8 — DEPLETION AT THE SNAPSHOT SCALE (~30 s) FROM TRADE DATA
# Part 2 found ε < 0 at one minute: taker buying is followed by slightly MORE ask-side depth,
# i.e. the book refills the side being hit. Is that a 1-minute aggregation artifact?
# Here signed taker flow is summed exactly between consecutive validated depth snapshots
# using aggTrades (every trade, with the aggressor side), and we estimate
#     d_i = c + (1-r) d_{i-1} + ε30 f_i + e           (depth imbalance within 1%, unit-free)
# with flow in units of the median |f| per interval. Sweeps: ε30 for intervals in the top decile of |f|.
# T6's depletion channel needs ε30 > 0 (flow takes depth from the side it hits).
# BTC aggTrades files are large (100s of MB per day): AT_DAYS keeps this manageable.
# ============================================================================
AT_DAYS = 6
AGG_COLS = ["agg_trade_id", "price", "quantity", "first_trade_id", "last_trade_id", "transact_time", "is_buyer_maker"]
thin_syms = [s for s in sym.index if TERCILE[s] == "thin"][-3:]
mid_syms = [s for s in sym.index if TERCILE[s] == "mid"][:1]
AT_SYMS = [s for s in ["BTCUSDT"] if s in TERCILE] + mid_syms + thin_syms

def read_agg(raw):
    """Memory-light reader for large aggTrades files: price, quantity, time, aggressor side only."""
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        name = [n for n in z.namelist() if n.endswith(".csv")][0]
        with z.open(name) as fh:
            first = fh.readline().decode()
        has_header = bool(re.search(r"[A-Za-z_]", first.split(",")[0]))
        with z.open(name) as fh:
            a = pd.read_csv(fh, header=0 if has_header else None, usecols=[1, 2, 5, 6],
                            dtype={1: "float64", 2: "float64"} if not has_header else None)
    a.columns = ["price", "quantity", "transact_time", "is_buyer_maker"]
    return a

def interval_series(s, d):
    cache = os.path.join(XDATA, "depl30", f"{s}_{d}.parquet"); os.makedirs(os.path.dirname(cache), exist_ok=True)
    if os.path.exists(cache):
        return pd.read_parquet(cache)
    t0 = int(pd.Timestamp(f"{d} 00:00:00", tz="UTC").timestamp())
    snap, _ = validated_snapshots(s, d, PANEL[(s, d)]["close"].to_numpy(), t0)
    raw = fetch("aggTrades", s, d)
    if snap is None or raw is None or len(snap) < 500:
        return None
    a = read_agg(raw); del raw
    sec = to_utc_seconds(a["transact_time"])
    bm = a["is_buyer_maker"].astype(str).str.lower().isin(["true", "1"]).to_numpy()
    sgn = np.where(bm, -1.0, 1.0) * a["price"].astype(float).to_numpy() * a["quantity"].astype(float).to_numpy() / 1e6
    snap = snap.sort_index(); ss = snap.index.to_numpy()
    pos = np.searchsorted(ss, sec, side="left")              # trade at second t belongs to interval ending at the next snapshot
    flow = np.bincount(pos[pos < len(ss)], weights=sgn[pos < len(ss)], minlength=len(ss))
    out = pd.DataFrame({"sec": ss, "d": ((snap["bid1"] - snap["ask1"]) / (snap["bid1"] + snap["ask1"])).to_numpy(),
                        "flow": flow, "gap": np.diff(ss, prepend=ss[0] - 30)})
    out.to_parquet(cache)
    return out

res8 = {}
for s in AT_SYMS:
    days = [d for (s2, d) in OK if s2 == s and d <= TRAIN_END]
    days = [days[int(i)] for i in np.linspace(0, len(days) - 1, min(AT_DAYS, len(days)))] if days else []
    per = []
    for d in days:
        try:
            iv = interval_series(s, d)
        except Exception as e:
            print("  !", s, d, e); iv = None
        if iv is None:
            continue
        iv = iv[(iv["gap"] > 0) & (iv["gap"] <= 90)]           # consecutive snapshots only
        sc = np.nanmedian(np.abs(iv["flow"])) or 1.0
        f = iv["flow"].to_numpy() / sc; dd = iv["d"].to_numpy()
        big = np.abs(f) >= np.quantile(np.abs(f), 0.9)
        y, X = dd[1:], np.column_stack([dd[:-1], f[1:], f[1:] * big[1:], f[:-1]])
        ok = np.all(np.isfinite(X), 1) & np.isfinite(y)
        b = np.linalg.lstsq(np.column_stack([np.ones(ok.sum()), X[ok]]), y[ok], rcond=None)[0]
        p_, u_, d1, x_, _ = prep(PANEL[(s, d)], FLOW_SCALE[s]); e1 = fit_t6(p_, u_, d1, x_)
        per.append({"date": d, "eps30": b[2], "eps30_sweep_extra": b[3], "eps30_next": b[4], "rho": b[1],
                    "eps_1min": e1["eps"] if e1 else np.nan, "n_intervals": int(ok.sum())})
    if per:
        P = pd.DataFrame(per); R8 = rng(80)
        res8[s] = {"tercile": TERCILE[s], "days": P.to_dict("records"),
                   **{f"mean_{c}": float(P[c].mean()) for c in ["eps30", "eps30_sweep_extra", "eps30_next", "eps_1min"]},
                   **{f"ci_{c}": boot_ci(P[c], R8) for c in ["eps30", "eps30_sweep_extra", "eps30_next"]},
                   "share_days_eps30_pos": float((P["eps30"] > 0).mean())}
        print(f"{s:10s} ({TERCILE[s]}): ε30 {res8[s]['mean_eps30']:+.5f} CI {np.round(res8[s]['ci_eps30'], 5)}; "
              f"sweep extra {res8[s]['mean_eps30_sweep_extra']:+.5f}; 1-min ε {res8[s]['mean_eps_1min']:+.5f}")
record("X8_depletion_30s", None, "real-data", {"by_symbol": res8, "days_per_symbol": AT_DAYS},
       note="T6's depletion channel requires ε30 > 0 (CI above 0), at least for sweeps. If ε30 < 0 too, "
            "the 1-minute finding is not an aggregation artifact: the book refills the side being hit.")
