# ============================================================================
# CELL X5 — HOURLY BLOCKS FOR EVERY SYMBOL + PRE-REGISTRATION (run before X6)
# Blocks: hours 6..23 UTC; features from minutes [t-360, t), outcomes from (t, t+60].
# The spec below is hashed and saved BEFORE the 2025-2026 blocks are evaluated in X6.
# ============================================================================
def day_blocks(s, d):
    df = PANEL[(s, d)]
    p, u, dd_, x, tot = prep(df, FLOW_SCALE[s])
    oi = df["oi"].ffill().to_numpy(); vol = df["vol"].to_numpy(); rows = []
    for hr in range(6, 24):
        t = hr * 60
        if t + 1 >= 1440:
            continue
        w, h, f = slice(t - 360, t), slice(t - 60, t), slice(t, min(t + 61, 1440))
        est = fit_t6(p[w], u[w], dd_[w], x[w])
        r60, r360 = np.diff(p[h]), np.diff(p[w])
        rows.append({"symbol": s, "date": d, "hour": hr,
                     "C3_hat": est["C3"] if est else np.nan, "peak_ratio_hat": est["peak_ratio"] if est else np.nan,
                     "rv_60": np.nanstd(r60), "rv_360": np.nanstd(r360), "abs_ret_60": abs(p[t - 1] - p[t - 60]),
                     "flow_imb_60": np.nansum(u[h]) / (np.nansum(np.abs(u[h])) + 1e-12),
                     "log_vol_60": np.log1p(np.nansum(vol[h])),
                     "log_depth1": np.log(tot[t - 1]) if np.isfinite(tot[t - 1]) and tot[t - 1] > 0 else np.nan,
                     "imbalance": dd_[t - 1],
                     "oi_chg_60": (oi[t - 1] / oi[t - 60] - 1) * 100 if np.isfinite(oi[t - 60]) and oi[t - 60] > 0 else np.nan,
                     "MAE_60": float(np.nanmax(np.abs(p[f] - p[t - 1]))),
                     "OI_drop_60": float((oi[t - 1] - np.nanmin(oi[f])) / oi[t - 1] * 100) if np.isfinite(oi[t - 1]) and oi[t - 1] > 0 else np.nan,
                     "depth_collapse_60": float((1 - np.nanmin(tot[f]) / tot[t - 1]) * 100) if np.isfinite(tot[t - 1]) and tot[t - 1] > 0 else np.nan})
    return rows

BLK = os.path.join(XDATA, f"blocks_{len(SYMBOLS)}sym.parquet")
want = {(s, d) for (s, d) in OK if s in TERCILE}
if os.path.exists(BLK) and set(map(tuple, pd.read_parquet(BLK)[["symbol", "date"]].drop_duplicates().to_numpy())) >= want:
    XB = pd.read_parquet(BLK)
else:
    rows = []
    for i, (s, d) in enumerate(sorted(want)):
        rows += day_blocks(s, d)
        if (i + 1) % 300 == 0:
            print(f"   blocks: {i+1}/{len(want)} symbol-days")
    XB = pd.DataFrame(rows); XB.to_parquet(BLK)
XB["tercile"] = XB["symbol"].map(TERCILE)
XB["split"] = np.where(XB["date"] <= TRAIN_END, "train", np.where(XB["date"] >= TEST_START, "test", "gap"))
print(XB.groupby(["tercile", "split"]).size().unstack())

# leakage audit: scramble everything from t on; features must not change
Rl = rng(55); fails = 0; keys = sorted(want)
for _ in range(30):
    s, d = keys[int(Rl.integers(len(keys)))]; hr = int(Rl.integers(6, 23)); t = hr * 60
    a_ = [r for r in day_blocks(s, d) if r["hour"] == hr][0]
    saved = PANEL[(s, d)]; df2 = saved.copy()
    for c in ["close", "flow", "vol", "bid1", "ask1", "oi"]:
        v = df2[c].to_numpy().copy(); v[t:] = v[t:][::-1] * 1.7; df2[c] = v
    PANEL[(s, d)] = df2
    b_ = [r for r in day_blocks(s, d) if r["hour"] == hr][0]
    PANEL[(s, d)] = saved
    feats = [k for k in a_ if k not in ("symbol", "date", "hour", "MAE_60", "OI_drop_60", "depth_collapse_60")]
    fails += any(not np.isclose(a_[k], b_[k], equal_nan=True) for k in feats)
record("X5_no_lookahead", fails == 0, "audit", {"trials": 30, "failures": fails},
       criterion="hourly features unchanged when all data from t onward are scrambled")

PREREG_X = {
    "question": "In the thinnest third of Binance USD-M order books, does the T6 amplification statistic C3_hat "
                "(estimated from the previous 6 hours) predict the next hour's maximum adverse excursion beyond controls?",
    "data": "Binance USD-M futures, symbols fixed in cell X1; panel days 10th and 24th of each month; validation V1-V5",
    "terciles": "liquidity terciles from median training-period depth within 1% of mid (cell X3), fixed",
    "unit": "symbol-hour blocks, hours 6-23 UTC; features [t-360, t); outcomes (t, t+60]",
    "controls": ["rv_60", "rv_360", "abs_ret_60", "flow_imb_60", "log_vol_60", "log_depth1", "imbalance", "oi_chg_60", "symbol fixed effects"],
    "primary": "tercile=thin, outcome=MAE_60, candidate=C3_hat winsorized at the thin tercile's train 1%/99%",
    "secondary": ["thin: MAE_60 | peak_ratio_hat", "thin: depth_collapse_60 | C3_hat", "thin: OI_drop_60 | C3_hat",
                  "mid: MAE_60 | C3_hat", "thick: MAE_60 | C3_hat", "all symbols: MAE_60 | C3_hat"],
    "train": "dates <= 2024-12-31", "test": "dates >= 2025-01-01",
    "model": "OLS; tail = outcome above train 90th percentile; score = fitted value",
    "inference": "Clark-West (Newey-West 6 lags); bootstrap 2,000 resampling dates (all symbols on a date together) for ΔR², ΔAUC",
    "success": "primary: Clark-West one-sided p < 0.05 AND bootstrap 95% CI of ΔR² excludes 0; secondary Holm-adjusted",
}
spec_txt = json.dumps(PREREG_X, indent=2, sort_keys=True)
X_HASH = hashlib.sha256(spec_txt.encode()).hexdigest()
px_path = os.path.join(PREREG, "P4_xsec.json")
if not os.path.exists(px_path):
    open(px_path, "w").write(spec_txt); print("pre-registration written:", px_path)
elif hashlib.sha256(open(px_path).read().encode()).hexdigest() != X_HASH:
    print("!! WARNING: spec differs from the registered file. Any change after seeing results must be disclosed.")
print("spec SHA-256:", X_HASH, "\nCommit prereg/P4_xsec.json (e.g. to GitHub) before running X6.")
