# ============================================================================
# CELL X1 — CHOOSE THE SYMBOLS (before any analysis)
# 1. List USD-M perpetuals that have bookDepth on data.binance.vision (bucket listing;
#    falls back to a fixed list of long-lived contracts if the listing is unavailable).
# 2. Keep symbols with depth both early (2023) and late (2026), so every symbol spans
#    the training and test periods.
# 3. Rank by quote volume on LIQ_RANK_DATE (a training day) and take N_SYMBOLS spread
#    evenly across the ranking, so the sample runs from the deepest books to thin ones.
# ============================================================================
FALLBACK = ("BTCUSDT ETHUSDT BNBUSDT XRPUSDT ADAUSDT DOGEUSDT SOLUSDT DOTUSDT LTCUSDT LINKUSDT BCHUSDT TRXUSDT "
            "AVAXUSDT ATOMUSDT ETCUSDT FILUSDT NEARUSDT AAVEUSDT UNIUSDT SANDUSDT MANAUSDT AXSUSDT XLMUSDT ALGOUSDT "
            "VETUSDT EOSUSDT XTZUSDT THETAUSDT ICPUSDT EGLDUSDT CHZUSDT ENJUSDT ZILUSDT KAVAUSDT RUNEUSDT GALAUSDT "
            "CRVUSDT DYDXUSDT 1INCHUSDT COMPUSDT SNXUSDT ZECUSDT DASHUSDT NEOUSDT IOTAUSDT ONTUSDT QTUMUSDT BATUSDT "
            "ZRXUSDT KNCUSDT").split()

def list_bucket_symbols(ds="bookDepth"):
    url0 = ("https://s3-ap-northeast-1.amazonaws.com/data.binance.vision?delimiter=/"
            f"&prefix=data/futures/um/daily/{ds}/")
    syms, marker = [], ""
    for _ in range(20):
        code, raw = _http(url0 + (f"&marker={marker}" if marker else ""), timeout=60)
        if code != 200 or not raw:
            return []
        root = ET.fromstring(raw)
        ns = {"s": root.tag.split("}")[0].strip("{")} if root.tag.startswith("{") else {}
        pref = [e.text for e in (root.findall(".//s:CommonPrefixes/s:Prefix", ns) if ns else root.findall(".//CommonPrefixes/Prefix"))]
        syms += [p.rstrip("/").split("/")[-1] for p in pref]
        trunc = (root.find("s:IsTruncated", ns) if ns else root.find("IsTruncated"))
        if trunc is None or trunc.text != "true" or not pref:
            break
        marker = pref[-1]
    return sorted(set(syms))

try:
    listed = list_bucket_symbols()
except Exception as e:
    print("bucket listing failed:", e); listed = []
cands = [s for s in listed if re.fullmatch(r"[A-Z0-9]+USDT", s)] or FALLBACK
print(f"candidates: {len(cands)} ({'bucket listing' if listed else 'fallback list'})")

EARLY, LATE = "2023-03-10", "2026-06-10"
def span_ok(s):
    return exists("bookDepth", s, EARLY) and exists("bookDepth", s, LATE)
with ThreadPoolExecutor(THREADS) as ex:
    keep = [s for s, ok in zip(cands, ex.map(span_ok, cands)) if ok]
print(f"with depth in both {EARLY} and {LATE}: {len(keep)}")

KL_COLS = ["open_time", "open", "high", "low", "close", "volume", "close_time", "quote_volume",
           "count", "taker_buy_volume", "taker_buy_quote_volume", "ignore"]
def day_quote_volume(s):
    raw = fetch("klines", s, LIQ_RANK_DATE)
    return np.nan if raw is None else float(read_zip_csv(raw, KL_COLS)["quote_volume"].astype(float).sum())
with ThreadPoolExecutor(THREADS) as ex:
    qv = dict(zip(keep, ex.map(day_quote_volume, keep)))
rank = sorted([s for s in keep if np.isfinite(qv[s])], key=lambda s: -qv[s])
must = [s for s in ("BTCUSDT", "ETHUSDT") if s in rank]
rest = [s for s in rank if s not in must]
k = max(N_SYMBOLS - len(must), 0)
pick = [rest[int(round(i))] for i in np.linspace(0, len(rest) - 1, min(k, len(rest)))] if rest else []
SYMBOLS = must + [s for s in pick if s not in must]
print("symbols:", SYMBOLS)
record("X1_universe", None, "audit",
       {"source": "bucket listing" if listed else "fallback list", "n_candidates": len(cands),
        "n_span_ok": len(keep), "symbols": SYMBOLS,
        "quote_volume_musd_on_rank_date": {s: qv[s] / 1e6 for s in SYMBOLS}, "rank_date": LIQ_RANK_DATE},
       note="Symbols are fixed here, from a training-period ranking, before any T6 statistic is computed.")
