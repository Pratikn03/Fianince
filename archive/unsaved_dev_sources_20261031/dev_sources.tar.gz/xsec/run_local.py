import os, sys, time, traceback, glob
os.makedirs('/home/claude/xsec/run', exist_ok=True); os.chdir('/home/claude/xsec/run')
g = {'__name__': '__main__'}
for c in sorted(glob.glob('/home/claude/xsec/cells/x*.py')):
    if len(sys.argv) > 1 and os.path.basename(c)[:3] not in sys.argv[1].split(',') and 'x00' not in c: pass
    print('\n####', os.path.basename(c), flush=True); t = time.time()
    try:
        exec(compile(open(c).read(), c, 'exec'), g)
    except Exception:
        traceback.print_exc(); break
    print(f'-- {time.time()-t:.1f}s', flush=True)
    if 'x00_setup' in c:
        exec(open('/home/claude/xsec/debug_fake.py').read(), g)
