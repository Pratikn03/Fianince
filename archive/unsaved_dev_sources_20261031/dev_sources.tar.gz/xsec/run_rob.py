import os, sys, traceback
os.chdir('/home/claude/xsec/run'); g={'__name__':'__main__'}
exec(open('/home/claude/xsec/cells/x00_setup.py').read(), g)
exec(open('/home/claude/xsec/cells/x11_robustness.py').read(), g)
