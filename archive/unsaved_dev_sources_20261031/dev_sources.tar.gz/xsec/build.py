import json, re, os
C = "/home/claude/xsec/cells"
order = [
 ("md", """# Part 4 — Cross-Section of Order Books, a Tick-Size Natural Experiment, 30-Second Depletion, and a Disclosure Test
This notebook runs the experiments that can still move both papers:

| Cell | Test | Paper | What it can show |
|---|---|---|---|
| X3 | T6 estimated on ~30 futures symbols, deep to thin | 2 | whether thinner books sit closer to (or across) the amplification threshold $C_3>0$ |
| X4 | depth mediation by liquidity tercile | 2 | whether a depth-carried overshoot appears in thin books |
| X5–X6 | **pre-registered** out-of-sample test in the thin tercile | 2 | whether $C_3$ forecasts next-hour adverse moves where books are thin |
| X7 | tick-size changes found in the data (difference-in-differences) | 2 | causal variation in refill $r$ |
| X8 | depletion at the ~30-second snapshot scale from every trade | 2 | whether the 1-minute "book refills the side being hit" result is an aggregation artefact |
| X9 | Binance top-trader vs all-account positions | 1 | what class-level disclosure buys: memory rates with vs without tagged data |
| X3 (Q columns) | feedback loop gain by symbol, with placebo | 1 | the feedback cross-section |

**Before running**
- Keep `USE_DRIVE = True` (cell X0). Everything is cached in Drive, so a disconnect only costs the current cell.
- The first run downloads about 30 symbols × 90 panel days (klines, depth, metrics), plus trade files for 5 symbols × 6 days. Expect 1–3 hours. `N_SYMBOLS = 20` makes it faster.
- **Run X5 before X6, then commit `prereg/P4_xsec.json` (for example to GitHub) before running X6.** X6 counts every time the 2025–2026 test period is opened; report that count in the paper.

**Rules:** do not change the X5 specification after running X6. If you must, disclose it. Whatever X6 shows goes in the paper."""),
 "x00_setup.py", "x01_universe.py", "x02_build.py",
 ("md", "## Training-period analysis (≤ 2024-12-31)"), "x03_cross_section.py", "x04_mediation.py",
 ("md", "## Pre-register, then test once on 2025–2026"), "x05_blocks_prereg.py", "x06_test.py",
 ("md", "## Exploratory: natural experiment and trade-level depletion"), "x07_tick_events.py", "x08_depletion_30s.py",
 ("md", "## Paper 1: disclosure test"), "x09_disclosure.py",
 ("md", "## Summary"), "x10_summary.py",
 ("md", """## How to read the results
| Test | Supports the theory if | If not |
|---|---|---|
| X3 | Spearman(log depth, mean $C_3$) < 0 with CI below 0; thin tercile has more days with $C_3>0$ | liquidity does not move books toward amplification |
| X4 | thin tercile: overshoot (B) CI > 0 and much smaller in (C) | no depth-carried overshoot even in thin books |
| **X6** | Clark–West p < 0.05 **and** ΔR² CI > 0 in the thin tercile | report the null; T6 does not forecast where books are thin |
| X7 | events where Δr and Δpeak move in opposite directions | report each event; few events are descriptive only |
| X8 | ε30 > 0 (CI above 0), at least for sweeps | the replenishment result is real, not an aggregation artefact |
| X9 | CI-width ratio (price-only / tagged) well above 1 | disclosure adds little in this market |

Send me `xsec_results.zip` when it finishes and I will put the results into both papers."""),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"},
      "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/xsec/Part4_CrossSection_Disclosure.ipynb", "w"), indent=1)
print(len(cells), "cells")
