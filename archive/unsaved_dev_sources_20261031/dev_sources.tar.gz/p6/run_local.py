import os, time, shutil
W = '/home/claude/p6/run'; os.makedirs(W, exist_ok=True); os.chdir(W)
shutil.rmtree(os.path.join(W, 'ceiling_suite_local'), ignore_errors=True)
g = {'__name__': '__main__'}; C = '/home/claude/p6/cells/'
def run(name):
    t = time.time(); print('\n####', name, flush=True)
    exec(compile(open(C + name).read(), name, 'exec'), g); print(f'-- {time.time()-t:.1f}s', flush=True)
run('z00_setup.py')
exec(open('/home/claude/xsec/debug_fake.py').read(), g)
f0, t0 = g['fresh_dates'], g['train_dates']
g['fresh_dates'] = lambda: f0()[::2]          # LOCAL ONLY: fewer days
g['train_dates'] = lambda: t0()[::2]
run('z01_functions.py')
exec("""THIN = _SYMS[5:]; MID = _SYMS[:5]; GROUP = {**{s: 'thin' for s in THIN}, **{s: 'mid' for s in MID}}; SYMBOLS = THIN + MID""", g)
for c in ['z03_prereg.py', 'z04_build.py', 'z05_blocks.py', 'z06_test.py', 'z07_summary.py']:
    run(c)
