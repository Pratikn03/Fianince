import json, re, os
C = "/home/claude/p6/cells"
order = [
 ("md", """# Part 6 — Confirmatory tests on fresh days (Papers 1 and 2)
Parts 4–5 used only the **10th and 24th** of each month. This notebook tests on the **3rd and 17th** of each month in 2025–2026: days **never downloaded or analysed**. Training reuses the cached 2023–2024 days, so only the fresh days are downloaded.

| Hypothesis | Paper | Question |
|---|---|---|
| **A** | 2 | Third replication: does C3 forecast thin-book tail moves on fresh days, now with price-impact controls built in? |
| **B** | 2 | Position-sizing backtest: does the guard's amplification multiple improve a volatility-scaled position limit? |
| **C** | 1 | Do prices identify the merged response but not the memory rates, while tagged long/short data identify the rates? |

**Rules:**
1. Run the cells one at a time (no "Run all").
2. **Z3 writes the pre-registration and downloads it to your computer. E-mail that file to yourself before running Z4.** That dated e-mail is the proof the plan was fixed before the data existed in your Drive.
3. Run Z6 **exactly once**.
4. Expected time: about 1–2 hours. The download is about 1,260 fresh symbol-days, then about 2,700 symbol-days of blocks."""),
 "z00_setup.py", "z01_functions.py",
 ("md", "## Symbols and pre-registration (before any fresh data)"), "z02_universe.py", "z03_prereg.py",
 ("md", "## Data and blocks"), "z04_build.py", "z05_blocks.py",
 ("md", "## The test: run ONCE"), "z06_test.py",
 ("md", "## Descriptives and download"), "z07_summary.py",
 ("md", """## How to read Z6
| Result | Meaning |
|---|---|
| A passes | Third independent confirmation (new days), with impact controls in the baseline. |
| B passes | The guard's theory adds value to the industry-standard volatility limit. This is the first real-data evidence for the guard. |
| C passes | Paper 1's core identification claim holds on real data. |

Send me `p6_results.zip`."""),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/outputs/Part6_FreshDays_Confirmatory.ipynb", "w"), indent=1)
print(len(cells), "cells")
