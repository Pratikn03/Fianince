# ============================================================================
# CELL Z7 — TRAINING DESCRIPTIVES AND DOWNLOAD
# ============================================================================
Gtr = G6[G6["split"] == "train"]
desc6 = {"train_TLR": {r: es95(Gtr["L_" + r]) / Gtr["q_" + r].mean() for r in rules6},
         "train_corr_risk_vs_MAE": {r: float(Gtr[["R_" + r, "MAE_60"]].corr(method="spearman").iloc[0, 1]) for r in rules6},
         "median_S60": float(thin6["S60"].median()), "median_gain_multiple": float(thin6["gain_multiple"].median())}
print(json.dumps(desc6, indent=1))
record("Z7_descriptives", None, "real-data", desc6)
zp6 = os.path.join(BASE, "p6_results.zip")
with zipfile.ZipFile(zp6, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "Z*.json")) + [os.path.join(RESULTS, "p6_manifest_sha256.csv"), p6_path, pth6]:
        if os.path.exists(fp):
            z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp6)
if IN_COLAB:
    from google.colab import files
    files.download(zp6)
