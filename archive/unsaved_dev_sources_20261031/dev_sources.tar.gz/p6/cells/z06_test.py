# ============================================================================
# CELL Z6 — THE CONFIRMATORY TESTS (RUN ONCE; every run is counted)
# ============================================================================
assert hashlib.sha256(open(p6_path).read().encode()).hexdigest() == P6_HASH, "spec changed after registration"
pth6 = os.path.join(PREREG, "test_set_unlocks_p6.json")
n_unl6 = (json.load(open(pth6))["n"] if os.path.exists(pth6) else 0) + 1
json.dump({"n": n_unl6, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": P6_HASH}, open(pth6, "w"))
thin6, mid6 = ZB[ZB["group"] == "thin"], ZB[ZB["group"] == "mid"]
CTRL6 = CTRL + IMPACT
def holm(pd_):
    items = sorted((v if np.isfinite(v) else 1.0, k) for k, v in pd_.items()); m = len(items); out, run = {}, 0.0
    for j, (p_, k) in enumerate(items):
        run = max(run, min(1.0, p_ * (m - j))); out[k] = run
    return out

# ---- A: third replication, with impact controls -------------------------------------------
A_res = evaluate_g(thin6, "MAE_60", "C3_hat", CTRL6, level=0.975)
A_pass = bool(np.isfinite(A_res.get("clark_west_p", np.nan)) and A_res["clark_west_p"] < 0.025 and A_res["delta_r2_ci"][0] > 0)

# ---- B: guard backtest -----------------------------------------------------------------------
THETA6, theta_tr = choose_theta(thin6)
print("theta chosen on training data:", THETA6, {k: round(v, 3) for k, v in theta_tr.items()})
G6, rules6 = guard_frame(thin6, {"amp_vol": (lambda X: X["rv_360"] * X["gain_multiple"] ** THETA6)})
B_res = guard_compare(G6, rules6, ref="vol", level=0.975)
B_pass = bool(B_res["vs_ref"]["amp_vol"]["ci"][1] < 0)
B_peak = guard_compare(G6, ["guard_summed", "guard_peak"], ref="guard_peak", level=0.95, seed=78)

# ---- C: Paper 1 identification on fresh days ----------------------------------------------
FRESH_SET = set(fresh_dates()); C_by = {}
for s in SYMBOLS:
    r_ = ident_symbol(s, sorted(d for (s2, d) in OK if s2 == s and d in FRESH_SET))
    if r_ is not None:
        r_["passes"] = bool(r_["width_ratio"] > 10 and r_["rates_unidentified"] and r_["M0_identified"])
        C_by[s] = r_
        print(f"  {s:11s} width ratio {r_['width_ratio']:7.1f}  price-only width {r_['width_price_only']:.3f}  "
              f"M0 CI {np.round(r_['price_only']['M0_ci'], 4)}  pass={r_['passes']}")
C_share = float(np.mean([v["passes"] for v in C_by.values()])) if C_by else np.nan
C_pass = bool(len(C_by) >= 10 and C_share >= 0.8)

# ---- secondary, Paper 2 (Holm) -------------------------------------------------------------
sec2 = {"thin: MAE | term_momentum": evaluate_g(thin6, "MAE_60", "term_momentum", CTRL6),
        "thin: MAE | term_reversion": evaluate_g(thin6, "MAE_60", "term_reversion", CTRL6),
        "thin: MAE | term_depth": evaluate_g(thin6, "MAE_60", "term_depth", CTRL6),
        "thin: MAE | gain_multiple": evaluate_g(thin6, "MAE_60", "gain_multiple", CTRL6),
        "thin: MAE | log_halflife": evaluate_g(thin6, "MAE_60", "log_halflife", CTRL6),
        "mid: MAE | C3_hat": evaluate_g(mid6, "MAE_60", "C3_hat", CTRL6),
        "thin: MAE | C3_flow": evaluate_g(thin6, "MAE_60", "C3_flow", CTRL6)}
p_sec2 = {k: v.get("clark_west_p", np.nan) for k, v in sec2.items()}
# guard secondaries: one-sided bootstrap "p" = share of draws at or above 0
for k, (a, ref, src) in {"guard_summed vs vol": ("guard_summed", "vol", B_res), "guard_peak vs vol": ("guard_peak", "vol", B_res), "static vs vol": ("static", "vol", B_res),
                         "guard_summed vs guard_peak": ("guard_summed", "guard_peak", B_peak)}.items():
    p_sec2[k] = 1 - src["vs_ref"][a]["share_boot_below_0"]
h2 = holm(p_sec2)
for k in sec2:
    sec2[k]["holm_p"] = h2[k]

# ---- secondary, Paper 1 (Holm) -------------------------------------------------------------
both6 = ZB[ZB["group"].isin(["thin", "mid"])]
sec1 = {"thin+mid: MAE | tagged positions": evaluate_g(both6, "MAE_60", TAGGED, CTRL6)}
cls_diff = {s: bool(v["top_minus_all_rate_ci"][0] > 0 or v["top_minus_all_rate_ci"][1] < 0) for s, v in C_by.items()}
h1 = holm({"tagged": sec1["thin+mid: MAE | tagged positions"].get("clark_west_p", np.nan)})
sec1["thin+mid: MAE | tagged positions"]["holm_p"] = h1["tagged"]

# ---- print --------------------------------------------------------------------------------
sh = lambda v: {k: (round(v[k], 5) if isinstance(v.get(k), float) else v.get(k)) for k in
                ["n_train", "n_test", "n_symbols", "delta_r2", "delta_r2_ci", "delta_auc_ci", "clark_west_t", "clark_west_p", "holm_p", "coef_candidates_train", "skipped"] if k in v}
print("\n=== A  third replication (thin, + impact controls):", "PASS" if A_pass else "FAIL"); print(sh(A_res))
print("\n=== B  guard backtest (test, thin):", "PASS" if B_pass else "FAIL")
print(pd.DataFrame(B_res["point"]).T.round(4).to_string())
for r, v in B_res["vs_ref"].items():
    print(f"   {r:13s} log TLR - log TLR_vol = {v['log_TLR_minus_ref']:+.4f}  CI {np.round(v['ci'], 4)}")
print(f"   summed vs peak guard: {B_peak['vs_ref']['guard_summed']['log_TLR_minus_ref']:+.4f} CI {np.round(B_peak['vs_ref']['guard_summed']['ci'], 4)}")
print(f"\n=== C  Paper 1 identification: {sum(v['passes'] for v in C_by.values())} of {len(C_by)} symbols pass "
      f"({C_share:.0%}) ->", "PASS" if C_pass else "FAIL")
print("\nsecondary, Paper 2:")
for k, v in sec2.items():
    print("  ", k, sh(v))
print("   guard secondaries (bootstrap one-sided p):", {k: round(p_sec2[k], 4) for k in ["guard_summed vs vol", "guard_peak vs vol", "static vs vol", "guard_summed vs guard_peak"]})
print("secondary, Paper 1:", sh(sec1["thin+mid: MAE | tagged positions"]))
print(f"   classes differ (top position vs all accounts) in {sum(cls_diff.values())} of {len(cls_diff)} symbols")

record("Z6_A_replication3", A_pass, "real-data", {"result": A_res, "test_set_unlocks": n_unl6, "prereg_sha256": P6_HASH},
       criterion=PREREG_P6["A_primary"]["success"])
record("Z6_B_guard_backtest", B_pass, "real-data", {"result": B_res, "theta": THETA6, "theta_train_TLR": theta_tr, "summed_vs_peak": B_peak, "test_set_unlocks": n_unl6,
       "prereg_sha256": P6_HASH}, criterion=PREREG_P6["B_primary"]["success"])
record("Z6_C_identification", C_pass, "real-data", {"by_symbol": C_by, "share_pass": C_share, "test_set_unlocks": n_unl6,
       "prereg_sha256": P6_HASH}, criterion=PREREG_P6["C_primary"]["success"])
record("Z6_secondary", None, "real-data", {"paper2": sec2, "paper2_holm_p": h2, "paper1": sec1, "classes_differ": cls_diff,
       "test_set_unlocks": n_unl6}, note="Holm-adjusted within each paper. Report whatever they show.")
