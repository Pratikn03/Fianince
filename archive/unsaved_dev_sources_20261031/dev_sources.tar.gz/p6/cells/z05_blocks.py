# ============================================================================
# CELL Z5 — HOURLY BLOCKS FOR ALL SYMBOL-DAYS (no outcome is looked at here)
# ============================================================================
BLK6 = os.path.join(XDATA, f"blocks_p6_{len(SYMBOLS)}sym.parquet")
if os.path.exists(BLK6) and set(map(tuple, pd.read_parquet(BLK6)[["symbol", "date"]].drop_duplicates().to_numpy())) >= set(OK):
    ZB = pd.read_parquet(BLK6)
else:
    rows = []
    for i, (s, d) in enumerate(OK):
        rows += day_blocks6(s, d, FLOW_SCALE[s])
        if (i + 1) % 200 == 0:
            print(f"   blocks: {i+1}/{len(OK)}")
    ZB = pd.DataFrame(rows); ZB.to_parquet(BLK6)
ZB["group"] = ZB["symbol"].map(GROUP)
ZB["split"] = np.where(ZB["date"] <= TRAIN_END, "train", "test")
ZB["kappa_sq"] = ZB["kappa_hat"] ** 2
ZB = winsor_train(ZB, IMPACT)
assert set(ZB.loc[ZB["split"] == "test", "date"]) <= set(fresh_dates()), "a non-fresh day entered the test set"
print(ZB.groupby(["group", "split"]).size().unstack())
record("Z3_blocks", None, "audit", {"blocks": ZB.groupby(["group", "split"]).size().unstack().to_dict(),
       "coverage": {c: float(ZB[c].notna().mean()) for c in ["C3_hat", "S60", "U6"] + IMPACT + TAGGED}})
