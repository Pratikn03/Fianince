import os, time, shutil
W = '/home/claude/p9/run'; os.chdir(W); shutil.rmtree(os.path.join(W, 'ceiling_suite_local'), ignore_errors=True)
g = {'__name__': '__main__'}; C = '/home/claude/p9/cells/'
def run(name):
    t = time.time(); print('\n####', name, flush=True)
    exec(compile(open(C + name).read(), name, 'exec'), g); print(f'-- {time.time()-t:.1f}s', flush=True)
run('u00_setup.py'); exec(open('/home/claude/xsec/debug_fake.py').read(), g)
f0, t0 = g['fresh_dates'], g['train_dates']; g['fresh_dates'] = lambda: f0()[::3]; g['train_dates'] = lambda: t0()[::3]
run('u01_functions.py')
exec("""THIN = _SYMS[5:]; MID = _SYMS[:5]; GROUP = {**{s: 'thin' for s in THIN}, **{s: 'mid' for s in MID}}; SYMBOLS = THIN + MID""", g)
for c in ['u03_prereg.py', 'u04_build.py', 'u05_blocks.py', 'u06_test.py']:
    run(c)
