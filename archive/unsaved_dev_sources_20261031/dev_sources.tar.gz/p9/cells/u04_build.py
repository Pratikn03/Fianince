# ============================================================================
# CELL U4 — DATA: cached training days + FRESH test days (downloaded now for the first time)
# ============================================================================
assert os.path.exists(p9_path) and hashlib.sha256(open(p9_path).read().encode()).hexdigest() == P9_HASH, "run U3 first"
TRAIN_D, FRESH_D = train_dates(), fresh_dates()
jobs = [(s, d) for s in SYMBOLS for d in TRAIN_D + FRESH_D]
n_cached = sum(os.path.exists(os.path.join(MIN_DIR, s, f"{d}.json")) for s, d in jobs)
print(f"{len(jobs)} symbol-days ({n_cached} already cached; fresh ones are downloaded now)")
PANEL, VST = {}, []
with ThreadPoolExecutor(THREADS) as ex:
    futs = {ex.submit(get_day, s, d): (s, d) for s, d in jobs}
    for i, f in enumerate(as_completed(futs), 1):
        s, d = futs[f]
        try:
            df, st = f.result(); VST.append(st)
            if df is not None:
                PANEL[(s, d)] = df
        except Exception as e:
            VST.append({"symbol": s, "date": d, "reason": f"error: {e}"})
        if i % 300 == 0:
            print(f"   {i}/{len(jobs)}")
vst = pd.DataFrame(VST)
vst["depth_day_ok"] = vst.get("depth_day_ok", pd.Series(False, index=vst.index)).fillna(False).astype(bool)
OK = sorted([(r.symbol, r.date) for r in vst.itertuples() if r.depth_day_ok and (r.symbol, r.date) in PANEL])
FLOW_SCALE = {}
for s in SYMBOLS:
    v = [np.nanmedian(np.abs(PANEL[(s, d)]["flow"].to_numpy())) for d in TRAIN_D if (s, d) in OK]
    FLOW_SCALE[s] = float(np.nanmedian(v)) if v and np.nanmedian(v) > 0 else 1.0
pd.DataFrame(DL_LOG).to_csv(os.path.join(RESULTS, "p9_manifest_sha256.csv"), index=False)
okf = [(s, d) for (s, d) in OK if d in set(FRESH_D)]
record("U2_build", None, "audit", {"symbol_days_requested": len(jobs), "valid": len(OK), "valid_fresh": len(okf),
       "valid_train": len(OK) - len(okf), "flow_scale": FLOW_SCALE,
       "by_symbol": vst.groupby("symbol")["depth_day_ok"].agg(["sum", "count"]).to_dict("index")})
