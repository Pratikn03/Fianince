# ============================================================================
# CELL U3 — PRE-REGISTRATION (run BEFORE U4 downloads any fresh day; U4 refuses to run without it)
# E-mail prereg/P9_volbench.json to yourself before running U4.
# ============================================================================
BASE9 = CTRL + IMPACT + VOLBENCH
PREREG_P9 = {
    "question": "Does C3_hat forecast next-hour MAE in thin books beyond a volatility-forecasting baseline "
                "(HAR-type realized volatility, EWMA volatility forecast, last hour's MAE, hour-of-day fixed effects) "
                "and price-impact controls?",
    "data": "Binance USD-M futures; training = cached 10th/24th of each month 2023-2024; test = FRESH days, the 6th and 20th of "
            "each month, 2025-01-01 to 2026-09-30, never used in Parts 1-8; validation V1-V5 unchanged",
    "symbols": {"thin": THIN, "mid": MID},
    "unit": "symbol-hour blocks, hours 6-23 UTC; features from minutes before t on the same day; outcome MAE over (t, t+60]",
    "baseline": BASE9 + ["symbol fixed effects"],
    "baseline_definitions": {"rv_15/rv_60/rv_360/rv_day": "std of 1-minute log-price changes over the last 15, 60, 360 minutes and since 00:00",
                             "ewma_vol": "RiskMetrics EWMA (lambda 0.94) of squared 1-minute changes, at t-1",
                             "mae_lag60": "maximum absolute deviation from the price at t-61 over (t-61, t-1]",
                             "hr_h": "hour-of-day dummies, hours 7-23 (6 omitted)"},
    "primary": {"sample": "thin (20 symbols)", "outcome": "MAE_60", "candidate": "C3_hat (winsorized at train 1%/99%)",
                "success": "Clark-West one-sided p < 0.05 AND 95% date-block bootstrap CI of dR2 above 0"},
    "secondary": ["thin: MAE | S60 (summed |impulse response| over 60 min; the guard statistic)",
                  "thin: MAE | gain_multiple (unit-free)", "thin: MAE | log_halflife (unit-free)",
                  "thin: MAE | term_reversion", "thin: MAE | term_momentum", "thin: MAE | C3_flow",
                  "mid: MAE | C3_hat (predicted: no effect)"],
    "inference": "Clark-West (Newey-West 6 lags); 2,000 date-block bootstrap draws (all symbols on a date together); secondary Holm-adjusted",
    "runs": "U6 is run once; every run is counted in prereg/test_set_unlocks_p9.json",
    "previous_hashes": {"part4": "5910b6b4d90aad457f03eb01d27cb0141933ff1d70dd93d85a98663f73e36020",
                        "part5": "6aa8e2c03d7979402769f0b3cab22d4709da5ade93b709cf05f9e675c0a063fa",
                        "part6": "65acda36186147bd6e959ce8c56b9958b7a7f94a01f8784bc82f2b1512360215"},
}
spec_txt9 = json.dumps(PREREG_P9, indent=2, sort_keys=True)
P9_HASH = hashlib.sha256(spec_txt9.encode()).hexdigest()
p9_path = os.path.join(PREREG, "P9_volbench.json")
if not os.path.exists(p9_path):
    open(p9_path, "w").write(spec_txt9); print("pre-registration written:", p9_path)
elif hashlib.sha256(open(p9_path).read().encode()).hexdigest() != P9_HASH:
    raise RuntimeError("The spec differs from the registered file. Do not edit the spec after registering it.")
print("spec SHA-256:", P9_HASH)
if IN_COLAB:
    from google.colab import files
    files.download(p9_path)
print("Keep a dated copy of P9_volbench.json (e-mail it to yourself) BEFORE running U4.")
