# ============================================================================
# CELL U6 — THE TEST (RUN ONCE; every run is counted)
# ============================================================================
assert hashlib.sha256(open(p9_path).read().encode()).hexdigest() == P9_HASH, "spec changed after registration"
pth9 = os.path.join(PREREG, "test_set_unlocks_p9.json")
n_unl9 = (json.load(open(pth9))["n"] if os.path.exists(pth9) else 0) + 1
json.dump({"n": n_unl9, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": P9_HASH}, open(pth9, "w"))
def holm(pd_):
    items = sorted((v if np.isfinite(v) else 1.0, k) for k, v in pd_.items()); m = len(items); out, run = {}, 0.0
    for j, (p_, k) in enumerate(items):
        run = max(run, min(1.0, p_ * (m - j))); out[k] = run
    return out
thin9, mid9 = UB[UB["group"] == "thin"], UB[UB["group"] == "mid"]
prim9 = evaluate_g(thin9, "MAE_60", "C3_hat", BASE9)
ok9 = bool(np.isfinite(prim9.get("clark_west_p", np.nan)) and prim9["clark_west_p"] < 0.05 and prim9["delta_r2_ci"][0] > 0)
sec9 = {"thin: MAE | S60": evaluate_g(thin9, "MAE_60", "S60", BASE9),
        "thin: MAE | gain_multiple": evaluate_g(thin9, "MAE_60", "gain_multiple", BASE9),
        "thin: MAE | log_halflife": evaluate_g(thin9, "MAE_60", "log_halflife", BASE9),
        "thin: MAE | term_reversion": evaluate_g(thin9, "MAE_60", "term_reversion", BASE9),
        "thin: MAE | term_momentum": evaluate_g(thin9, "MAE_60", "term_momentum", BASE9),
        "thin: MAE | C3_flow": evaluate_g(thin9, "MAE_60", "C3_flow", BASE9),
        "mid: MAE | C3_hat": evaluate_g(mid9, "MAE_60", "C3_hat", BASE9)}
h9 = holm({k: v.get("clark_west_p", np.nan) for k, v in sec9.items()})
for k in sec9:
    sec9[k]["holm_p"] = h9[k]
# descriptive (not a test): how much the volatility benchmarks themselves add over the Part 6 baseline
bench_gain = evaluate_g(thin9, "MAE_60", VOLBENCH, CTRL + IMPACT, B=500)
sh = lambda v: {k: (round(v[k], 5) if isinstance(v.get(k), float) else v.get(k)) for k in
                ["n_train", "n_test", "n_symbols", "n_test_dates", "r2_base", "delta_r2", "delta_r2_ci", "delta_auc_ci", "clark_west_t", "clark_west_p", "holm_p", "coef_candidates_train", "skipped"] if k in v}
print("=== PRIMARY (thin, C3 beyond volatility benchmarks):", "PASS" if ok9 else "FAIL"); print(sh(prim9))
for k, v in sec9.items():
    print(k, sh(v))
print("\n(descriptive) volatility benchmarks over the Part 6 baseline:", sh(bench_gain))
record("U6_volbench_test", ok9, "real-data", {"primary": prim9, "secondary": sec9, "holm_p": h9, "benchmarks_over_p6_baseline": bench_gain,
       "prereg_sha256": P9_HASH, "test_set_unlocks": n_unl9}, criterion=PREREG_P9["primary"]["success"])
zp9 = os.path.join(BASE, "p9_results.zip")
with zipfile.ZipFile(zp9, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "U*.json")) + [os.path.join(RESULTS, "p9_manifest_sha256.csv"), p9_path, pth9]:
        if os.path.exists(fp):
            z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp9)
if IN_COLAB:
    from google.colab import files
    files.download(zp9)
