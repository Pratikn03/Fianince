# ============================================================================
# CELL U5 — HOURLY BLOCKS WITH THE VOLATILITY BENCHMARKS (no outcome is looked at here)
# ============================================================================
BLK9 = os.path.join(XDATA, f"blocks_p9_{len(SYMBOLS)}sym.parquet")
if os.path.exists(BLK9) and set(map(tuple, pd.read_parquet(BLK9)[["symbol", "date"]].drop_duplicates().to_numpy())) >= set(OK):
    UB = pd.read_parquet(BLK9)
else:
    rows = []
    for i, (s, d) in enumerate(OK):
        rows += day_blocks9(s, d, FLOW_SCALE[s])
        if (i + 1) % 200 == 0:
            print(f"   blocks: {i+1}/{len(OK)}")
    UB = pd.DataFrame(rows); UB.to_parquet(BLK9)
UB["group"] = UB["symbol"].map(GROUP)
UB["split"] = np.where(UB["date"] <= TRAIN_END, "train", "test")
UB["kappa_sq"] = UB["kappa_hat"] ** 2
UB = winsor_train(UB, IMPACT + ["rv_15", "rv_day", "ewma_vol", "mae_lag60"])
assert set(UB.loc[UB["split"] == "test", "date"]) <= set(fresh_dates()), "a non-fresh day entered the test set"
print(UB.groupby(["group", "split"]).size().unstack())
record("U3_blocks", None, "audit", {"blocks": UB.groupby(["group", "split"]).size().unstack().to_dict(),
       "coverage": {c: float(UB[c].notna().mean()) for c in ["C3_hat", "S60", "ewma_vol", "mae_lag60", "rv_day"]}})
