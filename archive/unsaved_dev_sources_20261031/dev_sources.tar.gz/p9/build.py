import json, re, os
C = "/home/claude/p9/cells"
order = [
 ("md", """# Part 9 — Does C3 survive a volatility-forecasting baseline? (Paper 2)
A referee's strongest objection: the thin-book result may only forecast **future volatility**, which standard models already do. This notebook adds the standard volatility forecasts to the baseline and tests C3 again, on **new untouched days (the 6th and 20th of each month, 2025–2026)**. The baseline includes:
- realized volatility over 15 minutes, 1 hour, 6 hours and since midnight (HAR-type);
- an EWMA (RiskMetrics) volatility forecast;
- last hour's adverse excursion;
- hour-of-day fixed effects;
- the four price-impact controls.

**Rules:**
1. Run cells one at a time.
2. **U3 downloads the pre-registration: e-mail it to yourself before running U4.**
3. Run U6 **once**; it zips and downloads the results.

Expected time: about 1–1.5 hours. It reuses the Drive cache, so only about 1,260 fresh symbol-days are downloaded."""),
 "u00_setup.py", "u01_functions.py",
 ("md", "## Symbols and pre-registration (before any fresh data)"), "u02_universe.py", "u03_prereg.py",
 ("md", "## Data and blocks"), "u04_build.py", "u05_blocks.py",
 ("md", "## The test: run ONCE"), "u06_test.py",
 ("md", """## How to read U6
| Result | Meaning for Paper 2 |
|---|---|
| Primary passes | C3 carries information beyond standard volatility forecasting. This closes the biggest referee objection. |
| Primary fails, but S60 or the reversion half-life passes | The guard's own statistic carries the information; the paper is reframed around S. |
| Everything fails | The thin-book result was mostly volatility persistence; Paper 2's empirical core must be rewritten. |

Send me `p9_results.zip`."""),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/outputs/Part9_VolatilityBenchmark.ipynb", "w"), indent=1)
print(len(cells), "cells")
