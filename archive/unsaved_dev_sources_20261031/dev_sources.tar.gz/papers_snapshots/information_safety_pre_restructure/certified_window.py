"""Outward-valid endpoints for the finite-window interval of Theorem thm:window (blueprint D8/E05; Paper 2, Lemma lem:certnum).

Weak duality: for any polynomial p of degree <= n-1 with p >= f on [0, rbar] (f(r) = 1/(1-r)), every measure M on [0, rbar]
with moments k_0..k_{n-1} has  Phi(M) = int f dM <= int p dM = sum_j c_j k_j ; with p <= f the inequality reverses.
The Hermite interpolant of f at the nodes of the upper (lower) principal representation, with double conditions at interior
nodes, satisfies p >= f (p <= f) and makes the bound exact (Markov-Krein duality). We

  1. compute that interpolant in 60-digit arithmetic and round its coefficients to doubles,
  2. shift it by a slack eps*k_0 (so the inequality becomes strict),
  3. VERIFY p + eps >= f (or p - eps <= f) on [0, rbar] with outward-rounded interval arithmetic and adaptive bisection, and
  4. evaluate sum_j c_j k_j with outward rounding.

The result is an enclosure [Phi_-^cert, Phi_+^cert] that contains the exact sharp interval whatever the floating-point
errors in steps 1-2 (they can only make the bound looser, never invalid), and is within about 2 eps k_0 of it.
"""
import mpmath as mp
import numpy as np
from interval import IV
from markov_krein import principal

mp.mp.dps = 60


def hermite_coeffs(at, rbar, deg):
    """Monomial coefficients (mp) of the degree-`deg` polynomial interpolating f at the nodes of `at`, with derivative
    conditions at interior nodes (0 < x < rbar)."""
    f = lambda x: 1 / (1 - x); fp = lambda x: 1 / (1 - x) ** 2
    rows, rhs = [], []
    for x, _ in at:
        x = mp.mpf(x)
        rows.append([x ** j for j in range(deg + 1)]); rhs.append(f(x))
        if mp.mpf(0) + mp.mpf("1e-40") < x < mp.mpf(rbar) - mp.mpf("1e-40"):
            rows.append([j * x ** (j - 1) if j else mp.mpf(0) for j in range(deg + 1)]); rhs.append(fp(x))
    if len(rows) != deg + 1:
        raise ValueError(f"{len(rows)} interpolation conditions for degree {deg}")
    c = mp.lu_solve(mp.matrix(rows), mp.matrix(rhs))
    return [c[j] for j in range(deg + 1)]


def _horner_iv(coef, X):
    acc = IV(np.full_like(X.lo, coef[-1]))
    for c in coef[-2::-1]:
        acc = acc * X + c
    return acc


def _dhorner_iv(coef, X):
    d = [j * c for j, c in enumerate(coef)][1:]
    return _horner_iv(d, X) if d else IV(np.zeros_like(X.lo))


def verify_sign(coef, rbar, upper, slack, max_boxes=400000):
    """Prove G(x) = p(x) + slack - f(x) > 0 (upper) or G(x) = f(x) - p(x) + slack > 0 (lower) for all x in [0, rbar], with
    the mean-value form G(X) in G(m) + G'(X)(X - m) evaluated in outward-rounded interval arithmetic, and adaptive bisection."""
    sg = 1.0 if upper else -1.0
    boxes = [(0.0, float(np.nextafter(rbar, np.inf)))]
    n = 0
    while boxes:
        if n > max_boxes:
            return False, n
        lo = np.array([b[0] for b in boxes]); hi = np.array([b[1] for b in boxes])
        X = IV(lo, hi); M = IV(0.5 * (lo + hi)); n += len(boxes)
        Gm = (_horner_iv(coef, M) - 1.0 / (1.0 - M)) * sg + slack
        dG = (_dhorner_iv(coef, X) - 1.0 / (1.0 - X).sq()) * sg
        G = Gm + dG * (X - M)
        G0 = ((_horner_iv(coef, X) - 1.0 / (1.0 - X)) * sg + slack)          # natural form; keep the better lower bound
        bad = np.maximum(G.lo, G0.lo) <= 0
        if not np.any(bad):
            return True, n
        new = []
        for a, b in zip(lo[bad], hi[bad]):
            m = 0.5 * (a + b)
            if m <= a or m >= b:
                return False, n
            new += [(a, m), (m, b)]
        boxes = new
    return True, n


def certified_phi_bounds(k, rbar, rel_slack=1e-11):
    """Outward-valid [Phi_lo, Phi_hi] for all measures on [0, rbar] with moments k[0..n-1]. Returns a dict with the certified
    endpoints, the high-precision principal-representation values and the verification effort."""
    n = len(k); deg = n - 1
    kk = [mp.mpf(x) for x in k]
    out = {}
    for which, upper in (("upper", True), ("lower", False)):
        at = principal(kk, rbar, which)
        exact = sum(w / (1 - x) for x, w in at)
        coef_mp = hermite_coeffs(at, rbar, deg)
        coef = [float(c) for c in coef_mp]
        # slack: a relative margin, and at least what rounding the coefficients to doubles can cost
        slack = max(rel_slack * float(abs(exact) / kk[0]), 64 * np.finfo(float).eps * float(sum(abs(c) * rbar ** j for j, c in enumerate(coef_mp))))
        ok, nbox = verify_sign(coef, rbar, upper, slack)
        tries = 0
        while not ok and tries < 4:                     # widen the slack if rounding of the coefficients needs it
            slack *= 100; tries += 1
            ok, nb2 = verify_sign(coef, rbar, upper, slack); nbox += nb2
        if not ok:
            out[which] = {"certified": None, "exact_hp": float(exact), "boxes": nbox}
            continue
        Kv = IV.enclose(np.array([float(x) for x in k]))
        tot = IV(0.0)
        for j, c in enumerate(coef):
            tot = tot + IV(np.array(c)) * IV(Kv.lo[j], Kv.hi[j])
        if upper:
            bound = float(np.nextafter((tot + IV(slack) * IV(Kv.lo[0], Kv.hi[0])).hi, np.inf))
        else:
            bound = float(np.nextafter((tot - IV(slack) * IV(Kv.lo[0], Kv.hi[0])).lo, -np.inf))
        out[which] = {"certified": bound, "exact_hp": float(exact), "boxes": nbox, "slack": slack}
    return {"Phi_lo_cert": out["lower"]["certified"], "Phi_hi_cert": out["upper"]["certified"],
            "Phi_lo_hp": out["lower"]["exact_hp"], "Phi_hi_hp": out["upper"]["exact_hp"],
            "boxes_checked": out["lower"]["boxes"] + out["upper"]["boxes"]}
