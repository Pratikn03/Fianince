"""Finite-sample certificates for the summed response from reset episodes (blueprint D8; Paper 2, Proposition prop:hotelling).

Contract (O1'): N independent Gaussian episodes h^(e) = (h_0..h_{T-1}) + noise, with an UNKNOWN covariance across taps (any
within-episode correlation). The O1 certificate of Theorem thm:certcost assumes independent taps with known sigma; here:

  t-certificate:  S_up = mean_e X_e + t_{N-1,1-gamma} sd(X_e)/sqrt(N) + tail,  X_e = sum_{t<T} h_t^(e)   (exact coverage)
  Hotelling:      {m : N (hbar - m)' Shat^{-1} (hbar - m) <= T^2_crit},  T^2_crit = T(N-1)/(N-T) F_{T,N-T}(1-gamma),
                  exact simultaneous coverage for the whole mean window; c'm <= c'hbar + sqrt(T^2_crit c'Shat c / N) for all c.
"""
import numpy as np
from scipy import stats


def t_certificate(H, gamma=0.05, tail=0.0):
    X = H.sum(axis=1); N = len(X)
    return float(X.mean() + stats.t.ppf(1 - gamma, N - 1) * X.std(ddof=1) / np.sqrt(N) + tail)


def z_certificate_O1(H, sigma, gamma=0.05, tail=0.0):
    """The Theorem thm:certcost certificate (independent taps, known per-tap sigma)."""
    N, T = H.shape
    return float(H.mean(0).sum() + stats.norm.ppf(1 - gamma) * sigma * np.sqrt(T / N) + tail)


def hotelling_crit(T, N, gamma=0.05):
    if N <= T:
        raise ValueError("Hotelling region needs N > T")
    return T * (N - 1) / (N - T) * stats.f.ppf(1 - gamma, T, N - T)


def hotelling_upper(H, c, gamma=0.05, tail=0.0):
    """Simultaneous upper bound for the linear functional c'm (valid for all c at once)."""
    N, T = H.shape
    hb = H.mean(0); Sh = np.cov(H, rowvar=False)
    return float(c @ hb + np.sqrt(hotelling_crit(T, N, gamma) * (c @ Sh @ c) / N) + tail)


def simulate_coverage(h_true, N, reps, noise, gamma=0.05, sigma_nominal=None, seed=0):
    """Coverage of the three certificates for the finite-horizon sum S_T = sum h_true under a noise generator
    noise(R, N, T) -> (N, T) array. Returns coverage and mean excess for each."""
    R = np.random.default_rng(seed); T = len(h_true); S = float(np.sum(h_true)); c = np.ones(T)
    cov = {"z_O1": 0, "t": 0, "hotelling": 0}; exc = {k: [] for k in cov}
    for _ in range(reps):
        H = h_true[None, :] + noise(R, N, T)
        b = {"z_O1": z_certificate_O1(H, sigma_nominal, gamma), "t": t_certificate(H, gamma),
             "hotelling": hotelling_upper(H, c, gamma) if N > T else np.nan}
        for k, v in b.items():
            if np.isfinite(v):
                cov[k] += v >= S; exc[k].append(v - S)
    return {k: {"coverage": cov[k] / reps if exc[k] else None, "mean_excess": float(np.mean(exc[k])) if exc[k] else None}
            for k in cov}


def noise_iid(sigma):
    return lambda R, N, T: sigma * R.standard_normal((N, T))


def noise_ar_taps(sigma, phi):
    """Within-episode AR(1) correlation across taps (stationary marginal sd sigma)."""
    def g(R, N, T):
        e = R.standard_normal((N, T)); x = np.empty((N, T)); x[:, 0] = e[:, 0]
        for t in range(1, T):
            x[:, t] = phi * x[:, t - 1] + np.sqrt(1 - phi ** 2) * e[:, t]
        return sigma * x
    return g


def noise_heavy(sigma, df=3):
    sc = np.sqrt((df - 2) / df)
    return lambda R, N, T: sigma * sc * R.standard_t(df, (N, T))


def noise_dependent_episodes(sigma, phi_tap, phi_ep):
    """Episodes themselves AR(1)-dependent (violates independence across experiments)."""
    base = noise_ar_taps(sigma, phi_tap)
    def g(R, N, T):
        x = base(R, N, T); y = np.empty_like(x); y[0] = x[0]
        for e in range(1, N):
            y[e] = phi_ep * y[e - 1] + np.sqrt(1 - phi_ep ** 2) * x[e]
        return y
    return g
