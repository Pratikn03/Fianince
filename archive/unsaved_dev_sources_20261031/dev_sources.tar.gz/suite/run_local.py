import sys, glob, os, time, traceback
os.chdir('/home/claude')
cells = sys.argv[1:] or sorted(glob.glob('/home/claude/suite/cells/c*.py'))
g = {'__name__':'__main__'}
for c in cells:
    print('\n'+'#'*20, os.path.basename(c))
    t=time.time()
    try:
        exec(compile(open(c).read(), c, 'exec'), g)
    except Exception:
        traceback.print_exc()
    print(f'-- {time.time()-t:.1f}s')
