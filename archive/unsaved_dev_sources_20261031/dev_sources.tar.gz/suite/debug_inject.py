# LOCAL DEBUG ONLY — never part of the notebook. Exercises the real-data code paths
# with synthetic klines because data.binance.vision is not reachable from this sandbox.
_R = np.random.default_rng(1)
def load_day(sym, date):
    n = 86400
    rr = np.random.default_rng(abs(hash(date)) % 2**32)
    vol = 1.0 + (3.0 if date in CRASH_DAYS.values() or date in OOS_CRASH_DAYS.values() else 0.0)
    f = np.zeros(n); x = np.zeros(n); y = 0.0
    e = rr.standard_t(5, n) * vol
    u = rr.normal(0, 1, n)
    for t in range(2, n):
        f[t] = 0.6 * f[t-1] + u[t] + 0.05 * (x[t-1] - x[t-2])
        x[t] = x[t-1] + 0.3 * f[t] + e[t] * 0.5
    close = 30000 * np.exp(x / 1e4)
    df = pd.DataFrame({"close": close, "flow_q": f * 1e5, "flow_b": f * 3, "vol_q": np.abs(f) * 2e5 + 1e5},
                      index=pd.Index(np.arange(n), name="sec"))
    return df
print("!! DEBUG: synthetic load_day injected (local test harness only)")
