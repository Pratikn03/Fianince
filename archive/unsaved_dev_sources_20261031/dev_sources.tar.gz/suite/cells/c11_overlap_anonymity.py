# ============================================================================
# CELL A2 — TEXT OVERLAP BETWEEN PAPER 1 AND PAPER 2  (plan S1-T1)
# Pass: < 5% of Paper 2's long sentences appear verbatim in Paper 1.
# ============================================================================
def _sentences(pages):
    txt = " ".join(pages)
    txt = re.sub(r"-\s*\n\s*", "", txt)
    txt = re.sub(r"\s+", " ", txt)
    out = []
    for s in re.split(r"(?<=[.!?])\s+", txt):
        norm = re.sub(r"[^a-z0-9]", "", s.lower())
        if len(s) > 80 and len(norm) > 60:
            out.append(norm)
    return out

def _split_main_appendix(pages):
    for i, p in enumerate(pages):
        if re.search(r"Internet Appendix", p) and i > len(pages) * 0.3:
            return pages[:i], pages[i:]
    return pages, []

if PAPER1_PDF and PAPER2_PDF:
    p1, p2 = pdf_pages_text(PAPER1_PDF), pdf_pages_text(PAPER2_PDF)
    s1 = set(_sentences(p1))
    p2_main, p2_app = _split_main_appendix(p2)
    s2_main, s2_app = _sentences(p2_main), _sentences(p2_app)
    ov_main = np.mean([s in s1 for s in s2_main]) if s2_main else 0.0
    ov_app = np.mean([s in s1 for s in s2_app]) if s2_app else 0.0
    ov_all = np.mean([s in s1 for s in s2_main + s2_app])
    print(f"Paper 2 sentences found verbatim in Paper 1: main {ov_main:.1%}, appendix {ov_app:.1%}, all {ov_all:.1%}")
    record("S1-T1_overlap", bool(ov_all < 0.05 and ov_app == 0), "audit",
           {"overlap_main": ov_main, "overlap_appendix": ov_app, "overlap_all": ov_all,
            "n_p2_sentences": len(s2_main) + len(s2_app)},
           criterion="< 5% overall and 0% in appendices")
else:
    print("Upload both PDFs and re-run CELL 1.")

# ============================================================================
# CELL A3 — PAGE HEADERS, PAGE NUMBERS, ANONYMITY, LEAKS  (S1-T2, S2-T1, S3-T1)
# ============================================================================
NAMES = ["Niroula", "Alkhushayni", "Bhavsar", "Chen", "mnsu", "Mankato", "Tribhuvan", "Pratikn03"]
P2_ONLY_TERMS = ["Kreiss", "resolvent guard", "liquidation rate", "G_Kreiss", "Resolvent Solvency"]

def _page_number_issues(pages):
    bad = []
    for i, t in enumerate(pages, 1):
        tail = "\n".join(t.strip().split("\n")[-6:])
        nums = re.findall(r"(?m)^\s*(?:IA\.)?(\d{1,3})\s*$", tail)
        if len(nums) != 1:
            bad.append({"page": i, "numbers_found": nums})
    return bad

def _double_header(pages):
    bad = []
    for i, t in enumerate(pages, 1):
        head = " ".join(t.strip().split("\n")[:4])
        if re.search(r"(\b\w+\b)\s+(?:and\s+)?\1\b.*\1", head) or head.count("Niroula") >= 3:
            bad.append(i)
    return bad

checks = {}
for label, path in [("paper1", PAPER1_PDF), ("paper2_named", PAPER2_PDF), ("paper2_blind", PAPER2_BLIND_PDF)]:
    if not path:
        continue
    pages = pdf_pages_text(path)
    full = "\n".join(pages)
    c = {"pages": len(pages),
         "page_number_issues": _page_number_issues(pages)[:15],
         "n_page_number_issues": len(_page_number_issues(pages)),
         "double_header_pages": _double_header(pages)[:15],
         "double_blind_banner": "Double-Blind" in full}
    if label == "paper2_blind":
        c["name_leaks"] = {n: full.count(n) for n in NAMES if n in full}
    if label == "paper1":
        c["paper2_terms_in_paper1"] = {t: full.count(t) for t in P2_ONLY_TERMS if t in full}
    checks[label] = c
    print(label, json.dumps({k: v for k, v in c.items() if k != "page_number_issues"}, default=str))

if checks:
    ok_pages = all(v["n_page_number_issues"] == 0 and not v["double_header_pages"] for v in checks.values())
    record("S2-T1_page_layout", ok_pages, "audit", checks,
           criterion="every page has exactly one page number and one header")
    if "paper2_blind" in checks:
        record("S3-T1_anonymity", not checks["paper2_blind"].get("name_leaks"), "audit",
               checks["paper2_blind"], criterion="zero author names / affiliations in blind PDF")
    if "paper2_named" in checks:
        record("S3-T1b_named_has_no_blind_banner", not checks["paper2_named"]["double_blind_banner"], "audit",
               {"double_blind_banner": checks["paper2_named"]["double_blind_banner"]},
               criterion="named version does not say 'Double-Blind Submission'")
    if "paper1" in checks:
        record("S1-T2_leak_check", not checks["paper1"].get("paper2_terms_in_paper1"), "audit",
               checks["paper1"], criterion="no Paper 2 guard/liquidation content in Paper 1")
