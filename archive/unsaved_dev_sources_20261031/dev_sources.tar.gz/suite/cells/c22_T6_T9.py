# ============================================================================
# CELL L26 — PAPER 1 LEMMA 2.6: positive cohort economies cannot amplify
# Check: for stable economies with all w_i > 0, the price impulse response is
# completely monotone: (-1)^n Δ^n h_k >= 0 for n = 1..4.  (R2-T4)
# ============================================================================
R26 = rng(26)
viol, tested = 0, 0
for _ in range(2000):
    K = R26.integers(1, 5)
    r = R26.uniform(0.05, 0.95, K)
    w = R26.uniform(0.0, 0.2, K)
    a = R26.uniform(0.0, 0.95)
    if not is_stable(w, r, a, KAPPA_DEF):
        continue
    h = impulse(w, r, a, KAPPA_DEF, 200)
    tested += 1
    ok = all(np.all(((-1) ** n) * np.diff(h, n) >= -1e-12) for n in range(1, 5))
    viol += (not ok)
print(f"completely monotone: {tested - viol}/{tested}")
record("L26_complete_monotonicity", viol == 0, "theorem-check", {"tested": tested, "violations": viol},
       criterion="(-1)^n Δ^n h >= 0, n=1..4, every stable positive economy")

# ============================================================================
# CELL T6 — THE AMPLIFICATION THEOREM (depth-depletion channel)
# Book model (state: price displacement x, signed depth imbalance d):
#   x_t = a x_{t-1} + phi d_{t-1} + kappa u_t        (book pressure moves price)
#   d_t = (1 - r) d_{t-1} + eps u_t                  (sweeps deplete one side; refill r)
# Theorem to check:  max_k h_k > h_0   <=>   phi*eps > (1 - a)*kappa.
# Peak time from h_k = A a^k + B b^k, b = 1 - r.  Refill r controls height/duration.
# With momentum flow f_t = (1-eta) f_{t-1} + eta q x_{t-1} added to u (3-state):
#   candidate condition  phi*eps + kappa^2*eta*q > (1 - a)*kappa  (reported, not assumed).
# ============================================================================
def book_impulse(a, phi, kappa, r, eps, eta=0.0, q=0.0, L=400):
    x = np.zeros(L); d = np.zeros(L); f = np.zeros(L)
    for t in range(L):
        u = (1.0 if t == 0 else 0.0)
        if t > 0:
            f[t] = (1 - eta) * f[t - 1] + eta * q * x[t - 1]
        tot = u + f[t]
        x[t] = (a * x[t - 1] if t else 0) + (phi * d[t - 1] if t else 0) + kappa * tot
        d[t] = ((1 - r) * d[t - 1] if t else 0) + eps * tot
    return x

R6 = rng(6)
agree2, n2, peak_ok, n_pk, mono_r, n_r = 0, 0, 0, 0, 0, 0
for _ in range(2000):
    a, r = R6.uniform(0.0, 0.97), R6.uniform(0.01, 0.99)
    kappa, phi, eps = R6.uniform(0.1, 2.0), R6.uniform(0.0, 1.0), R6.uniform(0.0, 1.0)
    if abs(a - (1 - r)) < 1e-3:
        continue
    h = book_impulse(a, phi, kappa, r, eps)
    amp_sim = h.max() > h[0] * (1 + 1e-12)
    amp_thm = phi * eps > (1 - a) * kappa
    n2 += 1; agree2 += (amp_sim == amp_thm)
    if amp_thm:
        b = 1 - r
        B = -phi * eps / (a - b); A = kappa - B
        if A * np.log(a) != 0 and (-B * np.log(b)) / (A * np.log(a)) > 0:
            tc = np.log((-B * np.log(b)) / (A * np.log(a))) / np.log(a / b)
            kpk = int(np.argmax(h))
            n_pk += 1; peak_ok += (np.floor(tc) <= kpk <= np.ceil(tc) + 1e-9)
        # comparative static: faster refill -> lower peak
        h2 = book_impulse(a, phi, kappa, min(r * 1.05, 0.999), eps)
        n_r += 1; mono_r += (h2.max() <= h.max() + 1e-12)
print(f"2-state iff condition agrees with simulation: {agree2}/{n2}")
print(f"closed-form peak time correct: {peak_ok}/{n_pk};  faster refill lowers the peak: {mono_r}/{n_r}")

agree3, n3 = 0, 0
for _ in range(2000):
    a, r = R6.uniform(0.0, 0.95), R6.uniform(0.05, 0.95)
    kappa, phi, eps = R6.uniform(0.1, 1.5), R6.uniform(0.0, 0.6), R6.uniform(0.0, 0.6)
    eta, q = R6.uniform(0.05, 0.95), R6.uniform(0.0, 0.8)
    J3 = np.array([[a, phi, kappa * (1 - eta)], [0, 1 - r, eps * (1 - eta)], [eta * q, 0, 1 - eta]])
    # (exact 3x3 transition is computed by simulation; stability checked from the path)
    h = book_impulse(a, phi, kappa, r, eps, eta, q, L=600)
    if not np.all(np.isfinite(h)) or abs(h[-1]) > 1e-6 * abs(h).max():
        continue
    n3 += 1
    agree3 += ((h.max() > h[0] * (1 + 1e-12)) == (phi * eps + kappa ** 2 * eta * q > (1 - a) * kappa))
print(f"3-state candidate condition agrees with simulation: {agree3}/{n3}")
record("T6_amplification_theorem", agree2 == n2 and peak_ok == n_pk and mono_r == n_r, "theorem-check",
       {"agree_2state": agree2, "n_2state": n2, "peak_time_ok": peak_ok, "n_peak": n_pk,
        "refill_monotone": mono_r, "n_refill": n_r, "agree_3state_candidate": agree3, "n_3state": n3},
       criterion="2-state: iff condition, peak time and refill comparative static hold in every draw",
       note="3-state agreement is reported: if < 100%, the 3-state theorem needs a sharper condition.")

# ============================================================================
# CELL P1.7 — THIRD-TAP UNIT TEST (code correctness, belongs in an appendix)
# Merged cohort (weight q at rate η̄) vs split cohorts (q/2 at η̄ ± δ):
# first differing response lag and its size vs κ² q δ².
# ============================================================================
a7, k7, q7, eb = A_DEF, KAPPA_DEF, 0.3, 0.30
rows7 = []
for dl in [0.02, 0.05, 0.10]:
    hm = impulse([q7 * eb], [1 - eb], a7, k7, 20)
    hs = impulse([q7 / 2 * (eb + dl), q7 / 2 * (eb - dl)], [1 - eb - dl, 1 - eb + dl], a7, k7, 20)
    diff = hs - hm
    lag = int(np.argmax(np.abs(diff) > 1e-14))
    rows7.append({"delta": dl, "first_lag": lag, "diff": diff[lag], "kappa2_q_delta2": k7 ** 2 * q7 * dl ** 2})
df7 = pd.DataFrame(rows7); print(df7.to_string(index=False))
ok7 = np.allclose(np.abs(df7["diff"]), df7["kappa2_q_delta2"], rtol=1e-10)
record("P1.7-T1_third_tap", bool(ok7), "simulation", df7.to_dict("list"),
       criterion="|first response difference| = κ² q δ² to 1e-10 (unit test, not evidence)")

# ============================================================================
# CELL T7 + P2.11 — MAXIMALITY OF THE GUARD, AND MONOTONICITY OF L_max(α)
# Price impact system J(α) = J0 + α B; per-step shock |u_t| <= ū; horizon H.
# Exact worst-case loss: |I(α)| ū Σ_{k<H} |C J(α)^k b|  (cumulative L1 gain).
# Check 1 (T7): the L1 guard admits exactly the largest α a brute-force adversary allows.
# Check 2: a peak-gain guard (|I| ū max_k|g_k|) can be UNSAFE; a peak×H guard is conservative.
# Check 3 (P2.11): is worst-case loss monotone in α on the grid?
# ============================================================================
H7, GRID7 = 12, np.round(np.arange(0, 1.0001, 0.025), 3)
C7 = np.array([1.0, 0, 0]); b7 = np.array([0.8, 0.32, 0.25])
signs = np.array(list(itertools.product([-1.0, 1.0], repeat=H7)))      # 4096 x H

def gains(J, H=H7):
    v, out = b7.copy(), []
    for _ in range(H):
        out.append(C7 @ v); v = J @ v
    return np.array(out)

R7 = rng(7)
res7 = {"brute_equal": 0, "n_brute": 0, "peak_unsafe": 0, "peakH_conservative": 0, "n": 0, "monotone_viol": 0}
for s in range(2000):
    J0 = np.diag(R7.uniform(0.5, 0.85, 3)) + np.triu(R7.uniform(0, 0.4, (3, 3)), 1)
    Bm = np.triu(R7.uniform(0, 0.6, (3, 3)), 1)
    I0, cf, ubar = R7.uniform(0.5, 2.0), R7.uniform(0.0, 2.0), R7.uniform(0.1, 1.0)
    G = np.array([gains(J0 + al * Bm) for al in GRID7])                  # (41, H)
    inv = np.abs(I0 + cf * GRID7)
    loss_L1 = inv * ubar * np.abs(G).sum(1)
    budget = np.quantile(loss_L1, R7.uniform(0.2, 0.9))
    res7["n"] += 1
    res7["monotone_viol"] += int(np.any(np.diff(loss_L1) < -1e-12))
    safe_L1 = GRID7[loss_L1 <= budget]
    a_L1 = safe_L1.max() if len(safe_L1) else -1
    loss_pk = inv * ubar * np.abs(G).max(1)
    a_pk = GRID7[loss_pk <= budget].max() if np.any(loss_pk <= budget) else -1
    loss_pkH = loss_pk * H7
    a_pkH = GRID7[loss_pkH <= budget].max() if np.any(loss_pkH <= budget) else -1
    if a_pk > a_L1:
        res7["peak_unsafe"] += 1
    if a_pkH < a_L1:
        res7["peakH_conservative"] += 1
    if s < 200:   # brute force adversary over all sign sequences and all stopping times
        true_worst = []
        for gi, g in zip(range(len(GRID7)), G):
            # displacement after n steps with shocks u_0..u_{n-1}: sum_t g_{n-1-t} u_t
            paths = np.stack([signs[:, :n] @ g[:n][::-1] for n in range(1, H7 + 1)], 1)
            true_worst.append(inv[gi] * ubar * np.abs(paths).max())
        true_worst = np.array(true_worst)
        safe_b = GRID7[true_worst <= budget * (1 + 1e-12)]
        a_b = safe_b.max() if len(safe_b) else -1
        res7["n_brute"] += 1; res7["brute_equal"] += int(np.isclose(a_b, a_L1))
print(json.dumps(res7))
record("T7_guard_maximality", res7["brute_equal"] == res7["n_brute"], "theorem-check", res7,
       criterion="L1-gain guard α equals brute-force maximal safe α in every state",
       note=f"peak-gain guard admitted an unsafe α in {res7['peak_unsafe']}/{res7['n']} states; "
            f"peak×H guard was conservative in {res7['peakH_conservative']}/{res7['n']}.")
record("P2.11-T1_monotone_Lmax", res7["monotone_viol"] == 0, "theorem-check",
       {"violations": res7["monotone_viol"], "states": res7["n"]},
       criterion="worst-case loss nondecreasing in α on the grid (else condition Theorem 2.12)")

# ============================================================================
# CELL T8 — CERTIFIED ROBUST GAIN
# If ||E|| <= ε and ε S < 1 with M = sup_k ||J^k||, S = Σ_k ||J^k||, then
#   sup_k ||(J+E)^k|| <= M / (1 - ε S).
# Check on 100 random non-normal J × 300 perturbations (random + adversarial rank-1).
# ============================================================================
R8 = rng(8)
n8, viol8, ratios = 0, 0, []
for _ in range(100):
    d = R8.integers(2, 6)
    T = np.diag(R8.uniform(0.3, 0.85, d)) + np.triu(R8.normal(0, 1.5, (d, d)), 1)
    Q, _ = np.linalg.qr(R8.normal(size=(d, d)))
    J = Q @ T @ Q.T
    pn = power_norms(J)
    M, S = pn.max(), pn.sum()
    eps8 = 0.5 / S
    bound = M / (1 - eps8 * S)
    for j in range(300):
        if j % 2 == 0:
            E = R8.normal(size=(d, d))
        else:   # adversarial direction: align with top singular vectors of a high power of J
            k = R8.integers(1, 30)
            U, _, Vt = np.linalg.svd(np.linalg.matrix_power(J, k))
            E = np.outer(Vt[0], U[:, 0])
        E *= eps8 / np.linalg.norm(E, 2)
        m = power_norms(J + E, K=1500).max()
        n8 += 1; viol8 += (m > bound * (1 + 1e-9)); ratios.append(m / bound)
print(f"bound held in {n8 - viol8}/{n8}; tightness (realized/bound): median {np.median(ratios):.3f}, max {np.max(ratios):.3f}")
record("T8_robust_gain", viol8 == 0, "theorem-check",
       {"n": n8, "violations": viol8, "tightness_median": np.median(ratios), "tightness_max": np.max(ratios)},
       criterion="realized sup_k ||(J+E)^k|| <= M/(1-εS) for every draw")

# ============================================================================
# CELL T9 + P1.2-T1 — THE BRIDGE: wedge is cheap, cohorts are expensive
# K=2 cohorts at rates 0.7 ± Δ. Observe ĥ = h + noise (σ_eff = σ/√N).
#   * transient wedge W = Σ_{k<L} |h_k|  -> relative error vs Δ (should be flat)
#   * cohort weights by deconvolution + ESPRIT -> error vs Δ (should blow up)
#   * local ESPRIT requirement N*_ESPRIT(Δ) ∝ Δ^-6 (upper-bound side of P1.2)
# ============================================================================
def esprit_weights(k, K=2, M=None):
    M = M or (len(k) - 1) // 2
    Hk = linalg.hankel(k[:M + 1], k[M:2 * M + 1])
    U, s, Vt = np.linalg.svd(Hk)
    Us = U[:, :K]
    z = np.linalg.eigvals(np.linalg.pinv(Us[:-1]) @ Us[1:])
    z = np.sort(np.real(z))
    V = np.vander(z, len(k), increasing=True).T
    wv = np.linalg.lstsq(V, k, rcond=None)[0]
    return z, np.real(wv)

L9, sig_eff = 60, 1e-6
R9 = rng(9)
grid9 = np.geomspace(0.03, 0.2, 7)
rows9 = []
for dlt in grid9:
    w_t = np.array([0.05, 0.05]); r_t = np.array([R_CENTER - dlt, R_CENTER + dlt])
    h = impulse(w_t, r_t, A_DEF, KAPPA_DEF, L9)
    W_true = np.abs(h).sum()
    we, ce = [], []
    for _ in range(300):
        hh = h + R9.normal(0, sig_eff, L9)
        we.append(abs(np.abs(hh).sum() - W_true) / W_true)
        kk = kernel_from_impulse(hh, A_DEF, KAPPA_DEF)[:24]
        z, wv = esprit_weights(kk)
        ce.append(np.max(np.abs(wv - w_t)))
    q95 = np.quantile(ce, 0.95)
    rows9.append({"delta": dlt, "wedge_rel_err_q95": np.quantile(we, 0.95), "weight_err_q95": q95,
                  "N_star_ESPRIT_tau0.01": (q95 / sig_eff * 1.0 / 0.01) ** 2})   # σ=1 per reset
df9 = pd.DataFrame(rows9); print(df9.to_string(index=False))
s_w = loglog_slope(df9["delta"][:4], df9["wedge_rel_err_q95"][:4])     # small-Δ regime (the theorem's limit)
s_c = loglog_slope(df9["delta"][:4], df9["weight_err_q95"][:4])
s_N = loglog_slope(df9["delta"][:4], df9["N_star_ESPRIT_tau0.01"][:4])
print(f"slopes: wedge error {s_w:.2f} (target 0), weight error {s_c:.2f} (target -3), N*_ESPRIT {s_N:.2f} (target -6)")
record("T9_bridge", abs(s_w) <= 0.3 and s_c <= -2.5, "theorem-check",
       {"table": df9.to_dict("list"), "slope_wedge": s_w, "slope_weights": s_c},
       criterion="as Δ -> 0 (4 smallest Δ): wedge error flat (|slope| <= 0.3); cohort-weight error grows at least like Δ^-2.5")
record("P1.2-T1_esprit_rate", abs(s_N + 6) <= 0.5, "theorem-check",
       {"slope_N_star_ESPRIT": s_N, "table": df9.to_dict("list")},
       criterion="local ESPRIT requirement slope within ±0.5 of -6 (matches Le Cam order)",
       note="Numerical evidence for the upper bound. The paper still needs a written proof (Route A) "
            "or must call this a numerical proposition (Route B).")
