# ============================================================================
# CELL 2 — REAL DATA LOADER (Binance public 1-second klines, checksum-verified)
# Every real-data test downloads through load_day(). There is NO synthetic
# fallback: if a download fails, the test stops and says so.
# Data licence: Binance public data (data.binance.vision); cite it in the paper.
# ============================================================================
BINANCE = "https://data.binance.vision/data/spot/daily/klines/{sym}/1s/{sym}-1s-{date}.zip"
KLINE_COLS = ["open_time", "open", "high", "low", "close", "volume", "close_time",
              "quote_volume", "n_trades", "taker_buy_base", "taker_buy_quote", "ignore"]

DOWNLOAD_LOG = []

def _get(url, timeout=60, tries=3):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(2 * (i + 1))
    raise RuntimeError(f"download failed: {url}: {last}")

def load_day(sym, date):
    """One UTC day of 1s klines -> DataFrame indexed by second (86,400 rows):
       close (USDT), flow_q (signed taker quote flow, USDT), flow_b (signed base flow),
       vol_q (quote volume). Missing seconds: close forward-filled, flows 0."""
    pq = os.path.join(DATA, f"{sym}_{date}.parquet")
    if os.path.exists(pq):
        return pd.read_parquet(pq)
    url = BINANCE.format(sym=sym, date=date)
    raw = _get(url)
    sha = hashlib.sha256(raw).hexdigest()
    official = _get(url + ".CHECKSUM").decode().split()[0]
    if sha != official:
        raise RuntimeError(f"SHA-256 mismatch for {sym} {date}: {sha} vs {official}")
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        with z.open(z.namelist()[0]) as f:
            df = pd.read_csv(f, header=None, names=KLINE_COLS)
    t = df["open_time"].astype("int64")
    t = np.where(t > 1e14, t // 1_000_000, t // 1000)  # 2025+ files use microseconds
    s = pd.DataFrame({
        "close": df["close"].astype(float).to_numpy(),
        "flow_q": (2 * df["taker_buy_quote"] - df["quote_volume"]).astype(float).to_numpy(),
        "flow_b": (2 * df["taker_buy_base"] - df["volume"]).astype(float).to_numpy(),
        "vol_q": df["quote_volume"].astype(float).to_numpy(),
    }, index=pd.Index(t, name="sec"))
    s = s[~s.index.duplicated()]
    t0 = int(pd.Timestamp(f"{date} 00:00:00", tz="UTC").timestamp())
    s = s.reindex(np.arange(t0, t0 + 86400))
    s["close"] = s["close"].ffill().bfill()
    s[["flow_q", "flow_b", "vol_q"]] = s[["flow_q", "flow_b", "vol_q"]].fillna(0.0)
    s.index.name = "sec"
    s.to_parquet(pq)
    DOWNLOAD_LOG.append({"sym": sym, "date": date, "sha256": sha})
    return s

def load_days(sym, dates, verbose=True):
    out = {}
    for i, d in enumerate(dates):
        try:
            out[d] = load_day(sym, d)
        except Exception as e:
            print(f"   ! {sym} {d}: {e}")
        if verbose and (i + 1) % 10 == 0:
            print(f"   loaded {i+1}/{len(dates)} days")
    return out

def bars(day, delta=1):
    """Aggregate to delta-second bars. Returns log-price in bp, flow in $1M."""
    if delta == 1:
        p = np.log(day["close"].to_numpy()) * 1e4
        f = day["flow_q"].to_numpy() / 1e6
        v = day["vol_q"].to_numpy() / 1e6
        return p, f, v
    n = len(day) // delta * delta
    c = day["close"].to_numpy()[:n].reshape(-1, delta)[:, -1]
    f = day["flow_q"].to_numpy()[:n].reshape(-1, delta).sum(1) / 1e6
    v = day["vol_q"].to_numpy()[:n].reshape(-1, delta).sum(1) / 1e6
    return np.log(c) * 1e4, f, v

def ema_dev(p, span):
    """Price deviation from its EMA (the paper's x_t), bp."""
    return p - pd.Series(p).ewm(span=span, adjust=False).mean().to_numpy()

# ---- Event and panel calendars (fixed BEFORE looking at results) -----------
CRASH_DAYS = {                       # stress days used in Paper 2
    "May2021": "2021-05-19", "LUNA2022": "2022-05-09",
    "FTX2022": "2022-11-08", "SVB2023": "2023-03-11",
}
OOS_CRASH_DAYS = {"Aug2024": "2024-08-05"}   # held out: never used for tuning
PANEL_DAYS = [f"{y}-{m:02d}-{d:02d}" for y in (2021, 2022, 2023, 2024)
              for m in range(1, 13) for d in (10, 24)]
TRAIN_YEARS, TEST_YEARS = (2021, 2022, 2023), (2024,)
HOLDOUT_JAN2023 = [f"2023-01-{d:02d}" for d in range(10, 21)]
print(f"{len(PANEL_DAYS)} panel days; crash days: {list(CRASH_DAYS.values())}")
