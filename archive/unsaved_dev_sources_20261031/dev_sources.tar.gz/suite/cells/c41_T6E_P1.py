# ============================================================================
# CELL T6-E — DOES PRICE OVERSHOOT AFTER A FLOW SHOCK? (real data, local projections)
# For horizons k: regress  p_{t+k} - p_{t-1}  (bp)  on  f_t ($1M signed flow),
# controls: 5 lags of returns and flows.  Two versions:
#   "total":           includes the effect of flow persistence (order splitting)
#   "flow_held_fixed": also controls for cumulative future flow f_{t+1..t+k}
# Overshoot (the T6 mechanism) = β_k > β_0 in the flow-held-fixed response.
# Day-clustered bootstrap CIs.  Run on 2021-2023 panel days and on crash days.
# ============================================================================
HORIZONS = [0, 1, 2, 5, 10, 20, 30, 60, 120, 300]

def lp_day(day, horizons=HORIZONS, nlags=5):
    p, f, _ = bars(day, 1)
    r = np.diff(p, prepend=p[0])
    n = len(p); maxk = max(horizons)
    t = np.arange(nlags + 1, n - maxk - 1)
    lagsR = np.column_stack([r[t - j] for j in range(1, nlags + 1)])
    lagsF = np.column_stack([f[t - j] for j in range(1, nlags + 1)])
    cumf = np.concatenate([[0.0], np.cumsum(f)])
    out = {"total": [], "flow_held_fixed": []}
    for k in horizons:
        y = p[t + k] - p[t - 1]
        Xb = np.column_stack([np.ones(len(t)), f[t], lagsR, lagsF])
        out["total"].append(np.linalg.lstsq(Xb, y, rcond=None)[0][1])
        fut = cumf[t + k + 1] - cumf[t + 1]              # f_{t+1} .. f_{t+k}
        Xf = np.column_stack([Xb, fut]) if k > 0 else Xb
        out["flow_held_fixed"].append(np.linalg.lstsq(Xf, y, rcond=None)[0][1])
    return {k: np.array(v) for k, v in out.items()}

def lp_summary(days, R, B=1000):
    per = [lp_day(d) for d in days.values()]
    res = {}
    for kind in ("total", "flow_held_fixed"):
        M = np.array([p[kind] for p in per])            # days x horizons
        mean = M.mean(0)
        boots = np.array([M[R.integers(0, len(M), len(M))].mean(0) for _ in range(B)])
        over = boots[:, 1:].max(1) - boots[:, 0]         # max_{k>=1} β_k - β_0 (can be negative)
        peak_k = HORIZONS[int(np.argmax(mean))]
        res[kind] = {"beta": mean, "ci_lo": np.quantile(boots, 0.025, 0), "ci_hi": np.quantile(boots, 0.975, 0),
                     "overshoot_mean": float(mean[1:].max() - mean[0]),
                     "overshoot_ci": [float(np.quantile(over, 0.025)), float(np.quantile(over, 0.975))],
                     "peak_horizon_s": peak_k,
                     "decays_after_peak": bool(mean[-1] < mean.max())}
    return res

R6E = rng(61)
lp_ord = lp_summary(ord_data, R6E)
lp_crash = lp_summary({k: v for k, v in crash_data.items()}, R6E, B=500)
for lab, res in [("ordinary", lp_ord), ("crash", lp_crash)]:
    for kind, v in res.items():
        print(f"{lab:9s} {kind:16s} β(bp per $1M) by horizon: {np.round(v['beta'], 3)}")
        print(f"{'':9s} {'':16s} overshoot {v['overshoot_mean']:.3f} CI {np.round(v['overshoot_ci'], 3)}, peak at {v['peak_horizon_s']}s")
record("T6-E_overshoot_real", None, "real-data",
       {"horizons_s": HORIZONS, "ordinary": lp_ord, "crash": lp_crash},
       note="Evidence for T6 = flow-held-fixed overshoot CI above 0, with a decay after the peak. "
            "A 'total' overshoot alone can come from order splitting and is not evidence for the depth channel.")

# ============================================================================
# CELL P1.6 — IS MEASURED FEEDBACK MORE THAN EMA MECHANICS? (real data + placebo)
# Paper 1 estimator (repo feedback_var.var1): VAR(1) on (x_t, f_t) with EMA span 30 bins,
# Q = J12 J21 / (1 - J22).  Mechanical EMA persistence: 1 - 2/31 = 0.935.
# Placebo: same pipeline, price replaced by a random walk with the same volatility,
# independent of flow.  Pass: placebo Q CI contains 0 (pipeline unbiased).
# Report: whether real Q lies outside the placebo 95% band.
# ============================================================================
def q_stats(p, f, span=30):
    x = ema_dev(p, span); fn = np.roll(f, -1)
    x, fn = x[5 * span:-1], fn[5 * span:-1]
    J = var1_J(x, fn)
    Q = J[0, 1] * J[1, 0] / (1 - J[1, 1])
    return Q, J[0, 0]

R16 = rng(16)
real, plac = [], []
for d, day in ord_data.items():
    p, f, _ = bars(day, 1)
    real.append(q_stats(p, f))
    rw = np.concatenate([[p[0]], p[0] + np.cumsum(R16.normal(0, np.std(np.diff(p)), len(p) - 1))])
    plac.append(q_stats(rw, f))
real, plac = np.array(real), np.array(plac)
def day_ci(v, B=2000):
    bs = [v[R16.integers(0, len(v), len(v))].mean() for _ in range(B)]
    return [float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))]
res16 = {"Q_real_mean": real[:, 0].mean(), "Q_real_ci": day_ci(real[:, 0]),
         "Q_placebo_mean": plac[:, 0].mean(), "Q_placebo_ci": day_ci(plac[:, 0]),
         "Q_placebo_band95": [float(np.quantile(plac[:, 0], 0.025)), float(np.quantile(plac[:, 0], 0.975))],
         "J11_real_mean": real[:, 1].mean(), "J11_placebo_mean": plac[:, 1].mean(),
         "J11_mechanical": 1 - 2 / 31, "n_days": len(real)}
print(json.dumps(_clean(res16), indent=1))
ci = res16["Q_placebo_ci"]
record("P1.6-T1_ema_placebo", bool(ci[0] <= 0 <= ci[1]), "real-data", res16,
       criterion="placebo Q CI contains 0",
       note="Then report: real Q CI vs placebo band. If they overlap, write 'no evidence beyond mechanics'.")

# ============================================================================
# CELL P1.3 — MEASUREMENT NOISE ON THE JAN 2023 HOLDOUT (real data)
# Roll-type estimator on 1-second closes: σ_noise = sqrt(-cov(Δp_t, Δp_{t-1})) in USDT.
# Capital scales as σ_obs²: C(σ_obs) = 61.44 USDT × (σ_obs / 0.01)²   (61.44 at σ = 0.01;
# the paper's $9.83M corresponds to σ_obs = 4 USDT).  Microprice/half-spread versions
# need order-book depth (file 1-09-1-20.csv); add them here if you have the file.
# ============================================================================
jan = load_days("BTCUSDT", HOLDOUT_JAN2023, verbose=False)
rows13 = []
for d, day in jan.items():
    c = day["close"].to_numpy(); dc = np.diff(c)
    cov1 = np.mean((dc[1:] - dc.mean()) * (dc[:-1] - dc.mean()))
    rows13.append({"date": d, "roll_sigma_usdt": float(np.sqrt(max(0.0, -cov1))),
                   "sd_1s_change_usdt": float(dc.std()), "price": float(c.mean())})
df13 = pd.DataFrame(rows13)
grid = {"roll_median": df13["roll_sigma_usdt"].median(), "sd_1s_change_median": df13["sd_1s_change_usdt"].median(),
        "paper_assumption": 4.0}
cap = {k: {f"delta={dl}": 61.44 * (s / 0.01) ** 2 * (0.05 / dl) ** 4 for dl in (0.02, 0.05, 0.10)}
       for k, s in grid.items()}
print(df13.round(4).to_string(index=False)); print(pd.DataFrame(cap).round(0).to_string())
record("P1.3-T1_sigma_obs", None, "real-data", {"by_day": df13.to_dict("list"), "sigma_choices": grid,
                                                 "capital_usdt": cap},
       note="Replace the $9.83M headline with this grid; label 4 USDT as an upper scenario.")
