# ============================================================================
# CELL 1 — REPOSITORY AND MANUSCRIPT FILES
# Clones your repo (for the audit cells) and points to the current PDFs.
# Upload the newest PDFs to /content (left sidebar → Files → upload) or Drive,
# then set the four paths below.
# ============================================================================
REPO = "/content/Fianince" if IN_COLAB else os.path.abspath("repo")
if IN_COLAB and not os.path.isdir(REPO):
    subprocess.run(["git", "clone", "--depth", "1",
                    "https://github.com/Pratikn03/Fianince.git", REPO], check=True)

def _first(*cands):
    for c in cands:
        hits = sorted(glob.glob(c))
        if hits:
            return hits[-1]
    return None

_UP = "/content" if IN_COLAB else "/mnt/user-data/uploads"
PAPER1_PDF = _first(f"{_UP}/Paper_1*CLEAN*.pdf", f"{_UP}/Paper_1*.pdf")
PAPER2_PDF = _first(f"{_UP}/Paper_2*Named*CLEAN*.pdf", f"{_UP}/Paper_2*Named*.pdf", f"{_UP}/Paper_2*.pdf")
PAPER2_BLIND_PDF = _first(f"{_UP}/Paper_2*Anonymous*.pdf")
# Your LaTeX sources (used by the number-consistency audit). Adjust if needed.
PAPER1_TEX = _first(f"{REPO}/paper1/*.tex", f"{REPO}/paper/*Paper_1*.tex")
PAPER2_TEX = _first(f"{REPO}/paper2/*.tex", f"{REPO}/paper/*Paper_2*.tex")

for k in ["REPO", "PAPER1_PDF", "PAPER2_PDF", "PAPER2_BLIND_PDF", "PAPER1_TEX", "PAPER2_TEX"]:
    print(f"{k:18s} = {globals()[k]}")

def pdf_pages_text(path):
    import fitz
    with fitz.open(path) as doc:
        return [p.get_text() for p in doc]
