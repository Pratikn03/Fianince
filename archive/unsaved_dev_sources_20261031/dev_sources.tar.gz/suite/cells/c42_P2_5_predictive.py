# ============================================================================
# CELL P2.5a — PRE-REGISTRATION (run BEFORE P2.5b; commit the file to GitHub)
# The test period (2024) is evaluated only by P2.5b, only if this file exists,
# and every evaluation is counted in prereg/test_set_unlocks.json.
# ============================================================================
PREREG_SPEC = {
    "question": "Does the pre-window transient amplification A_xx add out-of-sample predictive power "
                "for the next 10 minutes' maximum adverse excursion beyond volatility and flow controls?",
    "data": "Binance BTCUSDT 1s klines, panel days (10th and 24th of each month) 2021-2024",
    "unit": "non-overlapping 30-minute blocks; features from [t-10min, t), outcome from (t, t+10min]",
    "outcome": "MAE = max_{s in (t, t+600]} |p_s - p_t| in bp; tail = MAE above train 90th percentile",
    "controls": ["rv_10m", "rv_60m", "abs_ret_10m", "flow_imbalance", "log_volume", "rho", "hour_sin", "hour_cos"],
    "candidate": "log_A_xx",
    "train": "2021-2023", "test": "2024",
    "model": "OLS for MAE; score = fitted MAE for tail AUC",
    "inference": "Clark-West (nested) with Newey-West(4); day-block bootstrap (2,000) for ΔR² and ΔAUC",
    "success": "Clark-West one-sided p < 0.05 AND bootstrap 95% CI of ΔR² excludes 0",
}
spec_txt = json.dumps(PREREG_SPEC, indent=2, sort_keys=True)
PREREG_HASH = hashlib.sha256(spec_txt.encode()).hexdigest()
pr_path = os.path.join(PREREG, "P2_predictive.json")
if not os.path.exists(pr_path):
    with open(pr_path, "w") as f:
        f.write(spec_txt)
    print("pre-registration written:", pr_path)
else:
    old = hashlib.sha256(open(pr_path).read().encode()).hexdigest()
    if old != PREREG_HASH:
        print("!! WARNING: the spec differs from the registered file. Changing it after seeing results "
              "must be disclosed in the paper. Registered hash:", old)
print("spec SHA-256:", PREREG_HASH)

# ============================================================================
# CELL P2.5b — OUT-OF-SAMPLE PREDICTIVE TEST   (gate G2)   + leakage tests (R2-T8, R2-T10)
# ============================================================================
BLOCK, PRE, POST = 1800, 600, 600

def features_at(p, f, v, t):
    """Uses ONLY indices < t."""
    seg = slice(t - PRE, t); seg60 = slice(max(0, t - 3600), t)
    r = np.diff(p[seg]); r60 = np.diff(p[seg60])
    x = ema_dev(p[max(0, t - PRE - 5 * SPAN):t], SPAN)[-PRE:]
    fn = np.roll(f[seg], -1)
    J = var1_J(x[:-1], fn[:-1])
    A, rho = amp_stats(J)
    hour = ((t % 86400) / 3600.0)
    fs = f[seg]
    return {"rv_10m": r.std(), "rv_60m": r60.std(), "abs_ret_10m": abs(p[t - 1] - p[t - PRE]),
            "flow_imbalance": fs.sum() / (np.abs(fs).sum() + 1e-12), "log_volume": np.log1p(v[seg].sum()),
            "rho": rho, "log_A_xx": np.log(A), "hour_sin": np.sin(2 * np.pi * hour / 24),
            "hour_cos": np.cos(2 * np.pi * hour / 24)}

def outcome_at(p, t):
    return float(np.max(np.abs(p[t + 1:t + 1 + POST] - p[t])))

print("Loading all panel days 2021-2024 ...")
panel = load_days("BTCUSDT", PANEL_DAYS)
rows = []
for d, day in panel.items():
    p, f, v = bars(day, 1)
    for t in range(3600, 86400 - POST - 1, BLOCK):
        r_ = features_at(p, f, v, t); r_["MAE"] = outcome_at(p, t); r_["date"] = d; r_["t"] = t
        rows.append(r_)
dfp = pd.DataFrame(rows)
dfp["year"] = dfp["date"].str[:4].astype(int)
print(f"{len(dfp)} blocks from {dfp['date'].nunique()} days")
# Drop blocks where a feature or the outcome is not finite (e.g. a 10-minute window with no
# trades makes the VAR degenerate). The count is recorded so the paper can report it.
_cols = PREREG_SPEC["controls"] + [PREREG_SPEC["candidate"], "MAE"]
_bad = ~np.isfinite(dfp[_cols].to_numpy(float)).all(1)
DROPPED_BLOCKS = {"n_dropped": int(_bad.sum()), "by_column": {c: int((~np.isfinite(dfp[c].to_numpy(float))).sum()) for c in _cols}}
print("dropped non-finite blocks:", DROPPED_BLOCKS)
dfp = dfp[~_bad].reset_index(drop=True)

# ---- Leakage / look-ahead tests (R2-T8, R2-T10) ---------------------------
Rlk = rng(80); leak_fail = 0
for _ in range(50):
    d = Rlk.choice(list(panel)); p, f, v = bars(panel[d], 1)
    t = int(Rlk.integers(3600, 86400 - POST - 1))
    a = features_at(p, f, v, t)
    p2, f2, v2 = p.copy(), f.copy(), v.copy()
    p2[t:] += Rlk.normal(0, 50, len(p) - t); f2[t:] *= -3; v2[t:] *= 7      # scramble the future
    b = features_at(p2, f2, v2, t)
    leak_fail += any(abs(a[k] - b[k]) > 1e-12 for k in a)
record("R2-T8_no_lookahead", leak_fail == 0, "audit", {"trials": 50, "failures": leak_fail},
       criterion="features unchanged when all data from t onward are scrambled")

# ---- Model fit on train, evaluate on test ---------------------------------
CTRL = PREREG_SPEC["controls"]; CAND = PREREG_SPEC["candidate"]
tr, te = dfp[dfp["year"].isin(TRAIN_YEARS)], dfp[dfp["year"].isin(TEST_YEARS)]

def fit_pred(cols, train, test, y="MAE"):
    X = np.column_stack([np.ones(len(train)), train[cols].to_numpy()])
    b = np.linalg.lstsq(X, train[y].to_numpy(), rcond=None)[0]
    return np.column_stack([np.ones(len(test)), test[cols].to_numpy()]) @ b

def auc(y, s):
    pos, neg = s[y == 1], s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return np.nan
    ranks = stats.rankdata(np.concatenate([pos, neg]))
    return (ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))

def clark_west(y, f_small, f_big, lags=4):
    adj = (y - f_small) ** 2 - ((y - f_big) ** 2 - (f_small - f_big) ** 2)
    m = adj.mean(); e = adj - m; n = len(adj)
    lrv = e @ e / n + 2 * sum((1 - l / (lags + 1)) * (e[l:] @ e[:-l]) / n for l in range(1, lags + 1))
    tstat = m / np.sqrt(lrv / n)
    return float(tstat), float(1 - stats.norm.cdf(tstat))

def evaluate(df_tr, df_te, cand_col):
    y = df_te["MAE"].to_numpy()
    fb = fit_pred(CTRL, df_tr, df_te); ff = fit_pred(CTRL + [cand_col], df_tr, df_te)
    sst = np.sum((y - df_tr["MAE"].mean()) ** 2)       # OOS R² vs train-mean benchmark
    r2b, r2f = 1 - np.sum((y - fb) ** 2) / sst, 1 - np.sum((y - ff) ** 2) / sst
    tail = (y > np.quantile(df_tr["MAE"], 0.90)).astype(int)
    return {"y": y, "fb": fb, "ff": ff, "tail": tail, "r2_base": r2b, "r2_full": r2f,
            "auc_base": auc(tail, fb), "auc_full": auc(tail, ff)}

def unlock_count():
    pth = os.path.join(PREREG, "test_set_unlocks.json")
    n = json.load(open(pth))["n"] + 1 if os.path.exists(pth) else 1
    json.dump({"n": n, "last_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": PREREG_HASH},
              open(pth, "w"))
    return n

assert os.path.exists(pr_path), "run P2.5a first"
n_unlock = unlock_count()
ev = evaluate(tr, te, CAND)
te_sorted = te.reset_index(drop=True).sort_values(["date", "t"])
order = te_sorted.index.to_numpy()
cw_t, cw_p = clark_west(ev["y"][order], ev["fb"][order], ev["ff"][order])

Rbs = rng(25); days_te = te["date"].to_numpy(); ud = np.unique(days_te)
dR2, dAUC = [], []
for _ in range(2000):
    pick = Rbs.choice(ud, len(ud))
    idx = np.concatenate([np.where(days_te == d)[0] for d in pick])
    y, fb, ff, tl = ev["y"][idx], ev["fb"][idx], ev["ff"][idx], ev["tail"][idx]
    sst = np.sum((y - tr["MAE"].mean()) ** 2)
    dR2.append((np.sum((y - fb) ** 2) - np.sum((y - ff) ** 2)) / sst)
    dAUC.append(auc(tl, ff) - auc(tl, fb))
ci_r2 = [float(np.nanquantile(dR2, 0.025)), float(np.nanquantile(dR2, 0.975))]
ci_auc = [float(np.nanquantile(dAUC, 0.025)), float(np.nanquantile(dAUC, 0.975))]

# Null feature: AR(1) noise with the candidate's autocorrelation
Rnull = rng(26); c = dfp[CAND].to_numpy(); phi = np.corrcoef(c[1:], c[:-1])[0, 1]
z = np.zeros(len(c)); e = Rnull.normal(size=len(c))
for i in range(1, len(c)):
    z[i] = phi * z[i - 1] + e[i]
dfp["null_feature"] = z
ev_null = evaluate(dfp[dfp["year"].isin(TRAIN_YEARS)], dfp[dfp["year"].isin(TEST_YEARS)], "null_feature")

res25 = {"n_train": len(tr), "n_test": len(te), "r2_base": ev["r2_base"], "r2_full": ev["r2_full"],
         "delta_r2": ev["r2_full"] - ev["r2_base"], "delta_r2_ci": ci_r2,
         "auc_base": ev["auc_base"], "auc_full": ev["auc_full"], "delta_auc_ci": ci_auc,
         "clark_west_t": cw_t, "clark_west_p": cw_p,
         "null_feature_delta_r2": ev_null["r2_full"] - ev_null["r2_base"],
         "prereg_sha256": PREREG_HASH, "test_set_unlocks": n_unlock, "dropped_blocks": DROPPED_BLOCKS}
print(json.dumps(_clean(res25), indent=1))
g2 = cw_p < 0.05 and ci_r2[0] > 0
record("P2.5_predictive_G2", bool(g2), "real-data", res25, criterion=PREREG_SPEC["success"],
       note="Report this result in the paper whatever it is. test_set_unlocks > 1 must be disclosed.")
record("P2.5-T2_null_feature", bool(abs(res25["null_feature_delta_r2"]) < max(abs(ci_r2[1] - ci_r2[0]), 1e-3)),
       "real-data", {"null_feature_delta_r2": res25["null_feature_delta_r2"]},
       criterion="a random feature adds ~0 out-of-sample R² (pipeline sanity)")

# Leave-one-year-out within train (robustness, not the headline)
loyo = {}
for yv in TRAIN_YEARS:
    a_ = dfp[dfp["year"].isin([y for y in TRAIN_YEARS if y != yv])]; b_ = dfp[dfp["year"] == yv]
    e_ = evaluate(a_, b_, CAND); loyo[yv] = e_["r2_full"] - e_["r2_base"]
record("P2.5-T3_leave_one_year_out", None, "real-data", loyo, note="ΔR² by held-out training year.")

# ============================================================================
# CELL P2.7 — VOL-ONLY ABLATION AND FALSE ALARMS ON REAL OUTCOMES
# Flags set on TRAIN so each flags 10% of blocks; compare on TEST for tail events.
# ============================================================================
thr_w = np.quantile(tr[CAND], 0.90); thr_v = np.quantile(tr["rv_10m"], 0.90)
tail_te = ev["tail"]; wf = (te[CAND].to_numpy() > thr_w); vf = (te["rv_10m"].to_numpy() > thr_v)
def pr(flag, y):
    tp = np.sum(flag & (y == 1)); return {"flag_rate": flag.mean(), "precision": tp / max(flag.sum(), 1),
                                          "recall": tp / max((y == 1).sum(), 1),
                                          "false_alarm_share": 1 - tp / max(flag.sum(), 1)}
res27 = {"wedge_flag": pr(wf, tail_te), "vol_flag": pr(vf, tail_te), "either": pr(wf | vf, tail_te)}
diffs = []
for _ in range(2000):
    pick = Rbs.choice(ud, len(ud)); idx = np.concatenate([np.where(days_te == d)[0] for d in pick])
    y = tail_te[idx]; diffs.append(pr(wf[idx], y)["recall"] - pr(vf[idx], y)["recall"])
res27["recall_diff_wedge_minus_vol_ci"] = [float(np.quantile(diffs, 0.025)), float(np.quantile(diffs, 0.975))]
print(json.dumps(_clean(res27), indent=1))
record("P2.7-T2_vol_ablation", None, "real-data", res27,
       note="If the CI of the recall difference contains 0, write that the wedge flag is not distinguishable "
            "from a volatility flag on real outcomes.")
