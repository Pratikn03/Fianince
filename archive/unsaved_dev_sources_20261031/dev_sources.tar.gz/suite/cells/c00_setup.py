# ============================================================================
# CELL 0 — SETUP (run first, every session)
# Creates folders, installs packages, defines record() which writes every
# result to results/<TEST_ID>.json and prints one PASS / FAIL / REPORT line.
#
# Result kinds (they are printed and saved, and the paper must use the same label):
#   "theorem-check"  numerical check of a theorem on simulated systems
#   "simulation"     property of an estimator / controller in a simulated market
#   "real-data"      computed from downloaded Binance files in THIS session
#   "audit"          checks on the manuscript, code or repository
# ============================================================================
import os, sys, json, time, math, glob, re, io, zipfile, hashlib, subprocess, warnings, itertools
import urllib.request

IN_COLAB = "google.colab" in sys.modules

def _pip(pkg, mod=None):
    try:
        __import__(mod or pkg)
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", pkg], check=True)

for _p, _m in [("pymupdf", "fitz"), ("pyarrow", "pyarrow"), ("scipy", "scipy"), ("pandas", "pandas")]:
    _pip(_p, _m)

import numpy as np
import pandas as pd
from scipy import linalg, optimize, stats

warnings.filterwarnings("ignore", category=RuntimeWarning)

# ---- Folders --------------------------------------------------------------
# Set USE_DRIVE = True to keep downloaded data and results across Colab resets.
USE_DRIVE = False
if IN_COLAB and USE_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = "/content/drive/MyDrive/ceiling_suite"
elif IN_COLAB:
    BASE = "/content/ceiling_suite"
else:
    BASE = os.path.abspath("ceiling_suite_local")

RESULTS = os.path.join(BASE, "results")
DATA = os.path.join(BASE, "data")
FIGS = os.path.join(BASE, "figures")
PREREG = os.path.join(BASE, "prereg")
for _d in (RESULTS, DATA, FIGS, PREREG):
    os.makedirs(_d, exist_ok=True)

SEED = 20261018

def rng(offset=0):
    """Independent, reproducible random generator per test."""
    return np.random.default_rng(SEED + offset)

def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, float):
        return None if not math.isfinite(o) else o
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    return o

def record(test_id, passed, kind, metrics, criterion="", note=""):
    """passed: True / False / None (None = REPORT: a result reported whatever it is)."""
    assert kind in {"theorem-check", "simulation", "real-data", "audit"}, kind
    status = "REPORT" if passed is None else ("PASS" if passed else "FAIL")
    out = {
        "test_id": test_id, "status": status, "kind": kind,
        "criterion": criterion, "note": note, "metrics": _clean(metrics),
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "seed": SEED,
    }
    with open(os.path.join(RESULTS, f"{test_id}.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(f"[{status}] {test_id} ({kind})" + (f" — {criterion}" if criterion else ""))
    if note:
        print("        note:", note)
    return out

def loglog_slope(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    ok = (x > 0) & (y > 0) & np.isfinite(y)
    b = np.polyfit(np.log(x[ok]), np.log(y[ok]), 1)
    return float(b[0])

print("IN_COLAB =", IN_COLAB, "| results ->", RESULTS)
