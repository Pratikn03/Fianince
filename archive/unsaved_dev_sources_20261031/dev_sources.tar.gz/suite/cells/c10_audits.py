# ============================================================================
# CELL A1 — HARD-CODED RESULT SCAN  (integrity check; run before anything else)
# Finds headline numbers from the papers typed into code as literals.
# Every hit must be either deleted or replaced by code that computes it.
# ============================================================================
KEY_NUMBERS = ["34.54", "16.67", "3.55", "2.37", "14.16", "22.87", "40.79",
               "25.31", "26.52", "0.906", "0.904", "9.83", "29.59", "0.2562",
               "98.3", "66.19", "385.05", "1.98", "19.42", "9.84", "43.80", "26.10"]
# Upload your OLD notebook (e.g. Untitled8.ipynb) to /content so it is scanned too.
NOTEBOOKS_TO_SCAN = [p for p in (glob.glob("/content/*.ipynb") if IN_COLAB else glob.glob("/mnt/user-data/uploads/*.ipynb"))
                     if "Ceiling_Test_Suite" not in p]

def _code_lines():
    for path in glob.glob(f"{REPO}/**/*.py", recursive=True):
        if "/.git/" in path or "/archive/" in path:
            continue
        try:
            for i, line in enumerate(open(path, errors="ignore"), 1):
                yield path, i, line
        except Exception:
            pass
    for nb in NOTEBOOKS_TO_SCAN:
        try:
            cells = json.load(open(nb))["cells"]
        except Exception:
            continue
        for ci, c in enumerate(cells):
            if c["cell_type"] != "code":
                continue
            for i, line in enumerate("".join(c["source"]).split("\n"), 1):
                yield f"{os.path.basename(nb)}[cell {ci}]", i, line

hits = []
pat = re.compile(r"(?<![\d.])(" + "|".join(re.escape(k) for k in KEY_NUMBERS) + r")(?![\d])")
for path, i, line in _code_lines():
    s = line.strip()
    if s.startswith("#"):
        continue
    m = pat.search(s)
    if m:
        # "typed_value": number assigned as data (e.g. "mean": 34.54 or x = 14.16)
        # "typed_into_latex": number written by hand into manuscript text by code
        n = re.escape(m.group(1))
        if re.search(r"[:=\[,(]\s*" + n + r"\s*[,}\])]?", s) and "\\" not in s and "$" not in s:
            cat = "typed_value"
        else:
            cat = "typed_into_latex"
        hits.append({"where": f"{path}:{i}", "number": m.group(1), "category": cat, "code": s[:160]})

by_file = pd.Series([h["where"].rsplit(":", 1)[0] for h in hits]).value_counts() if hits else pd.Series(dtype=int)
typed = [h for h in hits if h["category"] == "typed_value"]
latex = [h for h in hits if h["category"] == "typed_into_latex"]
print(f"{len(typed)} headline numbers typed as DATA values; {len(latex)} typed by hand into LaTeX text")
print("\n--- typed as data values (most serious: a result that is not computed) ---")
for h in typed[:60]:
    print(f"  {h['where']:60s} {h['number']:>7s} | {h['code'][:95]}")
record("A1_hardcoded_scan", len(typed) == 0, "audit",
       {"n_typed_values": len(typed), "n_typed_into_latex": len(latex),
        "typed_values": typed, "typed_into_latex": latex, "files": by_file.to_dict()},
       criterion="no headline result typed into code as a data value",
       note="Fix: every number in the papers must be read from results/*.json produced by a test cell.")
