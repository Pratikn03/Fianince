# ============================================================================
# CELL T0 — THE COHORT ECONOMY OF PAPER 1 (shared by all theorem checks)
#   x_t = a x_{t-1} + kappa * sum_i q_i y_{i,t-1} + kappa v_t
#   y_{i,t} = (1 - eta_i) y_{i,t-1} + eta_i x_t
# Merged measure: weights w_i = q_i * eta_i on memory rates r_i = 1 - eta_i,
# feedback kernel k_m = sum_i w_i r_i^m  (G(z) = sum_i w_i z / (z - r_i)).
# ============================================================================
def impulse_from_kernel(k, a, kappa, L):
    """Price impulse response h_0..h_{L-1} to v_0 = 1, given kernel k_m = sum w_i r_i^m.
    Uses g_t = sum_{s<=t} k_{t-s} h_s and h_{t+1} = a h_t + kappa g_t."""
    k = np.asarray(k, float)
    h = np.zeros(L)
    h[0] = kappa
    for t in range(L - 1):
        g = np.dot(k[:t + 1][::-1], h[:t + 1])
        h[t + 1] = a * h[t] + kappa * g
    return h

def kernel(w, r, L):
    m = np.arange(L)[:, None]
    return (np.asarray(w)[None, :] * np.asarray(r)[None, :] ** m).sum(1)

def impulse(w, r, a, kappa, L):
    return impulse_from_kernel(kernel(w, r, L), a, kappa, L)

def kernel_from_impulse(h, a, kappa):
    """Deconvolution: recover k from h (lower-triangular Toeplitz solve)."""
    L = len(h)
    g = (h[1:] - a * h[:-1]) / kappa
    T = linalg.toeplitz(h[:L - 1], np.zeros(L - 1))
    return linalg.solve_triangular(T, g, lower=True)

def is_stable(w, r, a, kappa):
    """Closed-loop eigenvalues of the (K+1)-state system."""
    K = len(w)
    eta = 1 - np.asarray(r)
    q = np.asarray(w) / eta
    A = np.zeros((K + 1, K + 1))
    A[0, 0] = a
    A[0, 1:] = kappa * q
    for i in range(K):           # y_i,t = r_i y_i,t-1 + eta_i x_t  (substitute x_t)
        A[1 + i, :] = eta[i] * A[0, :]
        A[1 + i, 1 + i] += r[i]
    return float(np.max(np.abs(np.linalg.eigvals(A)))) < 1

def matched_pair(K, seed=0):
    """Two K-atom positive measures on [-1,1] whose moments 0..2K-2 agree and
    whose moment 2K-1 differs (Gauss rule vs Gauss-Radau rule with a fixed node).
    Returns (sA, wA), (sB, wB) and the moment gap at order 2K-1."""
    sA, wA = np.polynomial.legendre.leggauss(K)
    wA = wA / wA.sum()
    target = np.array([np.sum(wA * sA ** j) for j in range(2 * K - 1)])
    fixed = -1.0                                # Radau: one node fixed at -1
    def resid(z):
        s = np.concatenate([[fixed], z[:K - 1]])
        w = z[K - 1:]
        return np.array([np.sum(w * s ** j) for j in range(2 * K - 1)]) - target
    z0 = np.concatenate([np.linspace(-0.5, 0.9, K - 1), np.full(K, 1.0 / K)])
    sol = optimize.least_squares(resid, z0, xtol=1e-15, ftol=1e-15, gtol=1e-15)
    sB = np.concatenate([[fixed], sol.x[:K - 1]])
    wB = sol.x[K - 1:]
    gap = np.sum(wB * sB ** (2 * K - 1)) - np.sum(wA * sA ** (2 * K - 1))
    assert np.max(np.abs(resid(sol.x))) < 1e-10, "moment matching failed"
    assert np.all(wB > 0) and len(np.unique(np.round(sB, 8))) == K, "Radau rule invalid"
    return (sA, wA), (sB, wB), float(gap)

def power_norms(J, K=3000):
    out, P = [], np.eye(len(J))
    for _ in range(K):
        out.append(np.linalg.norm(P, 2)); P = P @ J
        if out[-1] < 1e-14:
            break
    return np.array(out)

A_DEF, KAPPA_DEF, W_TOTAL, R_CENTER = 0.5, 1.0, 0.10, 0.70
print("cohort model helpers ready")
