# ============================================================================
# CELL R2 — CORE CODE-CORRECTNESS TESTS (appendix material, not evidence)
# R2-T1 ledger identity, R2-T3 Toeplitz positive definiteness, R2-T5 merged-measure
# invariance, R2-T9 data integrity log.
# ============================================================================
# R2-T1: execution at P* + Σ_{s<t} h_{t-s} v_s + ½ h_0 v_t + c·sign(v_t).
# For a flat round trip (Σ v = 0) the cash loss equals ½ vᵀ T_h v + c ||v||₁ with T_h[t,s] = h_|t-s|.
Rr = rng(90); worst = 0.0
for _ in range(1000):
    K = Rr.integers(1, 4); r = Rr.uniform(0.1, 0.9, K); w = Rr.uniform(0, 0.15, K)
    if not is_stable(w, r, A_DEF, KAPPA_DEF):
        continue
    n = int(Rr.integers(4, 40)); h = impulse(w, r, A_DEF, KAPPA_DEF, n); c = Rr.uniform(0, 0.1)
    v = Rr.normal(size=n); v -= v.mean()
    cash = 0.0
    for t in range(n):
        px = 100.0 + sum(h[t - s] * v[s] for s in range(t)) + 0.5 * h[0] * v[t] + c * np.sign(v[t])
        cash -= v[t] * px                       # buy v_t > 0 pays, sell receives
    loss = -cash                                # Σ v = 0, so terminal inventory is flat
    T = linalg.toeplitz(h)
    worst = max(worst, abs(loss - (0.5 * v @ T @ v + c * np.abs(v).sum())))
record("R2-T1_ledger_identity", worst < 1e-9, "audit", {"max_abs_error": worst},
       criterion="|ledger loss - (½vᵀT v + c||v||₁)| < 1e-9 on 1,000 random probes")

# R2-T3: Toeplitz of a positive-economy response is positive definite
min_eig = np.inf
for _ in range(1000):
    K = Rr.integers(1, 4); r = Rr.uniform(0.1, 0.9, K); w = Rr.uniform(0, 0.15, K)
    if not is_stable(w, r, A_DEF, KAPPA_DEF):
        continue
    h = impulse(w, r, A_DEF, KAPPA_DEF, 60)
    min_eig = min(min_eig, np.linalg.eigvalsh(linalg.toeplitz(h)).min())
record("R2-T3_toeplitz_pd", min_eig > 0, "audit", {"min_eigenvalue": min_eig},
       criterion="smallest eigenvalue of T_h > 0 over 1,000 stable positive economies")

# R2-T5: same merged measure -> identical responses; different measure -> different
h1 = impulse([0.06], [0.7], A_DEF, KAPPA_DEF, 200)
h2 = impulse([0.02, 0.04], [0.7, 0.7], A_DEF, KAPPA_DEF, 200)            # split, same rate
h3 = impulse([0.03, 0.03], [0.65, 0.75], A_DEF, KAPPA_DEF, 200)          # different measure
record("R2-T5_merged_invariance", bool(np.max(np.abs(h1 - h2)) < 1e-12 and np.max(np.abs(h1 - h3)) > 1e-6), "audit",
       {"same_measure_max_diff": np.max(np.abs(h1 - h2)), "different_measure_max_diff": np.max(np.abs(h1 - h3))},
       criterion="identical for equal merged measures, different otherwise")

# R2-T9: every downloaded file was checked against Binance's published SHA-256
dl = pd.DataFrame(DOWNLOAD_LOG)
if len(dl):
    dl.to_csv(os.path.join(RESULTS, "data_manifest_sha256.csv"), index=False)
record("R2-T9_data_integrity", True if len(dl) or glob.glob(os.path.join(DATA, "*.parquet")) else None, "audit",
       {"files_downloaded_this_session": len(dl), "cached_files": len(glob.glob(os.path.join(DATA, "*.parquet")))},
       criterion="every downloaded archive matched its official .CHECKSUM (load_day raises otherwise)",
       note="results/data_manifest_sha256.csv lists the hashes; put it in the replication package.")
