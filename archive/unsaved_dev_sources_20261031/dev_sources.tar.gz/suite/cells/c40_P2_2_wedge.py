# ============================================================================
# CELL P2.2 — UNIT-INVARIANT AMPLIFICATION ON REAL CRASHES + ARTIFACT NULL   (gate G1)
# Estimator (per 10-minute window, 1-second bars), following the repo's pipeline:
#   x_t = log-price deviation from its EMA (bp), f_t = next-second signed taker flow ($1M)
#   VAR(1) with intercept on z_t = (x_t, f_t)  ->  Ĵ (2x2)
# Statistics (all dimensionless and invariant to the units of x and f):
#   M_std = max_k || e_xᵀ J̃^k ||₂ with J̃ = D⁻¹ Ĵ D, D = diag(sd x, sd f)   <- PRIMARY
#           (the paper's M_C made unit-free: the state is measured in standard deviations)
#   A_xx  = max_k |(Ĵ^k)_{11}|      price-to-price amplification (reported)
#   hump  = max_k |(Ĵ^k)_{12}| / |Ĵ_{12}|   delayed peak of price response to a flow shock (reported)
#   rho   = spectral radius of Ĵ
# Window sets:
#   "stress_ex_ante": windows whose PREVIOUS 10 minutes had top-decile realized vol (no outcome selection)
#   "all_crash_day":  every window on the crash day
#   "ordinary":       every window on panel days in 2021-2023 (placebo)
#   "outcome_selected": top-10 |return| windows per crash day (old method; shown for comparison only)
# Artifact null: keep each window's REAL flow, generate price with NO feedback
#   (Δp = κ̂ f + σ̂ e), push through the identical EMA + VAR pipeline.
# ============================================================================
WIN, SPAN, KMAX = 600, 120, 300

def var1_J(x, f):
    """OLS VAR(1) with intercept. Returns NaNs for degenerate windows (no trades / flat price)."""
    Z = np.column_stack([x, f])
    if not np.all(np.isfinite(Z)) or Z[:, 0].std() < 1e-9 or Z[:, 1].std() < 1e-12:
        return np.full((2, 2), np.nan)
    X = np.column_stack([np.ones(len(Z) - 1), Z[:-1]])
    B = np.linalg.lstsq(X, Z[1:], rcond=None)[0]
    return B[1:].T

STAT = "M_std"          # primary statistic used by the gate tests

def _powers_rows(J, kmax):
    """Rows e_xᵀ J^k for k = 0..kmax (fast eigen form, loop fallback), shape (kmax+1, 2)."""
    w, V = np.linalg.eig(J)
    if np.max(np.abs(w)) < 1.05 and np.linalg.cond(V) < 1e8:
        Vi = np.linalg.inv(V)
        k = np.arange(kmax + 1)[:, None]
        return np.real((w[None, :] ** k) @ (V[0, :][:, None] * Vi))
    rows, P = [], np.eye(2)
    for _ in range(kmax + 1):
        rows.append(P[0].copy()); P = P @ J
        if np.abs(P).max() > 1e8:
            break
    return np.array(rows)

def window_stats(J, sd_x, sd_f, kmax=KMAX):
    if not np.all(np.isfinite(J)) or sd_x <= 0 or sd_f <= 0:
        return {"M_std": np.nan, "A_xx": np.nan, "hump": np.nan, "rho": np.nan}
    D = np.diag([sd_x, sd_f]); Jt = np.linalg.solve(D, J @ D)
    R_raw = _powers_rows(J, kmax); R_std = _powers_rows(Jt, kmax)
    h = np.abs(R_raw[1:, 1])                     # (J^k)_{12}, k >= 1
    return {"M_std": float(np.linalg.norm(R_std, axis=1).max()),
            "A_xx": float(np.abs(R_raw[:, 0]).max()),
            "hump": float(h.max() / h[0]) if h[0] > 1e-15 else np.nan,
            "rho": float(np.max(np.abs(np.linalg.eigvals(J))))}

def amp_stats(J, kmax=KMAX):
    """(A_xx, rho) — kept for the predictive cell."""
    st = window_stats(J, 1.0, 1.0, kmax)
    return st["A_xx"], st["rho"]

def day_windows(day, span=SPAN, win=WIN, delta=1):
    p, f, v = bars(day, delta)
    x = ema_dev(p, span)
    f_next = np.roll(f, -1)
    n = len(p) // win
    out = []
    for i in range(1, n):            # skip first window (EMA burn-in)
        s = slice(i * win, (i + 1) * win - 1)
        prev = slice((i - 1) * win, i * win)
        st = window_stats(var1_J(x[s], f_next[s]), x[s].std(), f_next[s].std())
        st.update({"i": i, "rv_prev": float(np.std(np.diff(p[prev]))),
                   "abs_ret": float(abs(p[s][-1] - p[s][0]))})
        out.append(st)
    return pd.DataFrame(out).dropna(subset=[STAT]).reset_index(drop=True)

def null_window_stats(day, i, B, R, span=SPAN, win=WIN):
    """Artifact null for window i: real flow, no-feedback price, same pipeline."""
    p, f, _ = bars(day, 1)
    lo = max(0, i * win - 5 * span)
    seg = slice(lo, (i + 1) * win)
    dp = np.diff(p[seg]); ff = f[seg][1:]
    X = np.column_stack([np.ones(len(ff)), ff])
    beta, *_ = np.linalg.lstsq(X, dp, rcond=None)
    sig = np.std(dp - X @ beta)
    fn = np.roll(f[seg], -1)
    stats_ = []
    for _ in range(B):
        dps = beta[1] * ff + sig * R.normal(size=len(ff))
        ps = np.concatenate([[0.0], np.cumsum(dps)])
        xs = ema_dev(ps, span)
        w = slice(len(ps) - win, len(ps) - 1)
        st = window_stats(var1_J(xs[w], fn[w]), xs[w].std(), fn[w].std())
        stats_.append([st[STAT], st["hump"]])
    return np.array(stats_, float)          # (B, 2): primary statistic, hump

def boot_mean_ci(v, R, B=2000, block=3):
    v = np.asarray(v); n = len(v)
    nb = int(np.ceil(n / block))
    means = []
    for _ in range(B):
        starts = R.integers(0, max(1, n - block + 1), nb)
        idx = np.concatenate([np.arange(s, min(s + block, n)) for s in starts])[:n]
        means.append(v[idx].mean())
    return float(np.mean(v)), [float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))]

print("Downloading crash days and 2021-2023 panel days (cached after first run)...")
crash_data = {k: load_day("BTCUSDT", d) for k, d in {**CRASH_DAYS, **OOS_CRASH_DAYS}.items()}
ord_dates = [d for d in PANEL_DAYS if int(d[:4]) in TRAIN_YEARS]
ord_data = load_days("BTCUSDT", ord_dates)
assert len(ord_data) >= 0.9 * len(ord_dates), "too many panel days failed to download"

R22 = rng(22)
crash_w = {k: day_windows(v) for k, v in crash_data.items()}
ord_w = pd.concat([day_windows(v).assign(day=d) for d, v in ord_data.items()], ignore_index=True)
rv_cut = np.quantile(ord_w["rv_prev"], 0.90)          # ex-ante stress trigger, set on ordinary days

rows = []
def _row(name, sub):
    m, ci = boot_mean_ci(sub[STAT], R22)
    return {"set": name, "n_windows": len(sub), f"mean_{STAT}": m, "ci95": ci,
            "median_hump": sub["hump"].median(), "share_A_xx_gt_1": float(np.mean(sub["A_xx"] > 1 + 1e-9)),
            "mean_rho": sub["rho"].mean()}
rows.append(_row("ordinary (2021-23 panel)", ord_w))
null_rows = {}
for k, w in crash_w.items():
    stress = w[w["rv_prev"] >= rv_cut]
    for label, sub in [("all_crash_day", w), ("stress_ex_ante", stress),
                       ("outcome_selected(top10|ret|)", w.nlargest(10, "abs_ret"))]:
        if len(sub) < 3:
            continue
        rows.append(_row(f"{k}:{label}", sub))
    # artifact null on the ex-ante stress windows (or all windows if none qualify)
    target = stress if len(stress) >= 3 else w
    sims = np.array([null_window_stats(crash_data[k], int(i), 50, R22) for i in target["i"]])  # (n_w, 50, 2)
    null_means = np.nanmean(sims[:, :, 0], 0)            # null distribution of the window-mean (primary)
    null_hump = np.nanmedian(sims[:, :, 1], 0)           # null distribution of the window-median hump
    obs, obs_h = target[STAT].mean(), target["hump"].median()
    null_rows[k] = {"observed_mean": obs, "null_mean": float(null_means.mean()),
                    "null_p99": float(np.quantile(null_means, 0.99)),
                    "p_value": float((1 + np.sum(null_means >= obs)) / (1 + len(null_means))),
                    "share_windows_M_std_gt_1": float(np.mean(target[STAT] > 1 + 1e-9)),
                    "observed_median_hump": obs_h, "null_hump_p99": float(np.quantile(null_hump, 0.99)),
                    "hump_p_value": float((1 + np.sum(null_hump >= obs_h)) / (1 + len(null_hump))),
                    "n_windows": len(target)}

tab22 = pd.DataFrame(rows)
print(tab22.to_string(index=False))
print(pd.DataFrame(null_rows).T.to_string())
in_sample = [k for k in CRASH_DAYS]
g1 = all(null_rows[k]["observed_mean"] > null_rows[k]["null_p99"] for k in in_sample)
record("P2.2-T2_artifact_null_G1", g1, "real-data", {"table": tab22.to_dict("list"), "null": null_rows},
       criterion="crash-day stress mean M_std > 99th pct of the no-feedback pipeline null, all 4 events",
       note="If FAIL: write that empirical amplification is not distinguishable from pipeline artifacts. "
            "M_std = 1 means no transient growth at all in standardized units. Also read hump_p_value: "
            "a delayed price peak beyond the no-feedback null is the T6 signature.")

placebo_pass = sum(
    tab22.loc[tab22["set"] == f"{k}:stress_ex_ante", f"mean_{STAT}"].squeeze() > np.quantile(ord_w[STAT], 0.95)
    for k in in_sample if (tab22["set"] == f"{k}:stress_ex_ante").any())
record("P2.2-T3_calm_placebo", bool(placebo_pass >= 3), "real-data",
       {"events_above_ordinary_p95": int(placebo_pass), "ordinary_p95": np.quantile(ord_w[STAT], 0.95)},
       criterion="stress-window mean M_std above the ordinary-window 95th pct for >= 3 of 4 events")

sel = {k: {"ex_ante": tab22.loc[tab22["set"] == f"{k}:stress_ex_ante", f"mean_{STAT}"].tolist(),
           "outcome_selected": tab22.loc[tab22["set"] == f"{k}:outcome_selected(top10|ret|)", f"mean_{STAT}"].tolist()}
       for k in crash_w}
record("P2.2-T4_selection", None, "real-data", sel,
       note="Report both. If amplification appears only in outcome-selected windows, it is a selection effect.")

# ---- Unit invariance (P2.2-T1) --------------------------------------------
d0 = crash_data["May2021"]; p0, f0, _ = bars(d0); x0 = ema_dev(p0, SPAN); fn0 = np.roll(f0, -1)
s = slice(30000, 30599)
xa, fa = x0[s], fn0[s]; xb, fb_ = x0[s] * 10, fn0[s] * 1e-3
J1, J2 = var1_J(xa, fa), var1_J(xb, fb_)
w1, w2 = window_stats(J1, xa.std(), fa.std()), window_stats(J2, xb.std(), fb_.std())
st1 = float(np.linalg.norm(_powers_rows(J1, KMAX), axis=1).max())     # raw state norm (paper's M_C style)
st2 = float(np.linalg.norm(_powers_rows(J2, KMAX), axis=1).max())
inv_ok = all(abs(w1[k] - w2[k]) <= 1e-6 * max(1, abs(w1[k])) for k in ("M_std", "A_xx", "hump"))
record("P2.2-T1_unit_invariance", bool(inv_ok), "real-data",
       {"original": w1, "rescaled": w2, "raw_state_norm_original": st1, "raw_state_norm_rescaled": st2},
       criterion="M_std, A_xx, hump unchanged when price ×10 and flow ×0.001; raw state norm changes")

# ---- Sensitivity (P2.2.5) ---------------------------------------------------
sens = []
for span in (60, 120, 300):
    for delta in (1, 5):
        win = WIN // delta
        o = pd.concat([day_windows(v, max(2, span // delta), win, delta) for v in list(ord_data.values())[::6]])
        c = pd.concat([day_windows(v, max(2, span // delta), win, delta) for k, v in crash_data.items() if k in CRASH_DAYS])
        sens.append({"ema_span_s": span, "bar_s": delta, f"ordinary_mean_{STAT}": o[STAT].mean(),
                     f"crash_mean_{STAT}": c[STAT].mean(), "difference": c[STAT].mean() - o[STAT].mean()})
sens = pd.DataFrame(sens); print(sens.round(4).to_string(index=False))
record("P2.2-T5_sensitivity", None, "real-data", sens.to_dict("list"),
       note="The headline must hold (same sign) across EMA span and bar size; otherwise report the dependence.")
