# ============================================================================
# CELL P1.5 — FEEDBACK ESTIMATORS UNDER ORDER SPLITTING (simulation, 500 reps)
# Simulated market (all parameters known):
#   y_t  = (1-η) y_{t-1} + η Δp_{t-1}        algorithm memory of past returns
#   u_t  = ρ u_{t-1} + ν_t                   persistent order-splitting flow
#   q_t  = γ y_t + u_t                        signed flow
#   Δp_t = κ q_t + λ z_t + e_t                z_t: observed exogenous price shock
# Instruments for y_t: z_{t-1}, z_{t-2}, z_{t-3} (move y through Δp, independent of u).
# Tests: size at γ=0 (P1.5-T1), 95% coverage at γ=0.2 (P1.5-T2), placebo instrument (P1.5-T3).
# ============================================================================
def nw_cov(Xh, e, lags):
    """Newey-West long-run covariance of Xh*e."""
    g = Xh * e[:, None]
    S = g.T @ g
    for l in range(1, lags + 1):
        w = 1 - l / (lags + 1)
        G = g[l:].T @ g[:-l]
        S += w * (G + G.T)
    return S

def _proj(Z, M):
    """P_Z M without forming the n x n projection matrix."""
    return Z @ np.linalg.solve(Z.T @ Z, Z.T @ M)

def iv_fit(y, X, Z, kind="2sls", lags=10):
    """X: regressors (incl. const), Z: instruments (incl. const). Returns beta, HAC se."""
    if kind == "ols":
        Xh = X
    elif kind == "2sls":
        Xh = _proj(Z, X)
    elif kind == "liml":
        Yall = np.column_stack([y, X[:, 1:]])
        Yd = Yall - Yall.mean(0)                       # M_exog with exog = constant
        A = Yd.T @ Yd
        Bm = Yall.T @ Yall - Yall.T @ _proj(Z, Yall)
        kk = np.min(np.real(linalg.eigvals(A, Bm)))
        Xh = X - kk * (X - _proj(Z, X))                # (I - k M_Z) X
    beta = np.linalg.solve(Xh.T @ X, Xh.T @ y)
    e = y - X @ beta
    Ainv = np.linalg.inv(Xh.T @ X)
    V = Ainv @ nw_cov(Xh, e, lags) @ Ainv.T
    return beta, np.sqrt(np.diag(V))

def simulate_market(T, gamma, R, eta=0.3, rho=0.8, kappa=0.5, lam=1.0):
    y = np.zeros(T); u = np.zeros(T); q = np.zeros(T); dp = np.zeros(T)
    z = R.normal(size=T); nu = R.normal(size=T); e = R.normal(size=T)
    for t in range(1, T):
        y[t] = (1 - eta) * y[t - 1] + eta * dp[t - 1]
        u[t] = rho * u[t - 1] + nu[t]
        q[t] = gamma * y[t] + u[t]
        dp[t] = kappa * q[t] + lam * z[t] + e[t]
    return y, q, z

def estimators(y, q, z, rho_oracle=0.8):
    s = slice(4, None)
    Y, X = q[s], np.column_stack([np.ones(len(q) - 4), y[s]])
    Z = np.column_stack([np.ones(len(q) - 4), z[3:-1], z[2:-2], z[1:-3]])
    out = {}
    out["OLS"] = iv_fit(Y, X, None, "ols")
    # Cochrane-Orcutt with oracle rho, and with estimated rho (iterated)
    for name, rh in [("CO_oracle", rho_oracle), ("CO_estimated", None)]:
        r_ = rh if rh is not None else 0.0
        for _ in range(1 if rh is not None else 20):
            Yq = q[5:] - r_ * q[4:-1]; Xq = np.column_stack([np.ones(len(Yq)), y[5:] - r_ * y[4:-1]])
            b = np.linalg.lstsq(Xq, Yq, rcond=None)[0]
            if rh is None:
                res = q[4:] - b[1] * y[4:]
                r_ = np.dot(res[1:], res[:-1]) / np.dot(res[:-1], res[:-1])
        out[name] = iv_fit(Yq, Xq, None, "ols")
    out["2SLS"] = iv_fit(Y, X, Z, "2sls")
    out["LIML"] = iv_fit(Y, X, Z, "liml")
    # first-stage F
    b1 = np.linalg.lstsq(Z, y[s], rcond=None)[0]
    rss1 = np.sum((y[s] - Z @ b1) ** 2); rss0 = np.sum((y[s] - y[s].mean()) ** 2)
    F = ((rss0 - rss1) / 3) / (rss1 / (len(Y) - 4))
    return out, F

T15, REPS15 = 3000, 500
R15 = rng(15)
cover, size, bias, Fs = {}, {}, {}, []
for rep in range(REPS15):
    for gam, store in [(0.2, cover), (0.0, size)]:
        y, q, z = simulate_market(T15, gam, R15)
        out, F = estimators(y, q, z)
        if gam == 0.2:
            Fs.append(F)
        for k, (b, se) in out.items():
            lo, hi = b[1] - 1.96 * se[1], b[1] + 1.96 * se[1]
            store.setdefault(k, []).append(lo <= gam <= hi)
            if gam == 0.2:
                bias.setdefault(k, []).append(b[1] - gam)
tab15 = pd.DataFrame({
    "coverage_at_0.2": {k: np.mean(v) for k, v in cover.items()},
    "rejection_at_0": {k: 1 - np.mean(v) for k, v in size.items()},
    "bias": {k: np.mean(v) for k, v in bias.items()},
    "rmse": {k: np.sqrt(np.mean(np.square(v))) for k, v in bias.items()},
})
tab15["label"] = np.where(tab15["coverage_at_0.2"].between(0.93, 0.97), "consistent", "biased / invalid inference")
print(tab15.round(4).to_string()); print(f"median first-stage F = {np.median(Fs):.1f}")
size_ok = tab15.loc[["2SLS", "LIML", "CO_oracle"], "rejection_at_0"].between(0.031, 0.069).all()
record("P1.5-T1_size", bool(size_ok), "simulation", tab15["rejection_at_0"].to_dict(),
       criterion="rejection rate at γ=0 in [3.1%, 6.9%] for estimators called consistent")
record("P1.5-T2_coverage", None, "simulation", {"table": tab15.to_dict(), "median_first_stage_F": np.median(Fs)},
       criterion="label every estimator outside [93%, 97%] coverage as biased in the paper's table",
       note="Use this table to decide which estimator the paper may call consistent.")

# Placebo instrument: future z (independent of y_t) should be weak and give nothing
y, q, z = simulate_market(T15, 0.2, rng(151))
s = slice(4, -6)
Zp = np.column_stack([np.ones(len(q[s])), z[9:-1], z[8:-2], z[7:-3]])
b1 = np.linalg.lstsq(Zp, y[s], rcond=None)[0]
rss1 = np.sum((y[s] - Zp @ b1) ** 2); rss0 = np.sum((y[s] - y[s].mean()) ** 2)
Fp = ((rss0 - rss1) / 3) / (rss1 / (len(y[s]) - 4))
record("P1.5-T3_placebo_instrument", bool(Fp < 10), "simulation", {"placebo_first_stage_F": Fp},
       criterion="placebo instrument first-stage F < 10")

# ============================================================================
# CELL P2.4 — CONFIDENCE SET FOR THE OPERATOR AND CERTIFIED WEDGE (simulation)
# Window VAR(1) like the real-data estimator (n = 600). ε_t = 95th percentile of
# ||Ĵ* - Ĵ||₂ over a residual bootstrap. Coverage: true J inside the ball.
# Certificate: robust bound M/(1-εS) from T8, available when εS < 1.
# ============================================================================
def var1_ols(Z):
    X = np.column_stack([np.ones(len(Z) - 1), Z[:-1]])
    B = np.linalg.lstsq(X, Z[1:], rcond=None)[0]
    return B[1:].T, B[0], Z[1:] - X @ B

def sim_var(J, n, R, burn=200, Sig=None):
    d = len(J); Z = np.zeros((n + burn, d))
    L = np.linalg.cholesky(Sig) if Sig is not None else np.eye(d)
    for t in range(1, n + burn):
        Z[t] = J @ Z[t - 1] + L @ R.normal(size=d)
    return Z[burn:]

J_true = np.array([[0.90, 0.35], [0.02, 0.60]])
R24 = rng(24)
inside, cert = 0, 0
REPS24, B24, n24 = 300, 199, 600
eps_list = []

def var1_batch(Zb):
    """OLS VAR(1) with intercept for a batch of paths Zb (B, n, d) -> J (B, d, d)."""
    B_, n_, d_ = Zb.shape
    X = np.concatenate([np.ones((B_, n_ - 1, 1)), Zb[:, :-1]], 2)
    Y = Zb[:, 1:]
    XtX = np.einsum("bti,btj->bij", X, X); XtY = np.einsum("bti,btj->bij", X, Y)
    Bc = np.linalg.solve(XtX, XtY)
    return np.transpose(Bc[:, 1:], (0, 2, 1))

for rep in range(REPS24):
    Z = sim_var(J_true, n24, R24)
    Jh, c, res = var1_ols(Z)
    idx = R24.integers(0, len(res), (B24, len(res)))
    Zb = np.zeros((B24, len(Z), 2)); Zb[:, 0] = Z[0]
    for t in range(1, len(Z)):
        Zb[:, t] = c + Zb[:, t - 1] @ Jh.T + res[idx[:, t - 1]]
    Jb = var1_batch(Zb)
    dists = np.linalg.norm(Jb - Jh[None], 2, axis=(1, 2))
    eps_t = np.quantile(dists, 0.95); eps_list.append(eps_t)
    inside += np.linalg.norm(Jh - J_true, 2) <= eps_t
    pn = power_norms(Jh, 2000)
    cert += eps_t * pn.sum() < 1
cov24 = inside / REPS24
print(f"bootstrap ball coverage = {cov24:.3f}; certificate available in {cert}/{REPS24} windows; median ε = {np.median(eps_list):.4f}")
record("P2.4-T1_coverage", bool(0.925 <= cov24 <= 0.975), "simulation",
       {"coverage": cov24, "reps": REPS24, "boot": B24, "median_eps": np.median(eps_list),
        "certificate_available_share": cert / REPS24},
       criterion="true J inside the 95% ball in [92.5%, 97.5%] of reps",
       note="If coverage is low, the paper must call ε_t approximate or use a larger ball.")
