# ============================================================================
# CELL A4 — DO THE PAPERS' NUMBERS COME FROM THESE RESULTS?  (P2.1-T1)
# Lists every number with >= 3 significant figures in each paper's abstract and
# main text that does not match any value in results/*.json.  Each orphan must
# be traced to a results file or removed.
# ============================================================================
def _all_values(o, out):
    if isinstance(o, dict):
        for v in o.values():
            _all_values(v, out)
    elif isinstance(o, list):
        for v in o:
            _all_values(v, out)
    elif isinstance(o, (int, float)) and o is not None and not isinstance(o, bool):
        out.append(float(o))
    return out

vals = []
for fp in glob.glob(os.path.join(RESULTS, "*.json")):
    vals += _all_values(json.load(open(fp)), [])
vals = np.array(vals) if vals else np.array([np.nan])

def _matches(xstr):
    x = float(xstr.replace(",", ""))
    dec = len(xstr.split(".")[1]) if "." in xstr else 0
    tol = 0.5 * 10 ** (-dec)
    cands = [vals, vals * 100, vals / 100]                     # allow percent conversions
    return any(np.any(np.abs(c - x) <= tol + 1e-12) for c in cands)

orph = {}
for label, path in [("paper1", PAPER1_PDF), ("paper2", PAPER2_PDF)]:
    if not path:
        continue
    pages = pdf_pages_text(path)
    main = []
    for p in pages:
        head = "\n".join(p.strip().split("\n")[:3])
        if re.search(r"^\s*(Internet Appendix|References|Appendix)\s*$|^\s*(Internet Appendix|References)\b", head, re.M) and len(main) > 5:
            break
        main.append(p)
    text = " ".join(main)
    nums = set(re.findall(r"(?<![\w.])(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+\.\d{2,})(?![\w])", text))
    nums = {n for n in nums if len(re.sub(r"[^0-9]", "", n).lstrip("0")) >= 3}
    orph[label] = sorted(n for n in nums if not _matches(n))
    print(f"{label}: {len(nums)} numbers in main text, {len(orph[label])} not produced by any result file")
    print("   e.g.", orph[label][:40])
record("P2.1-T1_number_trace", all(len(v) == 0 for v in orph.values()), "audit",
       {k: {"n_orphans": len(v), "orphans": v} for k, v in orph.items()},
       criterion="every 3+ significant-figure number in abstract/main text appears in results/*.json",
       note="Expected to FAIL now. Rewrite each number from these result files; delete what no file supports.")

# ============================================================================
# CELL Z — SUMMARY TABLE AND DOWNLOAD
# ============================================================================
rows = []
for fp in sorted(glob.glob(os.path.join(RESULTS, "*.json"))):
    r = json.load(open(fp))
    rows.append({"test": r["test_id"], "status": r["status"], "kind": r["kind"], "criterion": r["criterion"][:90]})
summary = pd.DataFrame(rows)
summary.to_csv(os.path.join(RESULTS, "SUMMARY.csv"), index=False)
pd.set_option("display.max_colwidth", 95); pd.set_option("display.width", 220)
print(summary.to_string(index=False))
print("\nCounts:", summary.groupby(["kind", "status"]).size().to_dict())

zip_path = os.path.join(BASE, "ceiling_results.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "*")) + glob.glob(os.path.join(PREREG, "*")):
        z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zip_path)
if IN_COLAB:
    from google.colab import files
    files.download(zip_path)
