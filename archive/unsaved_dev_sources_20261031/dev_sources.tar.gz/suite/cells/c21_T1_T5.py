# ============================================================================
# CELL T1 — GENERAL K-COHORT RATE (lower bound side)
# Claim to check: two K-cohort economies whose merged measures agree in moments
# 0..2K-2 have price responses differing by ||h_A - h_B|| ∝ (Δη)^(2K-1), so the
# Le Cam lower bound on resets is N* ∝ σ² / ||h_A - h_B||² ∝ (Δη)^-(4K-2).
# Pass: fitted slope of N* within ±0.3 of -(4K-2) for K = 2, 3, 4.
# The matching UPPER bound is checked separately (ESPRIT, cell T9) and must be proved.
# ============================================================================
L_T1, SIGMA_T1 = 400, 1.0
t1 = {}
for K, grid in [(2, np.geomspace(0.005, 0.08, 9)), (3, np.geomspace(0.01, 0.08, 8)), (4, np.geomspace(0.02, 0.08, 7))]:
    (sA, wA), (sB, wB), gap = matched_pair(K)
    dist, nstar = [], []
    for d in grid:
        rA, rB = R_CENTER + d * sA, R_CENTER + d * sB
        assert is_stable(W_TOTAL * wA, rA, A_DEF, KAPPA_DEF) and is_stable(W_TOTAL * wB, rB, A_DEF, KAPPA_DEF)
        hA = impulse(W_TOTAL * wA, rA, A_DEF, KAPPA_DEF, L_T1)
        hB = impulse(W_TOTAL * wB, rB, A_DEF, KAPPA_DEF, L_T1)
        D = np.linalg.norm(hA - hB)
        dist.append(D)
        nstar.append(SIGMA_T1 ** 2 * np.log(1 / (4 * 0.05)) / D ** 2)   # Le Cam / KL, 5% error
    slope = loglog_slope(grid[:5], nstar[:5])          # asymptotic (small-Δη) regime
    t1[K] = {"delta_grid": grid, "response_gap": dist, "N_star_lower": nstar,
             "slope_N": slope, "target": -(4 * K - 2), "moment_gap_order_2K-1": gap}
    print(f"K={K}: slope of N* = {slope:6.2f}  (target {-(4*K-2)})")
record("T1_K_cohort_rate", all(abs(v["slope_N"] - v["target"]) <= 0.3 for v in t1.values()),
       "theorem-check", t1, criterion="slope within ±0.3 of -(4K-2), K=2,3,4",
       note="Lower bound only. Upper bound: see T9 (ESPRIT) and a written proof.")

# ============================================================================
# CELL T2 — PASSIVE IDENTIFICATION (what passive price data can and cannot do)
# (a) Key lemma: the zeros of H(z) are the memory rates r_i, so with |r_i| < 1
#     H is minimum-phase and a single-shock price spectrum identifies H, hence
#     the merged measure. Check on 2,000 random stable economies, including
#     signed (mean-reverting) cohorts.
# (b) Exploratory: when each cohort's memory also receives its own shock, does
#     the price spectrum still pin down the parameters? Rank of the Jacobian.
# NOTE: this corrects the plan's first draft of T2. Signed cohorts do NOT break
# minimum phase. Passive noise generally HELPS identification (consistent with
# Paper 1 Prop 2.10); the barrier is the COST (T3: same δ^-4 / Δη^-6 orders).
# ============================================================================
def H_poly(w, r, a, kappa):
    """H(z) = kappa*D(z) / ((z-a)D(z) - kappa*N(z)), with D = prod(z-r_i), N = sum w_i z prod_{j!=i}(z-r_j)."""
    D = np.poly(r)
    N = np.zeros(len(r) + 1)
    for i in range(len(r)):
        N += w[i] * np.concatenate([np.atleast_1d(np.poly(np.delete(r, i))), [0.0]])
    den = np.polysub(np.polymul([1.0, -a], D), kappa * N)
    return kappa * D, den

R2 = rng(2)
n_ok, n_tot, worst = 0, 0, 0.0
for _ in range(2000):
    K = R2.integers(1, 5)
    r = R2.uniform(0.05, 0.95, K)
    w = R2.uniform(-0.15, 0.15, K)
    if not is_stable(w, r, A_DEF, KAPPA_DEF):
        continue
    num, den = H_poly(w, r, A_DEF, KAPPA_DEF)
    zeros = np.roots(num)
    n_tot += 1
    match = np.max(np.abs(np.sort(zeros) - np.sort(r))) < 1e-8
    inside = np.all(np.abs(zeros) < 1) and np.all(np.abs(np.roots(den)) < 1)
    n_ok += bool(match and inside)
print(f"(a) zeros of H equal memory rates and lie inside the unit disk: {n_ok}/{n_tot}")
record("T2a_min_phase", n_ok == n_tot, "theorem-check",
       {"n_ok": n_ok, "n_tested": n_tot},
       criterion="all stable economies (signed weights allowed) are minimum-phase with zeros = r_i")

# (b) two shock sources: price noise w_t and cohort memory noise e_{i,t}
def price_spectrum_2shock(theta, omegas, a=A_DEF, kappa=KAPPA_DEF):
    q1, q2, eta1, eta2, sw, se = theta
    S = np.zeros_like(omegas)
    for j, om in enumerate(omegas):
        z = np.exp(1j * om)
        r = np.array([1 - eta1, 1 - eta2]); q = np.array([q1, q2]); eta = np.array([eta1, eta2])
        # state equations in z: (1 - a z^-1) X = kappa z^-1 sum q_i Y_i + Wn
        #                         (1 - r_i z^-1) Y_i = eta_i X + E_i
        M = np.zeros((3, 3), complex)
        M[0, 0] = 1 - a / z; M[0, 1:] = -kappa * q / z
        for i in range(2):
            M[1 + i, 0] = -eta[i]; M[1 + i, 1 + i] = 1 - r[i] / z
        Minv = np.linalg.inv(M)
        S[j] = sw ** 2 * abs(Minv[0, 0]) ** 2 + se ** 2 * (abs(Minv[0, 1]) ** 2 + abs(Minv[0, 2]) ** 2)
    return S

omg = np.linspace(0.01, np.pi, 300)
theta0 = np.array([0.12, 0.10, 0.20, 0.45, 1.0, 0.3])
eps = 1e-6
Jac = np.column_stack([(np.log(price_spectrum_2shock(theta0 + eps * e, omg)) -
                        np.log(price_spectrum_2shock(theta0 - eps * e, omg))) / (2 * eps)
                       for e in np.eye(len(theta0))])
sv = np.linalg.svd(Jac, compute_uv=False)
rank = int(np.sum(sv > sv[0] * 1e-8))
print(f"(b) two-shock spectrum: Jacobian rank {rank} of {len(theta0)} parameters; singular values {np.round(sv, 6)}")
record("T2b_two_shock_rank", None, "theorem-check",
       {"rank": rank, "n_params": len(theta0), "singular_values": sv},
       note="Rank < 6 => local non-identification from passive prices; rank = 6 => identified locally.")

# ============================================================================
# CELL T3 — PASSIVE SAMPLE COMPLEXITY via Whittle KL
# T* ∝ 1 / KL rate. Pass: slope -4 (symmetric pair, δ) and -6 (K=2 matched pair).
# ============================================================================
def spec_single_shock(w, r, omegas, a=A_DEF, kappa=KAPPA_DEF):
    num, den = H_poly(np.asarray(w), np.asarray(r), a, kappa)
    z = np.exp(1j * omegas)
    return np.abs(np.polyval(num, z) / np.polyval(den, z)) ** 2

def whittle_kl(S0, S1, omegas):
    ratio = S1 / S0
    return np.trapezoid(ratio - 1 - np.log(ratio), omegas) / (2 * np.pi)

omg3 = np.linspace(1e-4, np.pi, 20001)
grid_d = np.geomspace(0.01, 0.12, 9)
kl_pair, kl_k2 = [], []
(sA2, wA2), (sB2, wB2), _ = matched_pair(2)
for d in grid_d:
    S0 = spec_single_shock([W_TOTAL], [R_CENTER], omg3)
    S1 = spec_single_shock([W_TOTAL / 2, W_TOTAL / 2], [R_CENTER - d, R_CENTER + d], omg3)
    kl_pair.append(whittle_kl(S0, S1, omg3))
    SA = spec_single_shock(W_TOTAL * wA2, R_CENTER + d * sA2, omg3)
    SB = spec_single_shock(W_TOTAL * wB2, R_CENTER + d * sB2, omg3)
    kl_k2.append(whittle_kl(SA, SB, omg3))
s_pair, s_k2 = loglog_slope(grid_d, 1 / np.array(kl_pair)), loglog_slope(grid_d, 1 / np.array(kl_k2))
print(f"T* slope: pair {s_pair:.2f} (target -4), K=2 matched {s_k2:.2f} (target -6)")
record("T3_passive_rate", abs(s_pair + 4) <= 0.3 and abs(s_k2 + 6) <= 0.3, "theorem-check",
       {"delta": grid_d, "kl_pair": kl_pair, "kl_K2": kl_k2, "slope_pair": s_pair, "slope_K2": s_k2},
       criterion="slopes -4 and -6 within ±0.3")

# ============================================================================
# CELL T4 — DISCLOSURE: cohort-tagged flow removes the separation barrier
# Regulator sees each cohort's flow u_{i,t} = q_i y_{i,t-1} with noise.
# Pass: RMSE of recovered weights is flat in Δη (|slope| <= 0.3).
# ============================================================================
def tagged_estimate(w, r, T, sig_u, R, a=A_DEF, kappa=KAPPA_DEF, sig_x=1.0):
    K = len(w); eta = 1 - r; q = w / eta
    x = np.zeros(T); y = np.zeros((T, K))
    shocks = R.normal(0, sig_x, T)
    for t in range(1, T):
        x[t] = a * x[t - 1] + kappa * np.dot(q, y[t - 1]) + shocks[t]
        y[t] = r * y[t - 1] + eta * x[t]
    u = q[None, :] * y + R.normal(0, sig_u, (T, K))     # observed tagged flow
    est = []
    for i in range(K):  # u_{i,t} = r_i u_{i,t-1} + w_i x_t  (noise -> use IV: x_t, u_{i,t-2})
        Y = u[2:, i]; X = np.column_stack([u[1:-1, i], x[2:]]); Z = np.column_stack([u[:-2, i], x[2:]])
        b = np.linalg.solve(Z.T @ X, Z.T @ Y)
        est.append(b[1])
    return np.array(est)

R4 = rng(4)
rmse4 = []
grid4 = np.geomspace(0.01, 0.12, 6)
for d in grid4:
    w_true = np.array([W_TOTAL / 2, W_TOTAL / 2]); r_true = np.array([R_CENTER - d, R_CENTER + d])
    errs = [tagged_estimate(w_true, r_true, 5000, 0.05, R4) - w_true for _ in range(60)]
    rmse4.append(float(np.sqrt(np.mean(np.square(errs)))))
s4 = loglog_slope(grid4, rmse4)
print(f"tagged-flow weight RMSE by Δη: {np.round(rmse4, 5)}  slope {s4:.2f}")
record("T4_disclosure", abs(s4) <= 0.3, "theorem-check",
       {"delta": grid4, "rmse": rmse4, "slope": s4, "T": 5000, "reps": 60},
       criterion="weight error flat in Δη (|slope| <= 0.3)")

# ============================================================================
# CELL T5 — SPECTRAL BLINDNESS
# Markets with the same eigenvalues, the same one-step price volatility and the
# same stationary price variance, but worst-case transient loss growing without bound.
# ============================================================================
lam1, lam2, s1, V = 0.80, 0.70, 1.0, 5.0
rows5 = []
for th in [1.0, 3.0, 10.0, 30.0, 100.0]:
    J = np.array([[lam1, th], [0.0, lam2]])
    def var_price(s2):
        P = linalg.solve_discrete_lyapunov(J, np.diag([s1, s2]))
        return P[0, 0]
    base = var_price(0.0)
    s2 = (V - base) / (var_price(1.0) - base)   # variance is affine in s2
    P = linalg.solve_discrete_lyapunov(J, np.diag([s1, s2]))
    powers = [np.linalg.matrix_power(J, k) for k in range(200)]
    peak_state = max(np.linalg.norm(Pk[0, :]) for Pk in powers)          # worst unit state shock
    cum_state = sum(np.linalg.norm(Pk[0, :]) for Pk in powers)
    rows5.append({"theta": th, "eigs": np.sort(np.linalg.eigvals(J).real), "one_step_vol": s1,
                  "stationary_var": P[0, 0], "peak_gain": peak_state, "cum_gain": cum_state})
df5 = pd.DataFrame(rows5)
print(df5[["theta", "stationary_var", "peak_gain", "cum_gain"]].to_string(index=False))
same_var = np.allclose(df5["stationary_var"], V, atol=1e-8)
grows = np.all(np.diff(df5["peak_gain"]) > 0)
record("T5_spectral_blindness", bool(same_var and grows), "theorem-check", df5.to_dict("list"),
       criterion="identical eigenvalues, one-step vol and stationary variance; peak gain strictly increasing")
