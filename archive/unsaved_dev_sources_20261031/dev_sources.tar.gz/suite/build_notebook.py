import json, re, os

CELLS = "/home/claude/suite/cells"
order = [
    ("md", """# Ceiling Test Suite — Paper 1 & Paper 2
**Run every cell top to bottom** (Runtime → Run all). It downloads real Binance data, checks the theorems numerically, runs every test in the revision plan, and writes each result to `results/<TEST_ID>.json` with one line: **PASS**, **FAIL** or **REPORT**.

**Rules this notebook enforces**
1. **No typed-in results.** Every number in either paper must come from a `results/*.json` file made here. Cell A1 lists the numbers your old notebook typed in by hand (cell 84's crash CIs, the `40.79 * ...` curve, the `M_C: 22.87 / 14.16` dicts). Do not reuse any of them.
2. **Labels travel with numbers.** Each result is tagged `theorem-check`, `simulation`, `real-data` or `audit`. The paper must use the same word.
3. **FAIL is information, not a reason to tune.** If a real-data test fails, report it and change the claim (see the gate rules in the plan doc).
4. **The 2024 test year is opened once.** Cell P2.5a writes the pre-registration; P2.5b counts every time the test set is evaluated.

**Run time:** about 30–60 min the first time (downloads ~110 days of 1-second data); a few minutes after that (cached). Set `USE_DRIVE = True` in cell 0 to keep data across Colab resets.

**Upload first:** your newest Paper 1 and Paper 2 PDFs (named and anonymous) to `/content`.
"""),
    ("md", "## 0. Setup"), "c00_setup.py", "c01_repo_and_files.py", "c02_binance_loader.py",
    ("md", "## A. Integrity and manuscript audits\nA1 must be clean before any paper is posted. A2–A3 are Phase 0 of the plan (split, recompile, anonymity)."),
    "c10_audits.py", "c11_overlap_anonymity.py",
    ("md", """## T. Theorem checks (simulation)
Numerical checks of the theorems in the plan doc. A PASS means the statement held in every simulated case, which tells you it is worth proving. It is **not** a proof. Write the proofs from the proof routes in the plan.

Note on **T2**: the check corrected the plan's first draft. Signed cohorts do *not* break minimum phase, and passive noise *helps* identification. The barrier is cost (T3), not impossibility."""),
    "c20_model.py", "c21_T1_T5.py", "c22_T6_T9.py",
    ("md", "## P1 / P2. Estimator and controller properties (simulation)"),
    "c30_sim_tests.py",
    ("md", """## P2 / P1. Real-data tests (Binance 1-second klines, checksum-verified)
These are the tests that decide gates **G1** (artifact null) and **G2** (predictive power). Whatever they show goes in the paper."""),
    "c40_P2_2_wedge.py", "c41_T6E_P1.py", "c42_P2_5_predictive.py",
    ("md", "## R. Code-correctness tests (appendix material)"), "c50_repo_tests.py",
    ("md", "## Z. Number trace, summary and download\nA4 lists every number in the papers that no result file supports. Rewrite or delete each one."),
    "c90_summary.py",
    ("md", """## After you run it: what each result decides
| Test | Gate | If PASS | If FAIL |
|---|---|---|---|
| A1 hard-coded scan | before posting anything | — | delete every typed-in number from both papers; replace with values from `results/` |
| S1-T1, S1-T2, S2-T1, S3-T1 | G0 | papers are split and clean | finish Phase 0 (split, recompile from LaTeX, anonymize) |
| P2.2-T2 artifact null | **G1** | keep "empirical amplification" as a headline | say amplification is not distinguishable from pipeline artifacts; lead with theory (T6) |
| P2.2-T4 selection | G1 | — | if only outcome-selected windows amplify, drop the crash-window claim |
| T6-E overshoot | supports T6 | cite flow-held-fixed overshoot as evidence for the depth channel | present T6 as theory; say klines cannot separate the channel (needs depth data) |
| P2.5 predictive | **G2** | abstract may say "predicts" with the CI | abstract must not say "predicts"; report the null result in the body |
| P2.7 vol ablation | G2 | wedge adds information beyond volatility | write that it is not distinguishable from a volatility flag |
| P1.6 EMA placebo | P1 | — | write "no evidence of feedback beyond EMA mechanics" |
| P1.5 coverage table | P1 | — | call every estimator outside 93–97% coverage biased |
| T1–T9 | proofs | write the proof from the route in the plan doc | the statement is false as written; change it |
| P2.1-T1 number trace | G4 | every number traced | rewrite or delete each orphan number |

Send me `ceiling_results.zip` (downloaded by the last cell) and I will check the results and draft the paper text from them."""),
]

def split_cells(src):
    # split at banner lines that start a new "# CELL ..." block
    parts = re.split(r"(?m)^(?=# =+\n# CELL )", src)
    return [p.rstrip() + "\n" for p in parts if p.strip()]

nb_cells = []
for item in order:
    if isinstance(item, tuple):
        nb_cells.append({"cell_type": "markdown", "metadata": {}, "source": item[1].splitlines(True)})
        continue
    for chunk in split_cells(open(os.path.join(CELLS, item)).read()):
        nb_cells.append({"cell_type": "code", "metadata": {}, "execution_count": None,
                         "outputs": [], "source": chunk.splitlines(True)})

nb = {"nbformat": 4, "nbformat_minor": 5,
      "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"},
                   "language_info": {"name": "python"}, "colab": {"provenance": []}},
      "cells": nb_cells}
out = "/home/claude/suite/Ceiling_Test_Suite.ipynb"
json.dump(nb, open(out, "w"), indent=1)
print(out, len(nb_cells), "cells")
