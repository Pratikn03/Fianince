import json, os, time, traceback, sys
os.chdir('/home/claude')
nb = json.load(open('/home/claude/suite/Ceiling_Test_Suite.ipynb'))
g = {'__name__': '__main__'}
dbg = open('/home/claude/suite/debug_inject.py').read()
for i, c in enumerate(nb['cells']):
    if c['cell_type'] != 'code':
        continue
    src = ''.join(c['source'])
    title = [l for l in src.split('\n') if l.startswith('# CELL')][0][:70]
    print(f'\n### cell {i}: {title}', flush=True)
    t = time.time()
    try:
        exec(compile(src, f'cell{i}', 'exec'), g)
    except Exception:
        traceback.print_exc()
    print(f'--- {time.time()-t:.1f}s', flush=True)
    if 'REAL DATA LOADER' in src:
        exec(dbg, g)   # sandbox only: Binance is unreachable here
