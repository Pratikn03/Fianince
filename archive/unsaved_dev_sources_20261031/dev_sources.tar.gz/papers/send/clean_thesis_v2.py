"""Send copy of the thesis (24 Oct 2026): fresh copy of the repository's thesis/, cleaned like the first send copy.

Pratik and Prashant Niroula are the only authors; no planning tags, placeholders, script or file names or
Lean identifiers in the text; the tool-neutral statement on AI use. The cleaned paper sources in
../ceiling_suite/papers (unchanged since the first send copy) feed Chapters 2 and 3. Never touches the repository.
"""
import os
import re
import shutil

H = os.path.dirname(os.path.abspath(__file__))
SRC = "/home/claude/fianince/thesis"
TH = os.path.join(H, "thesis")


def rd(p):
    return open(p).read()


def wr(p, s):
    open(p, "w").write(s)


def rep(name, a, b, count=1):
    p = os.path.join(TH, name)
    s = rd(p)
    assert s.count(a) == count, (name, a[:90], s.count(a))
    wr(p, s.replace(a, b))


if os.path.exists(TH):
    shutil.rmtree(TH)
shutil.copytree(SRC, TH, ignore=shutil.ignore_patterns("*.aux", "*.log", "*.out", "*.toc", "*.pdf", "__pycache__",
                                                      "withdrawn", "validation_logs"))

# ---------- front matter ----------
s = rd(os.path.join(TH, "thesis.tex"))
a = s.index("\\vfill\n\\noindent\\fcolorbox{black!60}")
s = s[:a] + "\\vfill\n" + s[s.index("\\end{titlepage}"):]
s = s.replace("{\\normalsize Thesis blueprint, October 2026\\par}", "{\\normalsize Draft, October 2026\\par}")
i = s.index("\\newcommand{\\tagbox}"); j = s.index("\n", s.index("\\newcommand{\\pendbox}")) + 1
s = s[:i] + ("\\newcommand{\\Proved}{}\n\\newcommand{\\ProvedIn}[1]{}\n\\newcommand{\\Conj}{}\n\\newcommand{\\Target}{}\n"
             "\\newcommand{\\Pending}{}\n\\newcommand{\\pendbox}[2]{\\paragraph{Status.}#2}\n") + s[j:]
s = s.replace("% status tags used in the new chapters\n", "")
old = s[s.index("Chapter~\\ref{ch:p1} reproduces the paper"):s.index("\\tableofcontents")]
s = s.replace(old, """Chapter~\\ref{ch:p1} is based on the paper \\emph{Auditable Memory and Financial Identification Limits in Electronic Limit Order Books}, and Chapter~\\ref{ch:p2} on the paper \\emph{From Human Markets to Machine Markets: Transient Amplification, an Exact Depth Condition, and a Maximal Pre-Trade Guard}, both joint with Prashant Niroula. Chapter~\\ref{ch:p3}, the introduction and the conclusion are the candidate's own work.

\\paragraph{Use of AI tools.} The research questions, the modelling and design choices, the data collection, the pre-registration of every test and all final decisions are the author's own. The author used AI assistants to help derive and check proofs, write and debug analysis code, and edit the text. The author verified every result, ran all code and takes full responsibility for the content.

""")
wr(os.path.join(TH, "thesis.tex"), s)

# ---------- Chapter 4 ----------
rep("ch4_paper3.tex", "Results proved here are marked \\Proved{}; results proved in Chapters~\\ref{ch:p1}--\\ref{ch:p2} are marked accordingly; the conjecture is marked as such.",
    "One question is left open and stated as a conjecture: the behaviour of the guard when agents respond to it.")
rep("ch4_paper3.tex", "The generated matrices, tolerances and diagnostics are recorded in \\texttt{checks/R\\_multiasset.json}.",
    "The generated matrices, tolerances and diagnostics are recorded in the replication package.")
rep("ch4_paper3.tex", "The script \\texttt{checks/check\\_modulus.py} solves", "A replication script solves")
rep("ch4_paper3.tex", " Source: \\texttt{checks/R\\_multiagent\\_v2.json}.", "")
c4 = rd(os.path.join(TH, "ch4_paper3.tex"))
i = c4.index("\\paragraph{Formal scope.}"); j = c4.index("\\paragraph{Identification under learning, by contrast.}")
c4 = c4[:i] + ("\\paragraph{Formal verification.} The finite-cohort, finite-horizon safety induction, the drift, floor and sensitivity "
               "calculations of Corollary~\\ref{thm:lifetime}, the deterministic certification arithmetic, the comparison step of "
               "Proposition~\\ref{prop:multiasset_positive} for any number of assets and cohorts, and the strategic counterexample are "
               "checked in Lean~4 with Mathlib, as are, for finite atomic measures, the weak-duality bound and the bias of the affine "
               "interval in Theorem~\\ref{thm:dich}(iv). Gaussian coverage, general-measure integration, the minimax step and the lower "
               "bound of part (iv) and Theorem~\\ref{thm:philog}, which rest on Sion's minimax theorem and on potential theory, and the "
               "Neumann-series and limit steps of Proposition~\\ref{prop:multiasset_positive} are written proofs.\n\n") + c4[j:]
c4 = re.sub(r"are formalized as \\nolinkurl\{[^}]*\} and \\nolinkurl\{[^}]*\}\.", "are checked in Lean~4.", c4)
c4 = re.sub(r"\s*\(\\nolinkurl\{[^}]*\}(?:,\s*\\nolinkurl\{[^}]*\})*\)", "", c4)
c4 = c4.replace("Exact rational diagnostics are recorded separately in \\texttt{checks/R\\_strategic.json}.",
                "Exact rational diagnostics are recorded in the replication package.")
c4 = c4.replace("(specification hash \\texttt{58c32f9b\\ldots}, pushed with its runner in a commit of its own before the run)",
                "(specification hash \\texttt{58c32f9b\\ldots}, made public with its code before the run)")
wr(os.path.join(TH, "ch4_paper3.tex"), c4)

# ---------- Chapter 5 ----------
rep("ch5_conclusion.tex", "(specification hash \\texttt{0b6c31c0\\ldots}; pipeline, download code and a Colab notebook committed with it). The notebook downloads the data, opens the test once and writes the results, the numbers printed here and a log of the SHA-256 of every downloaded file.",
    "(specification hash \\texttt{0b6c31c0\\ldots}), together with the analysis code, which downloads the data, opens the test once and records the SHA-256 of every downloaded file.")
rep("ch5_conclusion.tex", "The analysis code and its notebook are committed with the addendum and refuse to run before 2 February 2027.",
    "The analysis code was registered with the addendum and will not run before 2 February 2027.")
rep("ch5_conclusion.tex", "The code and output of both are kept in the repository, marked as withdrawn, so that the record is complete.",
    "The code and output of both are kept in the replication package, marked as withdrawn, so that the record is complete.")

# ---------- tags and status words in Chapters 1, 4, 5 and Appendix A ----------
for f in ("ch1_intro.tex", "ch4_paper3.tex", "ch5_conclusion.tex", "appA_status.tex"):
    p = os.path.join(TH, f)
    s = rd(p)
    s = re.sub(r",\s*\\Proved\{\}\)", ")", s)
    s = s.replace(" & proved here\\\\", " & proved\\\\").replace("\\section{Status register}", "\\section{Summary of results}")
    s = s.replace("\\chapter{Status of results and notation across chapters}", "\\chapter{Summary of results and notation across chapters}")
    s = s.replace("\\caption{Main results of the thesis and their status}", "\\caption{Main results of the thesis}")
    s = s.replace("\\section{Status of the results}", "\\section{Summary of the results}")
    s = s.replace("Appendix~\\ref{app:status} lists the status of every main result and maps the notation across chapters.",
                  "Appendix~\\ref{app:status} summarizes the main results and maps the notation across chapters.")
    wr(p, s)

# ---------- chapter prefaces ----------
M = os.path.join(TH, "make_chapters.py")
s = rd(M)
s = s.replace('"joint with Suboh Alkhushayni, Yuhao Chen, Mansi Bhavsar and Prashant Niroula. It establishes',
              '"joint with Prashant Niroula. It establishes')
s = s.replace("of the thesis, reproduces the paper", "of the thesis, is based on the paper")
wr(M, s)

# ---------- checks ----------
bad = re.compile(r"Alkhushayni|Bhavsar|Yuhao|Claude|Anthropic|Antigravity|Gemini|ChatGPT|\[To be completed|nolinkurl|"
                 r"\\texttt\{[^}]*\.(py|json|ipynb)\}|blueprint|PENDING|TARGET")
for f in os.listdir(TH):
    if f.endswith(".tex") and f not in ("ch2_paper1.tex", "ch3_paper2.tex"):
        hits = bad.findall(rd(os.path.join(TH, f)))
        assert not hits, (f, hits[:5])
print("cleaned thesis copy")
