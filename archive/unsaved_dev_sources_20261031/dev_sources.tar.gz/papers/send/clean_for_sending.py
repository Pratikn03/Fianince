"""Make send copies: Pratik and Prashant Niroula as the only authors, no script or file names in the text,
no planning tags or placeholders in the thesis. Runs on the copies in this folder, never on the repository."""
import os
import re

H = os.path.dirname(os.path.abspath(__file__))
P1 = os.path.join(H, "ceiling_suite", "papers", "paper1")
P2 = os.path.join(H, "ceiling_suite", "papers", "paper2")
TH = os.path.join(H, "thesis")


def rd(p):
    return open(p).read()


def wr(p, s):
    open(p, "w").write(s)


def rep(path, a, b, count=1):
    s = rd(path)
    assert s.count(a) == count, (os.path.basename(path), a[:80], s.count(a))
    wr(path, s.replace(a, b))


# ---------- authors ----------
f2 = os.path.join(P2, "p2_front.tex")
rep(f2, "\\fancyhead[L]{\\small Niroula, Alkhushayni, Chen, Bhavsar, and Niroula}", "\\fancyhead[L]{\\small Niroula and Niroula}")
s = rd(f2)
a = s.index("\\author{Pratik Niroula")
b = s.index("\\and Prashant Niroula")
s = s[:a] + "\\author{Pratik Niroula\\thanks{Department of Computer Information Science, Minnesota State University, Mankato. \\texttt{pratik.niroula@mnsu.edu}.}\n" + s[b:]
wr(f2, s)
f1a = os.path.join(P1, "p1_appendix.tex")
rep(f1a, "\\bibitem[Niroula et~al.(2026)]{niroula2026b} Niroula, P., S. Alkhushayni, Y. Chen, M. Bhavsar, and P. Niroula (2026).",
    "\\bibitem[Niroula and Niroula(2026b)]{niroula2026b} Niroula, P., and P. Niroula (2026b).")
p2a = os.path.join(P2, "p2_appendix.tex")
rep(p2a, "\\bibitem[Niroula and Niroula(2026)]{niroula2026} Niroula, P., and P. Niroula (2026).",
    "\\bibitem[Niroula and Niroula(2026a)]{niroula2026} Niroula, P., and P. Niroula (2026a).")


# ---------- script and file names in the text ----------
def strip_kind(s):
    """Remove 'Kind: ...' provenance sentences from table notes, with balanced parentheses."""
    out, i = [], 0
    while True:
        j = s.find("Kind: ", i)
        if j < 0:
            out.append(s[i:])
            break
        k = j - 1
        while k >= 0 and s[k] == " ":
            k -= 1
        out.append(s[i:k + 1])
        m, depth = j + 6, 0
        while m < len(s):
            c = s[m]
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif c == "." and depth == 0 and (m + 1 == len(s) or s[m + 1] in " \n\\$}"):
                m += 1
                break
            elif c == "\n" and depth == 0:
                break
            m += 1
        i = m
    return "".join(out)


FILE = r"\\texttt\{[^{}]*?\.(?:py|json|ipynb|csv)\}"
BODY = ["p1_front.tex", "p1_ident.tex", "p1_account.tex", "p1_mixture.tex", "p1_disclosure.tex", "p1_empirics.tex"]
BODY2 = ["p2_front.tex", "p2_theory1.tex", "p2_t6.tex", "p2_infosafety.tex", "p2_guard.tex", "p2_disclosure.tex",
         "p2_equil.tex", "p2_evidence.tex", "p2_thin.tex", "p2_istests.tex", "p2_close.tex"]


def strip_files(s):
    s = strip_kind(s)
    # specification files named next to their hash: keep the hash
    s = re.sub(r"\(" + FILE + r",\s*(SHA-256 )", r"(\1", s)
    # sentences that only name scripts
    s = re.sub(r"\s*Recomputed columns from " + FILE + r"\.", "", s)
    s = re.sub(r"Estimators re-implemented in " + FILE + r":", "Estimators:", s)
    s = re.sub(r"From " + FILE + r",\s*using", "Computed using", s)
    s = re.sub(r"From " + FILE + r"(?:\s+and\s+" + FILE + r")?[;,]\s*([a-z])", lambda m: m.group(1).upper(), s)
    # chains like \texttt{a.py} $\to$ \texttt{b.json}, lists of files
    chain = FILE + r"(?:\s*(?:\$\\to\$|,|and|;)\s*(?:Part [A-Z]|" + FILE + r"))*"
    s = re.sub(r"\s*\(\s*" + chain + r"\s*\)", "", s)               # whole parenthetical is files
    s = re.sub(r";\s*" + chain + r"(?=\s*\))", "", s)                # '...; file)' -> '...)'
    s = re.sub(r",\s*" + chain + r"(?=\s*\))", "", s)                # '..., file)' -> '...)'
    s = re.sub(r"\(\s*" + chain + r"\s*[,;]\s*", "(", s)             # '(file, rest)' -> '(rest)'
    s = re.sub(r"\s*" + chain, "", s)                                # anything left
    s = s.replace("()", "").replace("( )", "").replace(" .", ".").replace(" ,", ",")
    return s


for d, files in ((P1, BODY), (P2, BODY2)):
    for f in files:
        p = os.path.join(d, f)
        wr(p, strip_files(rd(p)))
# table notes in the appendices also carry 'Kind:' sentences; the reproducibility map keeps its file names
for p in (f1a, p2a):
    t = rd(p)
    i = t.index("\\section{Reproducibility: source of every number}")
    wr(p, strip_files(t[:i]) + strip_kind(t[i:]))

# ---------- thesis ----------
T = os.path.join(TH, "thesis.tex")
s = rd(T)
a = s.index("\\vfill\n\\noindent\\fcolorbox{black!60}")
b = s.index("\\end{titlepage}")
s = s[:a] + "\\vfill\n" + s[b:]
s = s.replace("{\\normalsize Thesis blueprint, October 2026\\par}", "{\\normalsize Draft, October 2026\\par}")
s = s.replace("""\\newcommand{\\tagbox}[2]{\\fcolorbox{#1}{#1!7}{\\textsf{\\scriptsize #2}}}
\\newcommand{\\Proved}{\\tagbox{green!45!black}{PROVED IN THIS THESIS}}
\\newcommand{\\ProvedIn}[1]{\\tagbox{green!45!black}{PROVED IN #1}}
\\newcommand{\\Target}{\\tagbox{blue!70!black}{TARGET: STATEMENT FIXED, PROOF TO BE WRITTEN}}
\\newcommand{\\Conj}{\\tagbox{orange!85!black}{CONJECTURE}}
\\newcommand{\\Pending}{\\tagbox{red!70!black}{PENDING DATA}}
\\newcommand{\\pendbox}[2]{\\par\\medskip\\noindent\\fcolorbox{red!70!black}{red!4}{\\parbox{0.96\\linewidth}{\\small\\textbf{\\color{red!70!black}Pending --- #1.} #2}}\\par\\medskip}""",
"""\\newcommand{\\Proved}{}
\\newcommand{\\ProvedIn}[1]{}
\\newcommand{\\Conj}{}
\\newcommand{\\pendbox}[2]{\\paragraph{Status.}#2}""")
s = s.replace("% status tags used in the new chapters\n", "")
s = s.replace("""Chapter~\\ref{ch:p1} reproduces the paper \\emph{Auditable Memory and Financial Identification Limits in Electronic Limit Order Books}, joint with Prashant Niroula. Chapter~\\ref{ch:p2} reproduces the paper \\emph{From Human Markets to Machine Markets: Transient Amplification, an Exact Depth Condition, and a Maximal Pre-Trade Guard}, joint with Suboh Alkhushayni, Yuhao Chen, Mansi Bhavsar and Prashant Niroula. \\textit{[To be completed with the co-authors: the candidate's contribution to each chapter, and permission to include the papers.]} Chapter~\\ref{ch:p3} (Paper~3), the introduction and the conclusion are the candidate's own work.""",
"""Chapter~\\ref{ch:p1} is based on the paper \\emph{Auditable Memory and Financial Identification Limits in Electronic Limit Order Books}, and Chapter~\\ref{ch:p2} on the paper \\emph{From Human Markets to Machine Markets: Transient Amplification, an Exact Depth Condition, and a Maximal Pre-Trade Guard}, both joint with Prashant Niroula. Chapter~\\ref{ch:p3}, the introduction and the conclusion are the candidate's own work.

\\paragraph{Use of AI tools.} The author used Claude (Anthropic), an AI assistant, to write and debug analysis code, run checks of derivations and numerical results, and draft and edit text. Every number in the thesis is produced by code the author executed and archived in the replication package. The author reviewed all content and takes full responsibility for it.""")
assert "\\fcolorbox{black!60}" not in s and "[To be completed" not in s and "\\Target" not in s.split("\\begin{document}")[0]
wr(T, s)

C4 = os.path.join(TH, "ch4_paper3.tex")
rep(C4, "Results proved here are marked \\Proved{}; results proved in Chapters~\\ref{ch:p1}--\\ref{ch:p2} are marked accordingly; the open technical target and the conjecture are marked as such.",
    "Two questions are left open and stated as conjectures: the matching lower bound for the cost of certification, and the behaviour of the guard when agents respond to it.")
s = rd(C4)
old_iv = s[s.index("\\item \\emph{Matching lower bound.}"):s.index("\\end{enumerate}", s.index("\\item \\emph{Matching lower bound.}"))]
s = s.replace(old_iv, "")
s = s.replace("\\begin{proof}[Proof of (i)--(iii)]", "\\begin{proof}")
conj = ("\\begin{conjecture}[Matching lower bound]\\label{conj:lower}\nFor $g$ in a regular class (coefficients of eventually constant sign and at most polynomial growth), "
        "$N_{\\rm cert}(\\epsilon;F_g,\\mathcal M(\\bar r,B))\\ge c\\,\\sigma^2A_g(c'\\,T_g(\\epsilon))\\,\\epsilon^{-2}$ for constants $c,c'>0$ depending only on $(\\bar r,B,\\alpha)$.\n\\end{conjecture}\n\n")
s = s.replace("\\paragraph{What the theorem says.}", conj + "\\paragraph{What the theorem says.}", 1)
s = s.replace("making it a corollary of part (iv) is part of the target.", "deriving it from Conjecture~\\ref{conj:lower} would make it one.")
s = s.replace("\\paragraph{Proof plan for part (iv).}", "\\paragraph{Towards Conjecture~\\ref{conj:lower}.}")
s = s.replace("matching the leader--satellite analysis of Chapter~\\ref{ch:p2}, is a \\Target{}.", "matching the leader--satellite analysis of Chapter~\\ref{ch:p2}, is left open.")
s = s.replace("Pending --- multi-agent simulation", "")
assert "\\Target" not in s and "\\Pending" not in s, [x for x in ("\\Target", "\\Pending") if x in s]
wr(C4, s)
# remaining references to part (iv)
for f in ("ch1_intro.tex", "appA_status.tex", "ch5_conclusion.tex"):
    p = os.path.join(TH, f)
    s = rd(p)
    s = s.replace("Thm~\\ref{thm:dich}(iv)", "Conj.~\\ref{conj:lower}").replace("Theorem~\\ref{thm:dich}(iv)", "Conjecture~\\ref{conj:lower}")
    s = s.replace("(Theorem~\\ref{thm:dich}(i)--(iii), \\Proved{})", "(Theorem~\\ref{thm:dich})").replace("Thm~\\ref{thm:dich}(i)--(iii)", "Thm~\\ref{thm:dich}")
    s = s.replace(" (Theorem~\\ref{thm:sector}, \\Proved{})", " (Theorem~\\ref{thm:sector})").replace(" (Corollary~\\ref{thm:lifetime}, \\Proved{})", " (Corollary~\\ref{thm:lifetime})")
    s = s.replace(" & target\\\\", " & open (conjecture)\\\\").replace(" & pending data\\\\", " & planned\\\\").replace(" & proved here\\\\", " & proved\\\\")
    s = s.replace("\\section{Status register}", "\\section{Summary of results}")
    s = s.replace("\\chapter{Status of results and notation across chapters}", "\\chapter{Summary of results and notation across chapters}")
    s = s.replace("\\caption{Main results of the thesis and their status}", "\\caption{Main results of the thesis}")
    s = s.replace("\\section{Status of the results}", "\\section{Summary of the results}")
    assert "\\Proved" not in s and "\\Target" not in s and "\\Pending" not in s, (f, [x for x in ("\\Proved", "\\Target", "\\Pending") if x in s])
    wr(p, s)
rep(os.path.join(TH, "ch1_intro.tex"), "Appendix~\\ref{app:status} lists the status of every main result and maps the notation across chapters.",
    "Appendix~\\ref{app:status} summarizes the main results and maps the notation across chapters.")
# chapter prefaces
M = os.path.join(TH, "make_chapters.py")
s = rd(M)
s = s.replace('"joint with Suboh Alkhushayni, Yuhao Chen, Mansi Bhavsar and Prashant Niroula. It establishes',
              '"joint with Prashant Niroula. It establishes')
s = s.replace("This chapter, the first paper of the thesis, reproduces the paper", "This chapter, the first paper of the thesis, is based on the paper")
s = s.replace("This chapter, the second paper of the thesis, reproduces the paper", "This chapter, the second paper of the thesis, is based on the paper")
wr(M, s)
print("cleaned")
