"""Send copies of Papers 1 and 2 (24 Oct 2026): fresh copies of the repository's paper sources, cleaned as before.

Pratik and Prashant Niroula as the only authors, no script or file names in the text (the reproducibility map
keeps them), and the tool-neutral statement on AI use. Never touches the repository."""
import os
import re
import shutil

H = os.path.dirname(os.path.abspath(__file__))
SRC = "/home/claude/fianince/ceiling_suite/papers"
DST = os.path.join(H, "ceiling_suite", "papers")
if os.path.exists(DST + "_previous"):
    shutil.rmtree(DST + "_previous")
shutil.move(DST, DST + "_previous")
shutil.copytree(SRC, DST, ignore=shutil.ignore_patterns("*.aux", "*.log", "*.out", "*.toc", "__pycache__", "venv"))
P1 = os.path.join(DST, "paper1")
P2 = os.path.join(DST, "paper2")


def rd(p):
    return open(p).read()


def wr(p, s):
    open(p, "w").write(s)


def rep(path, a, b, count=1):
    s = rd(path)
    assert s.count(a) == count, (os.path.basename(path), a[:80], s.count(a))
    wr(path, s.replace(a, b))


# ---------- authors ----------
f2 = os.path.join(P2, "p2_front.tex")
rep(f2, "\\fancyhead[L]{\\small Niroula, Alkhushayni, Chen, Bhavsar, and Niroula}", "\\fancyhead[L]{\\small Niroula and Niroula}")
s = rd(f2)
a = s.index("\\author{Pratik Niroula")
b = s.index("\\and Prashant Niroula")
s = s[:a] + "\\author{Pratik Niroula\\thanks{Department of Computer Information Science, Minnesota State University, Mankato. \\texttt{pratik.niroula@mnsu.edu}.}\n" + s[b:]
wr(f2, s)
f1a = os.path.join(P1, "p1_appendix.tex")
rep(f1a, "\\bibitem[Niroula et~al.(2026)]{niroula2026b} Niroula, P., S. Alkhushayni, Y. Chen, M. Bhavsar, and P. Niroula (2026).",
    "\\bibitem[Niroula and Niroula(2026b)]{niroula2026b} Niroula, P., and P. Niroula (2026b).")
p2a = os.path.join(P2, "p2_appendix.tex")
rep(p2a, "\\bibitem[Niroula and Niroula(2026)]{niroula2026} Niroula, P., and P. Niroula (2026).",
    "\\bibitem[Niroula and Niroula(2026a)]{niroula2026} Niroula, P., and P. Niroula (2026a).")


# ---------- script and file names in the text ----------
def strip_kind(s):
    """Remove 'Kind: ...' provenance sentences from table notes, with balanced parentheses."""
    out, i = [], 0
    while True:
        j = s.find("Kind: ", i)
        if j < 0:
            out.append(s[i:])
            break
        k = j - 1
        while k >= 0 and s[k] == " ":
            k -= 1
        out.append(s[i:k + 1])
        m, depth = j + 6, 0
        while m < len(s):
            c = s[m]
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif c == "." and depth == 0 and (m + 1 == len(s) or s[m + 1] in " \n\\$}"):
                m += 1
                break
            elif c == "\n" and depth == 0:
                break
            m += 1
        i = m
    return "".join(out)


FILE = r"\\texttt\{[^{}]*?\.(?:py|json|ipynb|csv)\}"
BODY = ["p1_front.tex", "p1_ident.tex", "p1_account.tex", "p1_mixture.tex", "p1_disclosure.tex", "p1_empirics.tex"]
BODY2 = ["p2_front.tex", "p2_theory1.tex", "p2_t6.tex", "p2_infosafety.tex", "p2_guard.tex", "p2_disclosure.tex",
         "p2_equil.tex", "p2_evidence.tex", "p2_thin.tex", "p2_istests.tex", "p2_close.tex"]


def strip_files(s):
    s = strip_kind(s)
    # specification files named next to their hash: keep the hash
    s = re.sub(r"\(" + FILE + r",\s*(SHA-256 )", r"(\1", s)
    # sentences that only name scripts
    s = re.sub(r"\s*Recomputed columns from " + FILE + r"\.", "", s)
    s = re.sub(r"Estimators re-implemented in " + FILE + r":", "Estimators:", s)
    s = re.sub(r"From " + FILE + r",\s*using", "Computed using", s)
    s = re.sub(r"From " + FILE + r"(?:\s+and\s+" + FILE + r")?[;,]\s*([a-z])", lambda m: m.group(1).upper(), s)
    # chains like \texttt{a.py} $\to$ \texttt{b.json}, lists of files
    chain = FILE + r"(?:\s*(?:\$\\to\$|,|and|;)\s*(?:Part [A-Z]|" + FILE + r"))*"
    s = re.sub(r"\s*\(\s*" + chain + r"\s*\)", "", s)               # whole parenthetical is files
    s = re.sub(r";\s*" + chain + r"(?=\s*\))", "", s)                # '...; file)' -> '...)'
    s = re.sub(r",\s*" + chain + r"(?=\s*\))", "", s)                # '..., file)' -> '...)'
    s = re.sub(r"\(\s*" + chain + r"\s*[,;]\s*", "(", s)             # '(file, rest)' -> '(rest)'
    s = re.sub(r"\s*" + chain, "", s)                                # anything left
    s = s.replace("()", "").replace("( )", "").replace(" .", ".").replace(" ,", ",")
    return s


for d, files in ((P1, BODY), (P2, BODY2)):
    for f in files:
        p = os.path.join(d, f)
        wr(p, strip_files(rd(p)))
# table notes in the appendices also carry 'Kind:' sentences; the reproducibility map keeps its file names
for p in (f1a, p2a):
    t = rd(p)
    i = t.index("\\section{Reproducibility: source of every number}")
    wr(p, strip_files(t[:i]) + strip_kind(t[i:]))


# ---------- statement on AI use ----------
AI = ("\\paragraph{{Use of AI tools.}} The research questions, the modelling and design choices, the data collection, the "
      "pre-registration of every test and all final decisions are the authors' own. The authors used AI assistants to help "
      "derive and check proofs, write and debug analysis code, and edit the text. The authors verified every result, ran all "
      "code and take full responsibility for the content.")
for p in (os.path.join(P1, "p1_empirics.tex"), os.path.join(P2, "p2_close.tex")):
    s = rd(p)
    s = re.sub(r"\\paragraph\{Use of AI tools\.\}[^\n]*", lambda m: AI.format(), s, count=1)
    assert "Claude" not in s and "Anthropic" not in s
    wr(p, s)
for d in (P1, P2):
    for f in os.listdir(d):
        if f.endswith(".tex") and not f.startswith("paper"):
            t = rd(os.path.join(d, f))
            assert not re.search(r"Claude|Anthropic|Alkhushayni|Bhavsar", t), (f, re.findall(r"Claude|Anthropic|Alkhushayni|Bhavsar", t))
print("cleaned papers")
