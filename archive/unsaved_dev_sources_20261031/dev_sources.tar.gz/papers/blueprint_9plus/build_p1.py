"""Assemble the restructured ('9+ blueprint') Paper 1 from the current sources plus new text.
Every block of the current paper appears exactly once (main text or supplement). Results that do not exist yet appear
only inside red PENDING boxes."""
import os, re, subprocess, shutil
H = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(H, "..", "paper1")
OUT = os.path.join(H, "p1")
rd = lambda f: open(os.path.join(SRC, f)).read()
new = lambda f: open(os.path.join(OUT, f)).read()


def cut(text, start, end=None, include_end=False):
    i = text.index(start)
    j = len(text) if end is None else text.index(end, i + len(start)) + (len(end) if include_end else 0)
    return text[i:j], text[:i] + text[j:]


PENDING = r"""
\definecolor{pendred}{rgb}{0.65,0.05,0.05}
\newcommand{\pendinline}[1]{{\color{pendred}\textbf{[PENDING:} #1\textbf{]}}}
\newcommand{\pendbox}[2]{\par\medskip\noindent\fcolorbox{pendred}{red!4}{\parbox{0.965\linewidth}{\small\textbf{\color{pendred}PENDING --- #1.} #2}}\par\medskip}
"""
front = rd("p1_front.tex")
preamble = front[:front.index("\\title{")] + PENDING
if "xcolor" not in preamble:
    preamble = preamble.replace("\\usepackage{booktabs", "\\usepackage{xcolor}\n\\usepackage{booktabs", 1)
rellit, _ = cut(front, "\\subsection{Related literature}", "\\subsection{Outline}")
model = front[front.index("\\section{Model and microfoundations}"):]
model = model.replace(
    "its interior first-order condition maps the belief state into the market-response weight $q_i=\\beta_i/(\\lambda_{{\\rm tc},i}+\\gamma_{{\\rm inv},i})$",
    "its interior first-order condition, for a desk that carries no inventory from one period to the next, maps the belief state into the market-response weight $q_i=\\beta_i/(\\lambda_{{\\rm tc},i}+\\gamma_{{\\rm inv},i})$ (with carried inventory the rule gains a term $-\\gamma_{{\\rm inv},i}I_{i,t-1}/(\\lambda_{{\\rm tc},i}+\\gamma_{{\\rm inv},i})$, an additional mean-reverting state that we do not model)")
outline = (r"""\subsection{Outline}
Section~\ref{sec:model} sets out the model and its microfoundations, and Section~\ref{sec:ident} proves the identification boundary. Section~\ref{sec:resources} prices identification in executed quantity and capital, and Section~\ref{sec:account} computes the capital an account needs and converts it to dollars. Section~\ref{sec:mixtures} treats unknown mixtures, general memory and passive data, and Section~\ref{sec:learners} asks whether the predictions survive realistic learners. Section~\ref{sec:disclosure} prices disclosure, in samples, in data and in dollars. Section~\ref{sec:empsum} summarizes what reduced-form feedback indices measure, and Sections~\ref{sec:policy} and~\ref{sec:conclusion} conclude. The supplement contains the tri-region analysis, probing protocols, the spectral blind spot, the empirical feedback analysis in full and further results.

""")

ident = rd("p1_ident.tex")
account = rd("p1_account.tex")
tri, account = cut(account, "\\subsection{Observation design and the tri-region partition}", "\\subsection{Account-level capital and the gap to the lower bound}")
robust, account = cut(account, "\\subsection{Robustness: heteroskedastic impact and probing protocols}", "\\subsection{From par units to Bitcoin dollars}")
account = account.replace("\\subsection{Account-level capital and the gap to the lower bound}",
                          "The observation design, a tri-region partition of separations and budgets, and isolated-pulse benchmarks are in the supplement (Section~\\ref{sec:tri_supp}); here we go directly to the ledger.\n\n\\subsection{Account-level capital and the gap to the lower bound}", 1)
mixture = rd("p1_mixture.tex")
disc = rd("p1_disclosure.tex")
blind, disc = cut(disc, "\\section{A spectral blind spot}\\label{sec:blind}")
emp = rd("p1_empirics.tex")
empirics, emp = cut(emp, "\\section{Empirical feedback and its measurement}\\label{sec:empirics}", "\\section{Implications for supervision and market design}")
close = emp.replace("\\end{document}", "")

ns = new("new_sections.tex")
learners = ns[ns.index("%LEARNERS%") + 10:ns.index("%DOLLARS%")]
dollars = ns[ns.index("%DOLLARS%") + 9:ns.index("%EMPSUM%")]
empsum = ns[ns.index("%EMPSUM%") + 8:]
disc = disc.replace("\\subsection{Disclosure in real data}\\label{sec:disc_data}", dollars + "\\subsection{Disclosure in real data}\\label{sec:disc_data}", 1)

app = rd("p1_appendix.tex")
bib, app = cut(app, "\\begin{thebibliography}", "\\end{thebibliography}", include_end=True)
mainapp, app = cut(app, "\\section{Proofs}\\label{app:proofs}", "\\section{Internet appendix}\\label{app:ia}")
ia, app = cut(app, "\\section{Internet appendix}\\label{app:ia}", "\\section{Reproducibility: source of every number}")
ia = ia.replace("\\section{Internet appendix}\\label{app:ia}", "\\section{Further results}\\label{app:ia}", 1)
repro = app[app.index("\\section{Reproducibility: source of every number}"):].replace("\\end{document}", "")
supp_head = (r"""\clearpage
\begin{center}{\Large Supplement}\end{center}
\noindent The supplement contains the material moved from the main text in this version.

\section{Observation design and probing protocols}\label{sec:tri_supp}
""")
tri = tri.replace("\\subsection{Observation design and the tri-region partition}", "\\subsection{Observation design and the tri-region partition}", 1)
tex = (preamble + new("new_front.tex") + rellit + outline + model + ident + account + mixture + learners + disc + empsum
       + close + bib + "\n\\appendix\n" + mainapp + supp_head + tri + robust + blind + empirics + ia + repro + "\n\\end{document}\n")
os.makedirs(os.path.join(OUT, "figs"), exist_ok=True)
for f in os.listdir(os.path.join(SRC, "figs")):
    shutil.copy(os.path.join(SRC, "figs", f), os.path.join(OUT, "figs", f))
open(os.path.join(OUT, "paper1_9plus.tex"), "w").write(tex)
for _ in range(3):
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "paper1_9plus.tex"], cwd=OUT, capture_output=True)
log = open(os.path.join(OUT, "paper1_9plus.log"), errors="ignore").read()
pages = re.search(r"Output written on .*?\((\d+) pages", log)
print("pages", pages.group(1) if pages else None)
print("\n".join(sorted(set(re.findall(r"LaTeX Warning: (?:Reference|Label|Citation)[^\n]*", log)))[:20]))
print("\n".join(re.findall(r"^! .*", log, re.M)[:10]))
