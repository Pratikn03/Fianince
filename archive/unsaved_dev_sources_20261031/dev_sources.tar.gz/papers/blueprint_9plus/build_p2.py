"""Assemble the restructured ('9+ blueprint') Paper 2 from the current sources plus new text.
Every block of the current paper appears exactly once (main text or Internet Appendix), so labels stay unique.
Results that do not exist yet appear only inside red PENDING boxes."""
import os, re, subprocess, shutil
H = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(H, "..", "paper2")
OUT = os.path.join(H, "p2")
rd = lambda f: open(os.path.join(SRC, f)).read()
new = lambda f: open(os.path.join(OUT, f)).read()


def cut(text, start, end=None, include_end=False):
    """Return (block, text without block). block runs from `start` to `end` (exclusive unless include_end)."""
    i = text.index(start)
    if end is None:
        j = len(text)
    else:
        j = text.index(end, i + len(start)) + (len(end) if include_end else 0)
    return text[i:j], text[:i] + text[j:]


PENDING = r"""
\definecolor{pendred}{rgb}{0.65,0.05,0.05}
\newcommand{\pendinline}[1]{{\color{pendred}\textbf{[PENDING:} #1\textbf{]}}}
\newcommand{\pendbox}[2]{\par\medskip\noindent\fcolorbox{pendred}{red!4}{\parbox{0.965\linewidth}{\small\textbf{\color{pendred}PENDING --- #1.} #2}}\par\medskip}
"""

front = rd("p2_front.tex")
preamble = front[:front.index("\\title{")] + PENDING
rellit, _ = cut(front, "\\subsection{Related literature}", "\\subsection{Outline}")
outline = (r"""\subsection{Outline}
Section~\ref{sec:model} sets out the closed-loop market and Section~\ref{sec:t6} derives when a book amplifies and the closed form of cumulative risk. Section~\ref{sec:guard} shows that safety depends on the traders only through the summed response. Section~\ref{sec:infosafety} compares what certification and identification cost. Section~\ref{sec:robustguard2} builds the guard under uncertainty and prices disclosure, and Section~\ref{sec:equil} asks who supplies reversion. Section~\ref{sec:evidence} reports the evidence and Section~\ref{sec:conclusion} concludes. The Internet Appendix contains further theory (spectral stability, venue mode, balance-sheet solvency, sequential certification, certification with unknown noise covariance), every empirical table, the simulation tests and the proofs' numerical checks.

""")

theory = rd("p2_theory1.tex")
model, radius = cut(theory, "\\section{The closed-loop market}", "\\section{Spectral stability is not solvency}")
model = model.replace(
    "yielding the response weight $q_i=\\beta_i/(\\lambda_{{\\rm tc},i}+\\gamma_{{\\rm inv},i})$",
    "yielding, for a desk that carries no inventory from one period to the next, the response weight $q_i=\\beta_i/(\\lambda_{{\\rm tc},i}+\\gamma_{{\\rm inv},i})$ (with carried inventory the rule gains a term $-\\gamma_{{\\rm inv},i}I_{i,t-1}/(\\lambda_{{\\rm tc},i}+\\gamma_{{\\rm inv},i})$, an additional mean-reverting state that we do not model)")
t6 = rd("p2_t6.tex")

guard = rd("p2_guard.tex")
g_safe, guard = cut(guard, "\\section{An identification-free pre-trade guard}", "\\subsection{Computability: a finite-horizon certificate}")
g_safe = g_safe.replace("\\section{An identification-free pre-trade guard}\\label{sec:guard}",
                        "\\section{Safety depends only on the summed response}\\label{sec:guard}")
g_safe += (r"""\paragraph{Scope.} The guard's input is invariant to how the unobserved traders are split into cohorts (Proposition~\ref{prop:invariance}) and is certified at the parametric rate whatever the spacing of their memories (Section~\ref{sec:infosafety}). Invariance requires that the market start from rest or that its current drift be observed: with an unknown hidden cohort state, two markets with the same summed response and the same early responses can have different future drift and different solvency bounds (Internet Appendix, Section~\ref{sec:forward_ia}). The quantity gate subtracts an observed drift from the budget; the general balance-sheet version is in the Internet Appendix.

""")
g_robust, guard = cut(guard, "\\subsection{An uncertainty-aware guard}\\label{sec:robustguard}", "\\subsection{When admission changes the dynamics}")
guard_ia = guard.replace("\\subsection{Computability: a finite-horizon certificate}",
                         "\\section{Further results on the guard}\\label{sec:guard_ia}\n\\subsection{Computability: a finite-horizon certificate}", 1)
guard_ia = guard_ia.replace("\\subsection{Balance-sheet solvency}", "\\subsection{Balance-sheet solvency}\\label{sec:forward_ia}", 1)
guard_ia = guard_ia.replace(
    "while achieving the highest net dealer P\\&L ($+2.87$, 95\\% CI $[+2.40,+3.33]$) at $65.5\\%$ mean admitted capacity.",
    "while achieving the highest net dealer P\\&L ($+2.87$, 95\\% CI $[+2.40,+3.33]$) at $65.5\\%$ mean admitted capacity. This is an in-model illustration: the guard is computed from the true operator, and the comparison rules are not scaled to the same admitted capacity, so it does not show that the guard beats these rules in data; the real-data comparisons are in Section~\\ref{sec:guardvalue}.")

info = rd("p2_infosafety.tex")
hot, info = cut(info, "\\paragraph{Unknown noise covariance.}")
cheb, info = cut(info, "\\begin{remark}[Shorter windows cost more experiments]", "\\end{remark}", include_end=True)
info += "\\paragraph{Unknown noise covariance and shorter windows.} The certificate assumes independent taps with a known noise level; with correlated taps a $t$-certificate on the summed taps and a Hotelling region keep their level, and polynomial window bounds shorten the horizon only at the cost of far more experiments (Internet Appendix, Section~\\ref{sec:info_ia}).\n\n"
info_ia = "\\section{Certification with unknown noise covariance, and shorter windows}\\label{sec:info_ia}\n" + hot + "\n" + cheb + "\n"

disc = rd("p2_disclosure.tex")
disc = disc.replace("\\section{The value of disclosure for safe trading}\\label{sec:disclosure}",
                    "\\subsection{The value of disclosure for safe trading}\\label{sec:disclosure}")
sec_robust = ("\\section{The guard under uncertainty, and the value of disclosure}\\label{sec:robustguard2}\n"
              + g_robust + disc)
equil = rd("p2_equil.tex")

thin = rd("p2_thin.tex")
alltests_sec, thin = cut(thin, "\\subsection{Every pre-registered test}\\label{sec:alltests}", "\\subsection{Threats to validity}\\label{sec:threats}")
threats, thin = cut(thin, "\\subsection{Threats to validity}\\label{sec:threats}", "\\subsection{What the evidence says}\\label{sec:thin_summary}")
alltests_tab, _ = cut(alltests_sec, "\\begin{table}[t]\\centering\\small\n\\begin{threeparttable}\n\\caption{All pre-registered tests}",
                      "\\end{table}", include_end=True)
forest, _ = cut(alltests_sec, "\\begin{figure}[p]\\centering", "\\end{figure}", include_end=True)
z9_start = thin.index("\\subsection{Beyond volatility forecasting}\\label{sec:z9}")
z9tab, rest = cut(thin[z9_start:], "\\begin{table}[t]\\centering", "\\end{table}", include_end=True)
thin = thin[:z9_start] + rest
thin = thin.replace("\\section{Evidence from thinner books}\\label{sec:thin}",
                    "\\section{Evidence from thinner books: full results}\\label{sec:thin}", 1)
evid = new("new_evidence.tex").replace("%ALLTESTS%", alltests_tab + "\n" + forest).replace("%Z9TABLE%", z9tab)
evid = evid + threats.replace("\\subsection{Threats to validity}\\label{sec:threats}",
                              "\\paragraph{Threats to validity.}\\label{sec:threats} The Internet Appendix discusses each threat in detail; the main ones follow.\n", 1)

evidence_ia = rd("p2_evidence.tex")
istests = rd("p2_istests.tex")
app = rd("p2_appendix.tex")
bib, app = cut(app, "\\begin{thebibliography}", "\\end{thebibliography}", include_end=True)
proofs, app = cut(app, "\\section{Proofs}\\label{app:proofs}", "\\section{Additional material}\\label{app:ia}")
addl, app = cut(app, "\\section{Additional material}\\label{app:ia}", "\\section{Reproducibility: source of every number}\\label{app:repro}")
repro = app[app.index("\\section{Reproducibility: source of every number}"):].replace("\\end{document}", "")

ia_head = (r"""\clearpage
\begin{center}{\Large Internet Appendix}\end{center}
\noindent The Internet Appendix contains the material moved from the main text in this version: further theory, every empirical table and the simulation tests.

""")
radius = radius.replace("\\section{Spectral stability is not solvency}\\label{sec:radius}",
                        "\\section{Spectral stability is not solvency}\\label{sec:radius}", 1)

tex = (preamble + new("new_front.tex") + rellit + outline + model + t6 + g_safe + info.replace("\\section{Identification and financial safety}\\label{sec:infosafety}", "\\section{Certification versus identification}\\label{sec:infosafety}", 1) + sec_robust + equil + evid
       + new("new_close.tex") + bib + "\n\\appendix\n" + proofs + ia_head + radius + guard_ia + info_ia
       + evidence_ia + thin + istests + addl + repro + "\n\\end{document}\n")
os.makedirs(os.path.join(OUT, "figs"), exist_ok=True)
for f in os.listdir(os.path.join(SRC, "figs")):
    shutil.copy(os.path.join(SRC, "figs", f), os.path.join(OUT, "figs", f))
open(os.path.join(OUT, "paper2_9plus.tex"), "w").write(tex)
for _ in range(3):
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "paper2_9plus.tex"], cwd=OUT, capture_output=True)
log = open(os.path.join(OUT, "paper2_9plus.log"), errors="ignore").read()
pages = re.search(r"Output written on .*?\((\d+) pages", log)
print("pages", pages.group(1) if pages else None)
print("\n".join(sorted(set(re.findall(r"LaTeX Warning: (?:Reference|Label|Citation)[^\n]*", log)))[:20]))
print("\n".join(re.findall(r"^! .*", log, re.M)[:10]))
