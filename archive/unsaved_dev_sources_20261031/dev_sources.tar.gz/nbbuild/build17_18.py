import json, re, os
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
def build(order, C, out):
    cells = []
    for it in order:
        if isinstance(it, tuple):
            cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
        for ch in split(open(os.path.join(C, it)).read()):
            cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
    nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "language_info": {"name": "python"}}, "cells": cells}
    json.dump(nb, open(out, "w"), indent=1); print("wrote", out, len(cells), "cells")

build([("md", """# Part 17 — A new venue and an order-splitting placebo (Paper 2)
Every earlier test used Binance, Bybit or US stocks. This notebook runs a **pre-registered** test on **Coinbase Exchange spot**, a US-regulated venue the program has never used, with public trade data only (no account and no API keys).

**Two primaries, tested in a fixed sequence:**
1. In thin Coinbase USD pairs, the depth-free amplification margin `C3_flow` forecasts the next hour's adverse excursion beyond a volatility and price-impact baseline.
2. Only if 1 passes: the real statistic beats an **order-splitting placebo**, the same statistic computed after shifting the flow series by 180 minutes inside its own six-hour window. The placebo keeps the flow's size distribution and persistence (order splitting) but breaks its minute-by-minute alignment with prices, which is what the model says matters.

**Rules:**
1. Run the cells one at a time, in order.
2. **C3 downloads `P17_new_venue.json`: e-mail it to yourself before running C4.**
3. C4 is the long one (about 2–4 hours at Coinbase's public rate limit). It caches every pair-day in Drive, so if Colab disconnects, re-run C0, C1, C2, C3 and then C4: it resumes where it stopped.
4. Run C6 **once**. Then run C7 and send me `p17_results.zip`."""),
 "c0_setup.py", "c1_functions.py",
 ("md", "## Universe and pre-registration (before any trade is downloaded)"), "c2_universe.py", "c3_prereg.py",
 ("md", "## Data and hourly blocks"), "c4_data.py", "c5_blocks.py",
 ("md", "## The test: run ONCE"), "c6_test.py", "c7_zip.py",
 ("md", """## How to read C6
| Result | Meaning for Paper 2 |
|---|---|
| Both pass | The thin-book result holds on a fourth venue, and its content is the flow–price alignment, not order-flow persistence. |
| 1 passes, 2 fails | The statistic forecasts on Coinbase, but a placebo with the same flow persistence does about as well: the content may be order splitting, not feedback. |
| 1 fails | Coinbase joins Bybit as a venue where the effect is absent; the paper reports it with the same prominence. |""")],
 "/home/claude/p17", "/home/claude/outputs/Part17_NewVenue_Coinbase.ipynb")

build([("md", """# Part 18 — Post-hoc checks: order-splitting placebo on Binance and three more guard baselines (Paper 2)
**Everything here is post hoc**: it reuses samples that Parts 9, 15 and 16 already opened. R1 fixes and hashes the analysis plan before anything is computed, and the paper labels the results as post hoc.

- **(A) Placebo:** recompute `C3` on the Part 9 and Part 16 forecasting samples with the flow shifted inside its window, and compare it with the real statistic.
- **(B) Guards:** add a certified **peak-response guard**, a **participation cap** (position proportional to recent volume) and a **margin-style rule** (exchange scanning range) to the Part 15 and Part 16 guard comparisons.

**Needs the same Google Drive** as Parts 9, 15 and 16 (`MyDrive/ceiling_suite`). Missing minute files are re-downloaded automatically, which is slower.

Run all cells in order (about 20–50 minutes), then send me `p18_results.zip`."""),
 "u0.py", "u1.py", "u2.py", "r1_plan.py", "r2_load.py", "r3_placebo.py", "r4_guards.py", "r5_zip.py"],
 "/home/claude/p18", "/home/claude/outputs/Part18_PostHoc_Placebo_Baselines.ipynb")
