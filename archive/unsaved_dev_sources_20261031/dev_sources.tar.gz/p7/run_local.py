import os, time, shutil, json
W = '/home/claude/p7/run'; os.chdir(W); shutil.rmtree(os.path.join(W, 'ceiling_suite_local'), ignore_errors=True)
g = {'__name__': '__main__'}; C = '/home/claude/p7/cells/'
def run(name):
    t = time.time(); print('\n####', name, flush=True)
    exec(compile(open(C + name).read(), name, 'exec'), g); print(f'-- {time.time()-t:.1f}s', flush=True)
g['__builtins__'] = __builtins__
src = open(C + 'w00_setup.py').read()
i = src.index('code, _ = _http(bb_url')
exec(compile(src[:i], 'w00a', 'exec'), g)
exec(open('/home/claude/p7/fake_bybit.py').read(), g)
exec(compile(src[i:], 'w00b', 'exec'), g)
g['TRAIN_D'] = g['TRAIN_D'][::4]; g['TEST_D'] = g['TEST_D'][::6]
# fake prior results needed by W2
R = g['RESULTS']; os.makedirs(R, exist_ok=True)
json.dump({"metrics": {"by_symbol": {f"AA{i}USDT": {"tercile": "thin"} for i in range(5)}}}, open(os.path.join(R, 'X3_T6_cross_section.json'), 'w'))
json.dump({"metrics": {"group": {f"BB{i}USDT": "thin" for i in range(4)}}}, open(os.path.join(R, 'Y3_groups.json'), 'w'))
for c in ['w01_functions.py', 'w02_symbols.py', 'w03_prereg.py', 'w04_build.py', 'w05_blocks.py', 'w06_test.py']:
    run(c)
