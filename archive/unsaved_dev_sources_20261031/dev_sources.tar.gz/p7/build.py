import json, re, os
C = "/home/claude/p7/cells"
order = [
 ("md", """# Part 7 — A second venue: Bybit (Paper 2)
Every result so far is from Binance. This notebook tests the thin-book result on **Bybit**, a different exchange with different participants, using Bybit's free public trade archive. Bybit has never been used in this project.

Bybit's free archive has trades but **no order-book depth**, so the test uses the depth-free statistic C3_flow = κ²ηq − (1−a)κ. Parts 5–6 show that the depth term carries no forecasting content, and Part 6 also tests C3_flow on Binance.

**Rules:** run cells one at a time. **W3 downloads the pre-registration: e-mail it to yourself before W4.** Run W6 exactly once.

Expected time: about 1–2 hours (about 2,600 daily trade files)."""),
 "w00_setup.py", "w01_functions.py",
 ("md", "## Symbols and pre-registration (before any Bybit data)"), "w02_symbols.py", "w03_prereg.py",
 ("md", "## Data and blocks"), "w04_build.py", "w05_blocks.py",
 ("md", "## The test: run ONCE (it also zips and downloads the results)"), "w06_test.py",
 ("md", """If W0 says the archive is not reachable, Bybit is blocking this Colab region. Tell me and I'll adapt it.

Send me `p7_results.zip`."""),
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/outputs/Part7_Bybit_SecondVenue.ipynb", "w"), indent=1)
print(len(cells), "cells")
