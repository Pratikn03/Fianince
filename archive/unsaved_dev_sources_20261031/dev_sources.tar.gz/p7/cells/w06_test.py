# ============================================================================
# CELL W6 — THE TEST (RUN ONCE; every run is counted)
# ============================================================================
assert hashlib.sha256(open(p7_path).read().encode()).hexdigest() == P7_HASH, "spec changed after registration"
pth7 = os.path.join(PREREG, "test_set_unlocks_p7.json")
n_unl7 = (json.load(open(pth7))["n"] if os.path.exists(pth7) else 0) + 1
json.dump({"n": n_unl7, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": P7_HASH}, open(pth7, "w"))
def holm(pd_):
    items = sorted((v if np.isfinite(v) else 1.0, k) for k, v in pd_.items()); m = len(items); out, run = {}, 0.0
    for j, (p_, k) in enumerate(items):
        run = max(run, min(1.0, p_ * (m - j))); out[k] = run
    return out
C7 = CTRL7 + IMPACT
prim7 = evaluate_g(WB, "MAE_60", "C3_flow", C7)
ok7 = bool(np.isfinite(prim7.get("clark_west_p", np.nan)) and prim7["clark_west_p"] < 0.05 and prim7["delta_r2_ci"][0] > 0)
sec7 = {"MAE | term_momentum": evaluate_g(WB, "MAE_60", "term_momentum", C7),
        "MAE | term_reversion": evaluate_g(WB, "MAE_60", "term_reversion", C7)}
THETA7, theta7_tr = choose_theta(WB)
print("theta chosen on training data:", THETA7)
G7, rules7 = guard_frame(WB, {"amp_vol": (lambda X: X["rv_360"] * X["gain_multiple"] ** THETA7)})
gb7 = guard_compare(G7, rules7, ref="vol")
p7s = {k: v.get("clark_west_p", np.nan) for k, v in sec7.items()}
for r in ["amp_vol", "guard_summed", "guard_peak", "static"]:
    p7s[f"{r} vs vol"] = 1 - gb7["vs_ref"][r]["share_boot_below_0"]
h7 = holm(p7s)
for k in sec7:
    sec7[k]["holm_p"] = h7[k]
sh = lambda v: {k: (round(v[k], 5) if isinstance(v.get(k), float) else v.get(k)) for k in
                ["n_train", "n_test", "n_symbols", "delta_r2", "delta_r2_ci", "delta_auc_ci", "clark_west_t", "clark_west_p", "holm_p", "coef_candidates_train", "skipped"] if k in v}
print("=== PRIMARY (Bybit, C3_flow):", "PASS" if ok7 else "FAIL"); print(sh(prim7))
for k, v in sec7.items():
    print(k, sh(v))
print(pd.DataFrame(gb7["point"]).T.round(4).to_string())
for r, v in gb7["vs_ref"].items():
    print(f"   {r:13s} log TLR - log TLR_vol = {v['log_TLR_minus_ref']:+.4f}  CI {np.round(v['ci'], 4)}  Holm p {h7[f'{r} vs vol']:.4f}")
record("W6_bybit_test", ok7, "real-data", {"primary": prim7, "secondary": sec7, "guard": gb7, "theta": THETA7, "theta_train_TLR": theta7_tr, "holm_p": h7,
       "prereg_sha256": P7_HASH, "test_set_unlocks": n_unl7}, criterion=PREREG_P7["primary"]["success"])
zp7 = os.path.join(BASE, "p7_results.zip")
with zipfile.ZipFile(zp7, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "W*.json")) + [os.path.join(RESULTS, "p7_manifest_sha256.csv"), p7_path, pth7]:
        if os.path.exists(fp):
            z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp7)
if IN_COLAB:
    from google.colab import files
    files.download(zp7)
