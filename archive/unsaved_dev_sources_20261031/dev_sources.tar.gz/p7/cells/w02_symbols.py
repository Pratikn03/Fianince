# ============================================================================
# CELL W2 — SYMBOLS: the 20 Binance thin-set coins, on Bybit (kept if Bybit has trades in 2023 and 2026)
# Fixed before any Bybit data are analysed. Thin status on Bybit is checked from training volume only.
# ============================================================================
X3 = json.load(open(os.path.join(RESULTS, "X3_T6_cross_section.json")))["metrics"]["by_symbol"]
Y3 = json.load(open(os.path.join(RESULTS, "Y3_groups.json")))["metrics"]["group"]
CAND = sorted([s for s, v in X3.items() if v["tercile"] == "thin"] + [s for s, g in Y3.items() if g == "thin"])
def bb_span(s):
    return all(_http(bb_url(s, d), "HEAD", timeout=30)[0] == 200 for d in ["2023-03-10", "2024-12-24", "2026-06-10"])
with ThreadPoolExecutor(THREADS) as ex:
    avail = dict(zip(CAND, ex.map(bb_span, CAND)))
SYMBOLS = [s for s in CAND if avail[s]]
print(f"{len(SYMBOLS)} of {len(CAND)} thin-set coins have Bybit trades over 2023-2026:", SYMBOLS)
print("missing on Bybit:", [s for s in CAND if not avail[s]])
assert len(SYMBOLS) >= 8, "too few symbols on Bybit; tell Claude"
record("W1_symbols", None, "audit", {"candidates": CAND, "available": avail, "symbols": SYMBOLS})
