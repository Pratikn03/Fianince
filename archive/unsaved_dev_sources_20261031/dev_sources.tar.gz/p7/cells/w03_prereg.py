# ============================================================================
# CELL W3 — PRE-REGISTRATION (before any Bybit data are downloaded; W4 refuses to run without it)
# ============================================================================
PREREG_P7 = {
    "question": "Second venue: does the depth-free amplification statistic forecast next-hour adverse excursions "
                "on Bybit USDT perpetuals of the Binance thin-set coins?",
    "data": "Bybit public trade archive (public.bybit.com/trading), never used before. Minute bars: last trade price, "
            "signed taker notional, notional volume. Day kept if >= 80% of minutes have trades.",
    "symbols": SYMBOLS,
    "train": "10th and 24th of each month, 2023-2024", "test": "3rd, 10th, 17th, 24th of each month, 2025-01-01 to 2026-09-30",
    "unit": "symbol-hour blocks, hours 6-23 UTC; features [t-360, t); outcome (t, t+60]",
    "statistic": "C3_flow = kappa^2 eta q - (1-a) kappa from dp = kappa u - (1-a) x and u_t = (1-eta) u_t-1 + eta q x_t-1 (T6 without depth)",
    "controls": CTRL7 + IMPACT + ["symbol fixed effects"],
    "primary": {"sample": "all symbols above", "outcome": "MAE_60", "candidate": "C3_flow (winsorized at train 1%/99%)",
                "success": "Clark-West one-sided p < 0.05 AND 95% date-block bootstrap CI of dR2 above 0"},
    "secondary": ["MAE | term_momentum", "MAE | term_reversion",
                  "position-sizing backtest, same definitions as Part 6 B: amp_vol (R = rv_360 * GM^theta, GM = S60/|h_0| from the "
                  "depth-free impulse response, theta chosen on Bybit training data) vs vol",
                  "guard_summed vs vol", "guard_peak vs vol", "static vs vol"],
    "inference": "Clark-West (Newey-West 6 lags); 2,000 date-block bootstrap draws; secondary Holm-adjusted",
    "runs": "W6 is run once; every run is counted in prereg/test_set_unlocks_p7.json",
}
spec_txt7 = json.dumps(PREREG_P7, indent=2, sort_keys=True)
P7_HASH = hashlib.sha256(spec_txt7.encode()).hexdigest()
p7_path = os.path.join(PREREG, "P7_bybit.json")
if not os.path.exists(p7_path):
    open(p7_path, "w").write(spec_txt7); print("pre-registration written:", p7_path)
elif hashlib.sha256(open(p7_path).read().encode()).hexdigest() != P7_HASH:
    raise RuntimeError("The spec differs from the registered file. Do not edit the spec after registering it.")
print("spec SHA-256:", P7_HASH)
if IN_COLAB:
    from google.colab import files
    files.download(p7_path)
