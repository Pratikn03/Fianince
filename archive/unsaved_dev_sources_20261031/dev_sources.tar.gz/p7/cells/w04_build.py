# ============================================================================
# CELL W4 — DOWNLOAD BYBIT TRADES AND BUILD MINUTE BARS (cached in Drive)
# ============================================================================
assert os.path.exists(p7_path) and hashlib.sha256(open(p7_path).read().encode()).hexdigest() == P7_HASH, "run W3 first"
jobs = [(s, d) for s in SYMBOLS for d in TRAIN_D + TEST_D]
print(f"{len(jobs)} symbol-days")
PANEL, VST = {}, []
with ThreadPoolExecutor(THREADS) as ex:
    futs = {ex.submit(get_day_bybit, s, d): (s, d) for s, d in jobs}
    for i, f in enumerate(as_completed(futs), 1):
        s, d = futs[f]
        try:
            df, st = f.result(); VST.append(st)
            if df is not None:
                PANEL[(s, d)] = df
        except Exception as e:
            VST.append({"symbol": s, "date": d, "reason": f"error: {e}"})
        if i % 300 == 0:
            print(f"   {i}/{len(jobs)}")
vst = pd.DataFrame(VST)
vst["day_ok"] = vst.get("day_ok", pd.Series(False, index=vst.index)).fillna(False).astype(bool)
OK = sorted([(r.symbol, r.date) for r in vst.itertuples() if r.day_ok and (r.symbol, r.date) in PANEL])
FLOW_SCALE = {}
for s in SYMBOLS:
    v = [np.nanmedian(np.abs(PANEL[(s, d)]["flow"].to_numpy())) for d in TRAIN_D if (s, d) in OK]
    v = [x for x in v if np.isfinite(x) and x > 0]
    FLOW_SCALE[s] = float(np.median(v)) if v else 1.0
pd.DataFrame(DL_LOG).to_csv(os.path.join(RESULTS, "p7_manifest_sha256.csv"), index=False)
record("W2_build", None, "audit", {"requested": len(jobs), "valid": len(OK), "flow_scale": FLOW_SCALE,
       "by_symbol": vst.groupby("symbol")["day_ok"].agg(["sum", "count"]).to_dict("index")})
