# ============================================================================
# CELL W5 — HOURLY BLOCKS
# ============================================================================
BLK7 = os.path.join(BASE, "data_bybit", f"blocks_p7_{len(SYMBOLS)}sym.parquet")
if os.path.exists(BLK7) and set(map(tuple, pd.read_parquet(BLK7)[["symbol", "date"]].drop_duplicates().to_numpy())) >= set(OK):
    WB = pd.read_parquet(BLK7)
else:
    rows = []
    for i, (s, d) in enumerate(OK):
        rows += day_blocks7(s, d, FLOW_SCALE[s])
        if (i + 1) % 300 == 0:
            print(f"   blocks: {i+1}/{len(OK)}")
    WB = pd.DataFrame(rows); WB.to_parquet(BLK7)
WB["split"] = np.where(WB["date"] <= TRAIN_END, "train", "test")
WB["kappa_sq"] = WB["kappa_hat"] ** 2
WB = winsor_train(WB, IMPACT)
print(WB.groupby("split").size())
record("W3_blocks", None, "audit", {"blocks": WB.groupby("split").size().to_dict(),
       "coverage": {c: float(WB[c].notna().mean()) for c in ["C3_flow", "S60", "U6"] + IMPACT}})
