# ============================================================================
# CELL W0 — SETUP (self-contained; run first)
# Part 7: a SECOND VENUE. Bybit USDT perpetuals from Bybit's free trade archive (public.bybit.com),
# never used before. Bybit's free archive has trades but no depth history, so the test uses the
# depth-free amplification statistic C3_flow = kappa^2 eta q - (1-a) kappa (Parts 5-6 show the depth
# term carries no forecasting content). Same symbols as the Binance thin set, a different venue.
# ============================================================================
import os, sys, json, time, math, glob, re, io, zipfile, hashlib, subprocess, warnings, zlib
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
import xml.etree.ElementTree as ET

IN_COLAB = "google.colab" in sys.modules
try:
    import pyarrow  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pyarrow"], check=True)
import numpy as np
import pandas as pd
from scipy import stats, optimize
warnings.filterwarnings("ignore", category=RuntimeWarning)

USE_DRIVE = True
if IN_COLAB and USE_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    BASE = "/content/drive/MyDrive/ceiling_suite"
elif IN_COLAB:
    BASE = "/content/ceiling_suite"
else:
    BASE = os.path.abspath("ceiling_suite_local")
RESULTS, PREREG = os.path.join(BASE, "results"), os.path.join(BASE, "prereg")
XDATA = os.path.join(BASE, "data_xsec")
for _d in (RESULTS, PREREG, XDATA):
    os.makedirs(_d, exist_ok=True)

SEED = 20261022
def rng(offset=0):
    return np.random.default_rng(SEED + offset)

def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o

def record(test_id, passed, kind, metrics, criterion="", note=""):
    assert kind in {"theorem-check", "simulation", "real-data", "audit"}, kind
    status = "REPORT" if passed is None else ("PASS" if passed else "FAIL")
    out = {"test_id": test_id, "status": status, "kind": kind, "criterion": criterion, "note": note,
           "metrics": _clean(metrics), "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "seed": SEED}
    with open(os.path.join(RESULTS, f"{test_id}.json"), "w") as f:
        json.dump(out, f, indent=2)
    print(f"[{status}] {test_id} ({kind})" + (f" — {criterion}" if criterion else ""))
    if note:
        print("        note:", note)
    return out

def boot_ci(v, R, B=2000, stat=np.mean):
    v = np.asarray(v, float); v = v[np.isfinite(v)]
    if len(v) < 3:
        return [np.nan, np.nan]
    bs = [stat(v[R.integers(0, len(v), len(v))]) for _ in range(B)]
    return [float(np.quantile(bs, 0.025)), float(np.quantile(bs, 0.975))]

# ---- Sample design --------------------------------------------------------------------------
BYBIT = "https://public.bybit.com/trading"
TRAIN_DAYS, TEST_DAYS = (10, 24), (3, 10, 17, 24)        # Bybit data were never used: all test days are fresh
TRAIN_START, TRAIN_END, TEST_START, TEST_END = "2023-01-01", "2024-12-31", "2025-01-01", "2026-09-30"
THREADS = 12
print("BASE =", BASE)
def _dates(a, b, days):
    return [d.strftime("%Y-%m-%d") for d in pd.date_range(a, b, freq="D") if d.day in days]
TRAIN_D, TEST_D = _dates(TRAIN_START, TRAIN_END, TRAIN_DAYS), _dates(TEST_START, TEST_END, TEST_DAYS)

def _http(url, method="GET", timeout=60, tries=3):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, method=method, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, (r.read() if method == "GET" else b"")
        except urllib.error.HTTPError as e:
            if e.code in (403, 404):
                return e.code, b""
            last = e
        except Exception as e:
            last = e
        time.sleep(1.5 * (i + 1))
    raise RuntimeError(f"network error {url}: {last}")
def bb_url(sym, date):
    return f"{BYBIT}/{sym}/{sym}{date}.csv.gz"
code, _ = _http(bb_url("BTCUSDT", "2024-06-10"), "HEAD", timeout=30)
print("Bybit archive reachable:", code == 200, f"(HTTP {code})")
assert code == 200, "public.bybit.com is not reachable from this runtime (Bybit blocks some regions); tell Claude."
DL_LOG = []
