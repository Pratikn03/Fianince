# LOCAL DEBUG ONLY: format-faithful fake of public.bybit.com/trading
import gzip as _gz, zlib as _zl
def _bsim(s, date):
    rr = np.random.default_rng(_zl.crc32(f"b{s}{date}".encode()))
    n = 1440; u = np.zeros(n); p = np.zeros(n); x = np.zeros(n)
    for t in range(1, n):
        u[t] = 0.3 * u[t - 1] + 0.02 * x[t - 1] + rr.normal(0, 1)
        p[t] = p[t - 1] + 2 * u[t] - 0.03 * x[t - 1] + rr.normal(0, 3)
        x[t] = p[t] - (0.967 * (p[t - 1] - x[t - 1]) + 0.033 * p[t])
    return 0.5 * np.exp(p / 1e4), u
def _http(url, method="GET", timeout=60, tries=3):
    m = re.search(r"/trading/([A-Z0-9]+)/[A-Z0-9]+(\d{4}-\d{2}-\d{2})\.csv\.gz$", url)
    if not m:
        return 404, b""
    if method == "HEAD":
        return 200, b""
    s, date = m.group(1), m.group(2); px, u = _bsim(s, date)
    rr = np.random.default_rng(3); t0 = pd.Timestamp(date, tz="UTC").timestamp()
    L = ["timestamp,symbol,side,size,price,tickDirection,trdMatchID,grossValue,homeNotional,foreignNotional"]
    for mi in range(1440):
        for _ in range(rr.poisson(6)):
            buy = rr.random() < 0.5 + 0.2 * np.tanh(u[mi]); sz = rr.exponential(2000) / px[mi]
            L.append(f"{t0 + 60*mi + rr.random()*59:.4f},{s},{'Buy' if buy else 'Sell'},{sz:.2f},{px[mi]:.6f},PlusTick,x,0,{sz:.2f},{sz*px[mi]:.4f}")
    return 200, _gz.compress("\n".join(L).encode())
