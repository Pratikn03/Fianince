import os, glob, time, traceback
os.chdir('/home/claude/xsec/run'); g = {'__name__': '__main__'}
for c in sorted(glob.glob('/home/claude/p5/cells/y*.py')):
    print('\n####', os.path.basename(c), flush=True); t = time.time()
    try:
        exec(compile(open(c).read(), c, 'exec'), g)
    except Exception:
        traceback.print_exc(); break
    print(f'-- {time.time()-t:.1f}s', flush=True)
    if 'y00_setup' in c:
        exec(open('/home/claude/xsec/debug_fake.py').read(), g)
