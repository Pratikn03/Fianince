import json, re, os
C = "/home/claude/p5/cells"
order = [
 ("md", """# Part 5 — Out-of-Sample Replication on New Symbols
Part 4's pre-registered test passed in thin books, but referees will ask whether it holds **outside the 30 symbols where it was found**. This notebook answers that on symbols never used before, with the **same frozen specification**.

| Cell | What it does |
|---|---|
| Y0–Y1 | setup and the same functions as Part 4 (shares the Drive cache) |
| Y2 | picks up to 24 **new** thin-volume symbols, seeded, before any analysis |
| Y3 | downloads and validates them (rules V1–V5) |
| Y4 | thin classification (fixed cut 0.39 $M) and hourly blocks, plus a **unit-free amplification ratio** and **the three terms of C3** |
| Y5 | **new pre-registration**: commit `prereg/P5_replication.json` before Y6 |
| Y6 | **the replication test: run ONCE** |
| Y7 | training-only descriptives and the download |

**Rules:** run cells one at a time (no "Run all"). Run Y6 exactly once. Whatever Y6 shows goes in the paper.
Expected time: 30–90 minutes (downloads)."""),
 "y00_setup.py", "y01_functions.py",
 ("md", "## Choose and build the new symbols"), "y02_select.py", "y03_build.py", "y04_blocks.py",
 ("md", "## Pre-register, then test ONCE"), "y05_prereg.py", "y06_test.py",
 ("md", "## Descriptives and download"), "y07_summary.py",
 ("md", """## How to read Y6
| Result | Meaning for Paper 2 |
|---|---|
| Primary passes (CW p < 0.05 and ΔR² CI > 0) | **Replicated out of sample on new symbols**: the strongest possible evidence; Paper 2 → about 8.5 |
| Primary fails, same sign | Effect real but smaller or noisier than in Part 4; report both honestly; about 7.5–8 |
| Opposite sign | Part 4's result does not generalize; Paper 2 → about 7 |
| A_ratio passes | the unit-free version works; this answers the scale concern from X6r |
| term_momentum passes but term_depth does not | mechanism = momentum feedback, consistent with X8 |

Send me `p5_results.zip`."""),
 ("md", """## Y8 — post-hoc: is C3 just price impact? (decided after Y6)
**Do NOT re-run Y6.** In a fresh session run Y0, Y1, Y2, Y3, Y4, Y5 (all read from the Drive cache), skip Y6 and Y7, then run Y8.
Y8 adds four price-impact controls (κ̂, κ̂², Kyle's λ, Amihud) and asks whether C3 still forecasts. It uses a separate counter, so Y6's unlock count stays at 1.
Expected time: about 10–20 minutes. Send me `p5_kappa.zip`."""),
 "y08_kappa_control.py",
]
def split(src):
    return [p.rstrip() + "\n" for p in re.split(r"(?m)^(?=# =+\n# CELL )", src) if p.strip()]
cells = []
for it in order:
    if isinstance(it, tuple):
        cells.append({"cell_type": "markdown", "metadata": {}, "source": it[1].splitlines(True)}); continue
    for ch in split(open(os.path.join(C, it)).read()):
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": ch.splitlines(True)})
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {"kernelspec": {"display_name": "Python 3", "name": "python3"}, "language_info": {"name": "python"}}, "cells": cells}
json.dump(nb, open("/home/claude/outputs/Part5_Replication_NewSymbols.ipynb", "w"), indent=1)
print(len(cells), "cells")
