import os, glob, time, traceback
os.chdir('/home/claude/xsec/run'); g = {'__name__': '__main__'}
for c in sorted(glob.glob('/home/claude/p5/cells/y0[0-5]*.py')):
    exec(compile(open(c).read(), c, 'exec'), g)
    if 'y00_setup' in c: exec(open('/home/claude/xsec/debug_fake.py').read(), g)
g['GROUP'] = {s: 'thin' for s in g['GROUP']}; g['YB']['group'] = 'thin'
c='/home/claude/p5/cells/y08_kappa_control.py'; t=time.time()
exec(compile(open(c).read(), c, 'exec'), g); print(f'-- {time.time()-t:.1f}s')
