# ============================================================================
# CELL Y5 — PRE-REGISTRATION OF THE REPLICATION (run before Y6; commit prereg/P5_replication.json)
# The model, controls, outcome, inference and success rule are copied unchanged from Part 4 (X5).
# ============================================================================
CTRL = ["rv_60", "rv_360", "abs_ret_60", "flow_imb_60", "log_vol_60", "log_depth1", "imbalance", "oi_chg_60"]
PREREG_P5 = {
    "question": "Does the Part 4 thin-book result replicate on Binance USD-M symbols never used before?",
    "symbols": "drawn in cell Y2 (seeded) from thin-volume candidates not used in Part 4",
    "thin_rule": "median training depth within 1% of mid < 0.39 $M (Part 4 thin/mid boundary)",
    "unit": "symbol-hour blocks, hours 6-23 UTC; features [t-360, t); outcome (t, t+60]",
    "controls": CTRL + ["symbol fixed effects"],
    "primary": "group=thin, outcome=MAE_60, candidate=C3_hat winsorized at train 1%/99% (identical to Part 4 X6)",
    "secondary": ["thin: MAE_60 | A_ratio (unit-free)", "thin: MAE_60 | term_momentum", "thin: MAE_60 | term_depth",
                  "thin: MAE_60 | term_reversion", "not_thin: MAE_60 | C3_hat"],
    "train": "dates <= 2024-12-31", "test": "dates >= 2025-01-01",
    "model": "OLS with symbol fixed effects; tail = outcome above train 90th percentile",
    "inference": "Clark-West (Newey-West 6 lags); bootstrap 2,000 resampling dates for ΔR², ΔAUC",
    "success": "primary: Clark-West one-sided p < 0.05 AND bootstrap 95% CI of ΔR² excludes 0; secondary Holm-adjusted",
    "part4_hash": "5910b6b4d90aad457f03eb01d27cb0141933ff1d70dd93d85a98663f73e36020",
}
spec_txt5 = json.dumps(PREREG_P5, indent=2, sort_keys=True)
P5_HASH = hashlib.sha256(spec_txt5.encode()).hexdigest()
p5_path = os.path.join(PREREG, "P5_replication.json")
if not os.path.exists(p5_path):
    open(p5_path, "w").write(spec_txt5); print("pre-registration written:", p5_path)
elif hashlib.sha256(open(p5_path).read().encode()).hexdigest() != P5_HASH:
    print("!! WARNING: spec differs from the registered file. Any change after seeing results must be disclosed.")
print("spec SHA-256:", P5_HASH, "\nSave prereg/P5_replication.json somewhere dated BEFORE running Y6.")
