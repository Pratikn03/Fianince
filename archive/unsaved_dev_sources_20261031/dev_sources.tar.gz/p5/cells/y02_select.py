# ============================================================================
# CELL Y2 — CHOOSE NEW SYMBOLS (never used in Part 4), FIXED BEFORE ANY ANALYSIS
# Candidates: USD-M perpetuals with depth in both 2023 and 2026, NOT among Part 4's 30 symbols,
# whose quote volume on the Part 4 ranking day is at most 1.5x the largest volume among
# Part 4's thin-tercile symbols (so they are thin-book candidates). Up to NEW_MAX are drawn at
# random with a fixed seed. Thin status is decided later from training depth (cell Y4).
# ============================================================================
NEW_MAX = 24
P4 = json.load(open(os.path.join(RESULTS, "X1_universe.json")))["metrics"]
P4_SYMBOLS = P4["symbols"]
P4_TERC = {s: v["tercile"] for s, v in json.load(open(os.path.join(RESULTS, "X3_T6_cross_section.json")))["metrics"]["by_symbol"].items()}
qv4 = P4["quote_volume_musd_on_rank_date"]
thin_vol_max = max(qv4[s] for s in P4_SYMBOLS if P4_TERC.get(s) == "thin")
print(f"Part 4 thin symbols: max quote volume on {LIQ_RANK_DATE} = {thin_vol_max:.1f} $M")

try:
    listed = list_bucket_symbols()
except Exception as e:
    print("bucket listing failed:", e); listed = []
cands = [s for s in (listed or FALLBACK) if re.fullmatch(r"[A-Z0-9]+USDT", s) and s not in P4_SYMBOLS]
with ThreadPoolExecutor(THREADS) as ex:
    keep = [s for s, ok in zip(cands, ex.map(span_ok, cands)) if ok]
with ThreadPoolExecutor(THREADS) as ex:
    qv = dict(zip(keep, ex.map(day_quote_volume, keep)))
pool = sorted([s for s in keep if np.isfinite(qv[s]) and qv[s] / 1e6 <= 1.5 * thin_vol_max])
R_sel = rng(5)
SYMBOLS = sorted(R_sel.choice(pool, size=min(NEW_MAX, len(pool)), replace=False).tolist()) if pool else []
print(f"new candidates: {len(cands)}; with depth span: {len(keep)}; thin-volume pool: {len(pool)}; chosen: {len(SYMBOLS)}")
print(SYMBOLS)
record("Y1_new_universe", None, "audit",
       {"part4_symbols_excluded": P4_SYMBOLS, "thin_volume_cap_musd": 1.5 * thin_vol_max, "pool": pool,
        "symbols": SYMBOLS, "quote_volume_musd": {s: qv[s] / 1e6 for s in SYMBOLS}, "seed": SEED},
       note="New symbols fixed before any estimation. None was used in Part 4.")
