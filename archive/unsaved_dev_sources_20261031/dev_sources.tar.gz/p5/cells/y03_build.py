# ============================================================================
# CELL Y3 — DOWNLOAD AND VALIDATE THE NEW SYMBOLS (same rules V1-V5 as Part 4; cached in Drive)
# ============================================================================
PDATES = panel_dates()
jobs = [(s, d) for s in SYMBOLS for d in PDATES]
print(f"building {len(jobs)} symbol-days; cached ones are skipped")
PANEL, VST = {}, []
with ThreadPoolExecutor(THREADS) as ex:
    futs = {ex.submit(get_day, s, d): (s, d) for s, d in jobs}
    for i, f in enumerate(as_completed(futs), 1):
        s, d = futs[f]
        try:
            df, st = f.result(); VST.append(st)
            if df is not None:
                PANEL[(s, d)] = df
        except Exception as e:
            VST.append({"symbol": s, "date": d, "reason": f"error: {e}"})
        if i % 200 == 0:
            print(f"   {i}/{len(jobs)}")
vst = pd.DataFrame(VST)
vst["depth_day_ok"] = vst.get("depth_day_ok", pd.Series(False, index=vst.index)).fillna(False).astype(bool)
OK = sorted([(r.symbol, r.date) for r in vst.itertuples() if r.depth_day_ok and (r.symbol, r.date) in PANEL])
pd.DataFrame(DL_LOG).to_csv(os.path.join(RESULTS, "p5_manifest_sha256.csv"), index=False)
record("Y2_build", None, "audit", {"symbol_days_requested": len(jobs), "symbol_days_valid": len(OK),
       "by_symbol": vst.groupby("symbol")["depth_day_ok"].agg(["sum", "count"]).to_dict("index")})
