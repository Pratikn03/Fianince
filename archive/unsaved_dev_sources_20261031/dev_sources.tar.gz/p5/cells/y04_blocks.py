# ============================================================================
# CELL Y4 — THIN CLASSIFICATION AND HOURLY BLOCKS
# Thin = median training-period depth within 1% of mid below THIN_DEPTH_MUSD, the boundary between
# Part 4's thin and mid terciles (largest thin 0.3815 $M, smallest mid 0.4003 $M). Fixed here.
# Each block also stores the three terms of C3 and a unit-free amplification ratio:
#   A_ratio = (φε + κ²ηq) / ((1-a)κ) - 1      (> 0 exactly when C3 > 0; invariant to flow units)
# ============================================================================
THIN_DEPTH_MUSD = 0.39
FLOW_SCALE, DEPTH_TR = {}, {}
for s in SYMBOLS:
    tr_days = [d for (s2, d) in OK if s2 == s and d <= TRAIN_END]
    v = [np.nanmedian(np.abs(PANEL[(s, d)]["flow"].to_numpy())) for d in tr_days]
    FLOW_SCALE[s] = float(np.nanmedian(v)) if v and np.nanmedian(v) > 0 else 1.0
    dep = [np.nanmedian((PANEL[(s, d)]["bid1"] + PANEL[(s, d)]["ask1"]).to_numpy()) for d in tr_days]
    DEPTH_TR[s] = float(np.nanmedian(dep)) if dep else np.nan
GROUP = {s: ("thin" if DEPTH_TR[s] < THIN_DEPTH_MUSD else "not_thin") for s in SYMBOLS if np.isfinite(DEPTH_TR[s])}
print("training depth ($M):", {s: round(v, 3) for s, v in DEPTH_TR.items()})
print("thin:", [s for s, g in GROUP.items() if g == "thin"])

def fit_terms(p, u, d, x):
    est = fit_t6(p, u, d, x)
    if est is None:
        return None
    t1, t2, t3 = est["phi"] * est["eps"], est["kappa"] ** 2 * est["eta"] * est["q"], (1 - est["a"]) * est["kappa"]
    est.update({"term_depth": t1, "term_momentum": t2, "term_reversion": t3,
                "A_ratio": (t1 + t2) / t3 - 1 if t3 > 1e-12 else np.nan})
    return est

def day_blocks5(s, d):
    df = PANEL[(s, d)]
    p, u, dd_, x, tot = prep(df, FLOW_SCALE[s])
    oi = df["oi"].ffill().to_numpy(); vol = df["vol"].to_numpy(); rows = []
    for hr in range(6, 24):
        t = hr * 60
        w, h, f = slice(t - 360, t), slice(t - 60, t), slice(t, min(t + 61, 1440))
        est = fit_terms(p[w], u[w], dd_[w], x[w])
        rows.append({"symbol": s, "date": d, "hour": hr,
                     **{k: (est[k] if est else np.nan) for k in ["C3", "A_ratio", "term_depth", "term_momentum", "term_reversion", "peak_ratio"]},
                     "rv_60": np.nanstd(np.diff(p[h])), "rv_360": np.nanstd(np.diff(p[w])), "abs_ret_60": abs(p[t - 1] - p[t - 60]),
                     "flow_imb_60": np.nansum(u[h]) / (np.nansum(np.abs(u[h])) + 1e-12),
                     "log_vol_60": np.log1p(np.nansum(vol[h])),
                     "log_depth1": np.log(tot[t - 1]) if np.isfinite(tot[t - 1]) and tot[t - 1] > 0 else np.nan,
                     "imbalance": dd_[t - 1],
                     "oi_chg_60": (oi[t - 1] / oi[t - 60] - 1) * 100 if np.isfinite(oi[t - 60]) and oi[t - 60] > 0 else np.nan,
                     "MAE_60": float(np.nanmax(np.abs(p[f] - p[t - 1])))})
    return rows

BLK5 = os.path.join(XDATA, f"blocks_p5_{len(SYMBOLS)}sym.parquet")
want = {(s, d) for (s, d) in OK if s in GROUP}
if os.path.exists(BLK5) and set(map(tuple, pd.read_parquet(BLK5)[["symbol", "date"]].drop_duplicates().to_numpy())) >= want:
    YB = pd.read_parquet(BLK5)
else:
    rows = []
    for i, (s, d) in enumerate(sorted(want)):
        rows += day_blocks5(s, d)
        if (i + 1) % 300 == 0:
            print(f"   blocks: {i+1}/{len(want)}")
    YB = pd.DataFrame(rows); YB.to_parquet(BLK5)
YB = YB.rename(columns={"C3": "C3_hat"})
YB["group"] = YB["symbol"].map(GROUP)
YB["split"] = np.where(YB["date"] <= TRAIN_END, "train", np.where(YB["date"] >= TEST_START, "test", "gap"))
print(YB.groupby(["group", "split"]).size().unstack())
record("Y3_groups", None, "audit", {"depth_train_musd": DEPTH_TR, "group": GROUP, "thin_cut_musd": THIN_DEPTH_MUSD,
       "blocks": YB.groupby(["group", "split"]).size().unstack().to_dict()})
