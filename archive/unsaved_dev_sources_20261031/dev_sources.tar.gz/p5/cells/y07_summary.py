# ============================================================================
# CELL Y7 — DESCRIPTIVES (training only) AND DOWNLOAD
# ============================================================================
trn = YB[YB["split"] == "train"]
desc = {}
for g in ["thin", "not_thin"]:
    T = trn[trn["group"] == g]
    if len(T):
        desc[g] = {"blocks": len(T), "share_C3_pos": float((T["C3_hat"] > 0).mean()),
                   **{f"median_{c}": float(T[c].median()) for c in ["C3_hat", "A_ratio", "term_depth", "term_momentum", "term_reversion"]},
                   "corr_MAE": {c: float(T[[c, "MAE_60"]].corr(method="spearman").iloc[0, 1]) for c in ["C3_hat", "A_ratio", "term_depth", "term_momentum", "term_reversion"]}}
print(json.dumps(desc, indent=1))
record("Y7_descriptives_train", None, "real-data", desc, note="Training period only: which term of C3 moves with tail risk.")
zp = os.path.join(BASE, "p5_results.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in glob.glob(os.path.join(RESULTS, "Y*.json")) + [os.path.join(RESULTS, "p5_manifest_sha256.csv"), p5_path, pth5]:
        if os.path.exists(fp):
            z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", zp)
if IN_COLAB:
    from google.colab import files
    files.download(zp)
