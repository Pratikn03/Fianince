# ============================================================================
# CELL Y6 — REPLICATION TEST ON 2025-2026 (RUN ONCE; every run is counted)
# ============================================================================
assert os.path.exists(p5_path), "run Y5 first"
pth5 = os.path.join(PREREG, "test_set_unlocks_p5.json")
n_unl5 = (json.load(open(pth5))["n"] if os.path.exists(pth5) else 0) + 1
json.dump({"n": n_unl5, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "spec_sha256": P5_HASH}, open(pth5, "w"))
thin5 = YB[YB["group"] == "thin"]
primary5 = evaluate(thin5, "MAE_60", "C3_hat")
secondary5 = {"thin: MAE_60 | A_ratio": evaluate(thin5, "MAE_60", "A_ratio"),
              "thin: MAE_60 | term_momentum": evaluate(thin5, "MAE_60", "term_momentum"),
              "thin: MAE_60 | term_depth": evaluate(thin5, "MAE_60", "term_depth"),
              "thin: MAE_60 | term_reversion": evaluate(thin5, "MAE_60", "term_reversion"),
              "not_thin: MAE_60 | C3_hat": evaluate(YB[YB["group"] == "not_thin"], "MAE_60", "C3_hat")}
ps = sorted([(v["clark_west_p"] if np.isfinite(v.get("clark_west_p", np.nan)) else 1.0, k) for k, v in secondary5.items()])
for i, (p_, k) in enumerate(ps):
    secondary5[k]["holm_p"] = min(1.0, max(p2 * (len(ps) - j) for j, (p2, _) in enumerate(ps[:i + 1])))
show = lambda v: {k: (round(v[k], 5) if isinstance(v.get(k), float) else v.get(k)) for k in ["n_train", "n_test", "n_symbols", "delta_r2", "delta_r2_ci", "delta_auc_ci", "clark_west_p", "holm_p", "coef_candidate_train", "skipped"] if k in v}
print("PRIMARY (thin, new symbols):", show(primary5))
for k, v in secondary5.items():
    print(k, show(v))
ok5 = bool(np.isfinite(primary5.get("clark_west_p", np.nan)) and primary5["clark_west_p"] < 0.05 and primary5["delta_r2_ci"][0] > 0)
record("Y6_replication_G2", ok5, "real-data", {"primary": primary5, "secondary": secondary5, "prereg_sha256": P5_HASH,
       "test_set_unlocks": n_unl5}, criterion=PREREG_P5["success"],
       note="Out-of-sample replication on new symbols. Report whatever it shows; unlocks > 1 must be disclosed.")
