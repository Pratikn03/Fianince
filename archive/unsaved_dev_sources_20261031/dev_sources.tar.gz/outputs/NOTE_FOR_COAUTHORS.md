# Restructured drafts: what changed and why

**Purpose.** Show the two papers in the shape intended for submission (JF for Paper 2, QE for Paper 1). Nothing is
deleted: every theorem, table and test of the current versions is still in the PDF, either in the main text or in the
Internet Appendix / supplement. Red PENDING boxes mark results that require new work (see `WORK_ORDERS.md`); no number in
these drafts is invented.

## Paper 2 — *Safety Without Identification: Certifying Transient Risk in Algorithmic Markets*
- New title and abstract around one question: what information certifies a safe trading decision when the traders cannot be identified.
- Main text about 40 pages (was about 60): model → amplification and closed-form S → safety depends only on S → certification versus identification → guard under uncertainty and disclosure → equilibrium → one evidence section → conclusion.
- Evidence section: one table of all 18 registered tests, the forest plot, the strongest result (beyond volatility), three new tests designed to test the mechanism and the economic value (PENDING), an explicit list of failures and the threats to validity.
- Moved to the Internet Appendix: spectral-stability theorem and multi-asset coupling, venue mode, balance-sheet solvency, sequential certification, unknown-covariance certificates, all per-test evidence sections.
- Fixes: microfoundation now states the no-carried-inventory assumption; abstract says "minimax-optimal up to a logarithmic factor"; the matched-shock benchmark is labelled an in-model illustration not at matched capacity.

## Paper 1 — *What Prices Reveal About Trading Algorithms, and What It Costs to Learn More*
- New title, shorter abstract, tighter introduction with four results.
- Main text about 48 pages: the tri-region analysis, probing protocols, the spectral blind spot and the full feedback-index analysis move to the supplement, with a one-page summary in the main text.
- New sections (PENDING): robustness to realistic learners; disclosure in dollars against the cost of the Consolidated Audit Trail.
- Fix: microfoundation states the no-carried-inventory assumption.

## Decisions for the authors
1. Accept the new titles and the restructure (or keep the current titles with the new structure).
2. Target journals and whether the submission must be anonymized.
3. Approve the three new Paper 2 tests and the two Paper 1 additions before data are opened (OSF deposit).
