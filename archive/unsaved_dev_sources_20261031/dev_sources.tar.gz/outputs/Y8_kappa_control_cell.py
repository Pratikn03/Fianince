# ============================================================================
# CELL Y8 — POST-HOC: IS C3 JUST PRICE IMPACT? (run after Y0–Y4; does NOT touch Y6's counter)
# Decided AFTER seeing Y6. Report as post-hoc robustness. Counted in prereg/robustness_evals_p5.json.
# Both terms that carried Y6 (momentum κ²ηq and reversion (1-a)κ) contain the impact coefficient κ.
# If C3 only measures price impact, adding impact controls should erase its forecasting gain.
# Impact controls (all from the same past 6 h / 1 h, no look-ahead), winsorized 1/99 on training data:
#   kappa_hat   κ from the same T6 fit that produces C3
#   kappa_sq    κ²
#   kyle_lam    univariate slope of Δp on signed flow, past 6 h
#   amihud_60   |60-min return| / 60-min volume, logged
# Checks (thin group, new symbols, same evaluation code as Y6):
#   K0 baseline C3 (must match Y6)          K1 C3 | + kappa_hat, kappa_sq
#   K2 C3 | + kyle_lam, amihud_60            K3 C3 | all four impact controls
#   K4 term_momentum | all four              K5 term_reversion | all four
#   K6 kappa_hat alone as the candidate (does raw impact forecast?)
# Reading: C3 is more than impact if K3 keeps CW p < 0.05 with ΔR² CI above 0.
# ============================================================================
BLK8 = os.path.join(XDATA, f"blocks_p5_kappa_{len(SYMBOLS)}sym.parquet")
thin_syms = sorted(s for s, g in GROUP.items() if g == "thin")
want8 = {(s, d) for (s, d) in OK if s in thin_syms}
assert want8, "no thin symbol-days: run Y0-Y4 first"
assert "CTRL" in globals(), "run Y5 first (defines CTRL)"

def day_blocks8(s, d):
    df = PANEL[(s, d)]
    p, u, dd_, x, tot = prep(df, FLOW_SCALE[s])
    vol = df["vol"].to_numpy(); dp = np.diff(p, prepend=np.nan); rows = []
    for hr in range(6, 24):
        t = hr * 60
        w, h = slice(t - 360, t), slice(t - 60, t)
        est = fit_t6(p[w], u[w], dd_[w], x[w])
        uu, yy = u[w][1:], dp[w][1:]; ok = np.isfinite(uu) & np.isfinite(yy)
        kl = float(np.polyfit(uu[ok], yy[ok], 1)[0]) if ok.sum() > 60 and np.std(uu[ok]) > 0 else np.nan
        v60 = np.nansum(vol[h])
        rows.append({"symbol": s, "date": d, "hour": hr,
                     "kappa_hat": est["kappa"] if est else np.nan, "kyle_lam": kl,
                     "amihud_60": np.log(abs(p[t - 1] - p[t - 60]) / v60 + 1e-9) if v60 > 0 and np.isfinite(p[t - 60]) else np.nan})
    return rows

if os.path.exists(BLK8) and set(map(tuple, pd.read_parquet(BLK8)[["symbol", "date"]].drop_duplicates().to_numpy())) >= want8:
    K8 = pd.read_parquet(BLK8)
else:
    rows = []
    for i, (s, d) in enumerate(sorted(want8)):
        rows += day_blocks8(s, d)
        if (i + 1) % 200 == 0:
            print(f"   impact blocks: {i+1}/{len(want8)}")
    K8 = pd.DataFrame(rows); K8.to_parquet(BLK8)

YK = YB[YB["group"] == "thin"].merge(K8, on=["symbol", "date", "hour"], how="left")
YK["kappa_sq"] = YK["kappa_hat"] ** 2
IMPACT = ["kappa_hat", "kappa_sq", "kyle_lam", "amihud_60"]
for c in IMPACT:                                    # winsorize controls with training quantiles only
    lo, hi = YK.loc[YK["split"] == "train", c].quantile([0.01, 0.99])
    YK[c] = YK[c].clip(lo, hi)
print("impact-control coverage:", {c: round(float(YK[c].notna().mean()), 3) for c in IMPACT})
print("train correlations with C3_hat:", YK[YK["split"] == "train"][["C3_hat"] + IMPACT].corr()["C3_hat"].round(3).to_dict())

def evaluate_ctrl(sub, outcome, cand, extra):
    global CTRL
    _saved = CTRL
    try:
        CTRL = _saved + extra
        return evaluate(sub, outcome, cand)
    finally:
        CTRL = _saved

checks8 = {
    "K0_baseline_C3":            evaluate_ctrl(YK, "MAE_60", "C3_hat", []),
    "K1_C3_plus_kappa":          evaluate_ctrl(YK, "MAE_60", "C3_hat", ["kappa_hat", "kappa_sq"]),
    "K2_C3_plus_kyle_amihud":    evaluate_ctrl(YK, "MAE_60", "C3_hat", ["kyle_lam", "amihud_60"]),
    "K3_C3_plus_all_impact":     evaluate_ctrl(YK, "MAE_60", "C3_hat", IMPACT),
    "K4_momentum_plus_all":      evaluate_ctrl(YK, "MAE_60", "term_momentum", IMPACT),
    "K5_reversion_plus_all":     evaluate_ctrl(YK, "MAE_60", "term_reversion", IMPACT),
    "K6_kappa_alone":            evaluate_ctrl(YK, "MAE_60", "kappa_hat", []),
}
ps = sorted([(v["clark_west_p"] if np.isfinite(v.get("clark_west_p", np.nan)) else 1.0, k) for k, v in checks8.items() if k != "K0_baseline_C3"])
for i, (p_, k) in enumerate(ps):
    checks8[k]["holm_p"] = min(1.0, max(p2 * (len(ps) - j) for j, (p2, _) in enumerate(ps[:i + 1])))

pth8 = os.path.join(PREREG, "robustness_evals_p5.json")
n_rob8 = (json.load(open(pth8))["n"] if os.path.exists(pth8) else 0) + 1
json.dump({"n": n_rob8, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, open(pth8, "w"))

rows = []
for k, v in checks8.items():
    if v.get("skipped"):
        rows.append({"check": k, "note": v["skipped"]}); continue
    rows.append({"check": k, "n_test": v["n_test"], "dR2_pts": round(100 * v["delta_r2"], 3),
                 "CI_pts": [round(100 * c, 3) for c in v["delta_r2_ci"]],
                 "dAUC_CI": [round(c, 4) for c in v["delta_auc_ci"]],
                 "CW_p": round(v["clark_west_p"], 5), "Holm_p": round(v.get("holm_p", np.nan), 5),
                 "coef": round(v["coef_candidate_train"], 2)})
print(pd.DataFrame(rows).to_string(index=False))
k3 = checks8["K3_C3_plus_all_impact"]
survives = bool(not k3.get("skipped") and k3["clark_west_p"] < 0.05 and k3["delta_r2_ci"][0] > 0)
print("\nC3 survives all impact controls:", survives)
record("Y8_kappa_control_posthoc", survives, "real-data",
       {"checks": checks8, "impact_controls": IMPACT, "robustness_evaluations": n_rob8,
        "train_corr_with_C3": YK[YK["split"] == "train"][["C3_hat"] + IMPACT].corr()["C3_hat"].to_dict()},
       criterion="K3: CW p < 0.05 and ΔR² CI above 0 with all four impact controls added",
       note="POST-HOC. Report separately from the pre-registered Y6 result.")
_zp8 = os.path.join(BASE, "p5_kappa.zip")
with zipfile.ZipFile(_zp8, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in [os.path.join(RESULTS, "Y8_kappa_control_posthoc.json"), pth8]:
        z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", _zp8)
if IN_COLAB:
    from google.colab import files
    files.download(_zp8)
