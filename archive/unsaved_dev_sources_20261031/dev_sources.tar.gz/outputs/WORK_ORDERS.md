# Work orders to fill the PENDING boxes

The two restructured papers (`p1/paper1_9plus.pdf`, `p2/paper2_9plus.pdf`) are complete except for the red PENDING boxes.
Each box needs one result. This file is the specification. Write each pre-registration file, hash it and deposit it
on OSF **before** opening the test data; then run the notebook and send the results zip.

---

## Part 19 — Is the mechanism leverage? (Paper 2, Section 8.3) — highest priority

| Item | Specification |
|---|---|
| Data | Binance Vision USD-M **daily `metrics`** files (`data/futures/um/daily/metrics/{SYM}/{SYM}-metrics-{DATE}.zip`; 5-minute `sum_open_interest_value`); monthly **`fundingRate`**; the depth files and minute bars already used in Parts 9/16; Binance **spot** klines and trades for the same coins (placebo). |
| Universe | The thin symbols of Parts 9 and 16 that have a Binance spot pair. |
| Dates | Fresh: the **8th and 22nd** of each month, Jan 2025 – Sep 2026 (check no earlier Part used them). Training: Part 9 training days. |
| Leverage | `LEV_t` = mean over the prior 6 hours of open-interest value divided by depth within 1% of mid (from the depth files). Terciles from **training** data. |
| Model | The Part 9 forecasting model: next-hour MAE on the full volatility baseline + Ĉ3 (+ impact controls). Add `Ĉ3 × 1[LEV in top tercile]` and the tercile dummy. |
| Primary 1 | Interaction coefficient > 0, date-block bootstrap (2,000 draws) 95% interval above 0. Equivalent check: ΔR²(high LEV) − ΔR²(low LEV) > 0. |
| Primary 2 (only if 1 passes) | On Binance **spot** for the same coins and dates, ΔR² of Ĉ3 (flow from spot trades) ≤ 0.25 × the perpetual ΔR²; one-sided bootstrap test. |
| Secondary (Holm) | Interaction with |funding|; Coinbase–Binance lead–lag for Part 17 coins (cross-correlation of 1-minute returns, lags −5..+5). |
| Output | `P19_leverage.json`: coefficients, CIs, Clark–West t, ΔR² by tercile, the spot comparison, pass flags, spec hash, unlock counter. |

## Part 20 — Natural experiment in fees (Paper 2, Section 8.4)

| Item | Specification |
|---|---|
| Events | Fix the list **before** looking at outcomes: the two fee events of Paper 1 (`V3_fee_events`) plus every Binance USD-M maker-fee or rebate change in official announcements, 2023–2026. Record date, affected symbols and the size of the change. |
| Design | Difference in differences: affected against unaffected pairs (other quote currency or excluded tiers), ±30 days around each event, day-clustered standard errors. |
| Outcomes | Daily estimates of reversion `m = 1 − a`, impact `κ̃`, and the unit-free multiple `S/κ̃` from the structural fit of Section 4. |
| Primary | Rebate up ⇒ `m` up and `S/κ̃` down (one-sided, pooled across events). |
| Report | Power at the observed sample size; a well-powered null is a result. |
| Output | `P20_fees.json`. |

## Part 21 — The guard's value in dollars (Paper 2, Section 8.5)

| Item | Specification |
|---|---|
| Samples | The untouched samples of Parts 15 and 16 (already opened: label the test as pre-registered on new outcomes, not new data). |
| Position | Each hour a stylized 20× position of $1M notional, long or short by the sign of the previous hour's return (or fixed long; pick one before running). |
| Rules | (a) static limit; (b) volatility cap; (c) volatility cap × certified guard (Part 15 definition); (d) guard alone. **Scale all four to the same average exposure** over the training days. |
| Outcomes | Share of hours that reach maintenance margin (0.5%), expected shortfall (95%) of hourly loss, net P&L after 4 bp costs; dollars per $1M notional per year. |
| Primary | (c) has fewer margin breaches than (b); date-block bootstrap interval of the difference below 0. |
| Output | `P21_dollar_value.json`. |

## Paper 1 — Realistic learners (Section 7)

| Item | Specification |
|---|---|
| Learners | (1) exponential momentum with tanh position limit; (2) threshold rule (trade only if |y|>τ, τ = training 75th percentile); (3) recursive least squares with forgetting 1−η; (4) 2-layer MLP (16 units), online SGD with learning rate η on next-period return; (5) tabular Q-learner on a discretized signal. |
| Market | The Paper 1 price equation (a = 0.5, κ = 0.8), cohorts replaced by the learners; burn-in to a steady state; common random numbers across arms. |
| Test A | Two populations with the same merged weight but different splits; response to probes of size A ∈ {0.01, 0.03, 0.1, 0.3, 1} times flow s.d. Report the response gap; prediction O(A²). |
| Test B | Pair with rates η ± δ vs single learner with η, δ ∈ {0.02, 0.03, 0.05, 0.08, 0.12}; report ‖Δh‖₂ (prediction slope 2) and the capital to separate (slope −4); report the probe size at which saturation breaks the law. |
| Output | `P1_learners.json` + figure `fig_learners.pdf`. |

## Paper 1 — Disclosure in dollars (Section 8.2)

| Item | Specification |
|---|---|
| Inputs | Official CAT cost figures from SEC releases (Rule 613 adopting release; Release 34-102386, Feb 2025, and its cost discussion). Cite page numbers. |
| Table | Probing capital avoided per market for K = 2, 3, 4 and δ (or Δη) ∈ {0.02, 0.05, 0.10}, from the paper's capital formula and the K-cohort rate; against the CAT annual cost; break-even number of markets. |
| Caveat | Probing capital is a lower bound on the cost of learning from prices, not a social cost. |

---

When results arrive, each PENDING box is replaced by one paragraph and one table or figure, and the abstract and
introduction sentences marked PENDING are written from the numbers, whatever they show.
