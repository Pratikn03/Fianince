# ============================================================================
# CELL X6r — POST-HOC ROBUSTNESS OF THE X6 RESULT (run after X0 only; does NOT touch X6's counter)
# These checks were decided AFTER seeing X6. Report them as post-hoc robustness, separately from
# the pre-registered result. Every evaluation here is counted in prereg/robustness_evals_xsec.json.
# The concern: thin coins have coarse price ticks, and several cut their tick inside the test period.
# Coarse ticks distort both the C3 estimate and MAE measured in basis points.
#   R0  baseline: the X6 primary, re-computed (should match X6)
#   R1  + relative tick size (bp) and its log as controls
#   R2  drop every symbol whose tick changed at any time (X7 events)
#   R3  keep all symbols, drop symbol-days whose tick differs from the symbol's training-period tick
#   R4  outcome measured in ticks (MAE_bp / tick_bp) instead of basis points
#   R5  candidate = C3 percentile within symbol (training distribution), immune to scale
#   R6  leave-one-symbol-out (10 runs)
# ============================================================================
import glob as _glob
B_ROB = 500
TERC = {s: v["tercile"] for s, v in json.load(open(os.path.join(RESULTS, "X3_T6_cross_section.json")))["metrics"]["by_symbol"].items()}
blk_files = sorted(_glob.glob(os.path.join(XDATA, "blocks_*sym.parquet")))
assert blk_files, "blocks file not found: run X5 first"
XB_r = pd.read_parquet(blk_files[-1])
XB_r["tercile"] = XB_r["symbol"].map(TERC)
XB_r["split"] = np.where(XB_r["date"] <= TRAIN_END, "train", np.where(XB_r["date"] >= TEST_START, "test", "gap"))

# daily tick and relative tick (bp) from the cached minute files
tick_rows = []
for js in _glob.glob(os.path.join(XDATA, "minute", "*", "*.json")):
    st = json.load(open(js)); s, d = st.get("symbol"), st.get("date")
    pq = js[:-5] + ".parquet"
    if s in TERC and st.get("tick") and os.path.exists(pq):
        px = float(pd.read_parquet(pq, columns=["close"])["close"].median())
        tick_rows.append({"symbol": s, "date": d, "tick": st["tick"], "rel_tick_bp": st["tick"] / px * 1e4})
TKD = pd.DataFrame(tick_rows)
XB_r = XB_r.merge(TKD, on=["symbol", "date"], how="left")
XB_r["log_rel_tick"] = np.log(XB_r["rel_tick_bp"])
XB_r["MAE_ticks"] = XB_r["MAE_60"] / XB_r["rel_tick_bp"]
train_tick = (TKD[TKD["date"] <= TRAIN_END].groupby("symbol")["tick"].agg(lambda v: v.mode().iloc[0]))
XB_r["same_tick_as_train"] = np.isclose(XB_r["tick"], XB_r["symbol"].map(train_tick))
ev = json.load(open(os.path.join(RESULTS, "X7_tick_natural_experiment.json")))["metrics"]["events"]
TICK_CHANGED = sorted({e["symbol"] for e in ev})
print("symbols with a tick change:", TICK_CHANGED)
# C3 percentile within symbol, using each symbol's training distribution only
def _pct(g):
    tr = np.sort(g.loc[g["split"] == "train", "C3_hat"].dropna().to_numpy())
    return pd.Series(np.searchsorted(tr, g["C3_hat"].to_numpy()) / max(len(tr), 1), index=g.index)
XB_r["C3_pct"] = XB_r.groupby("symbol", group_keys=False).apply(_pct)

CTRL0 = ["rv_60", "rv_360", "abs_ret_60", "flow_imb_60", "log_vol_60", "log_depth1", "imbalance", "oi_chg_60"]
def _design(D, cols, syms):
    return np.column_stack([np.ones(len(D))] + [D[c].to_numpy() for c in cols] + [(D["symbol"] == s).to_numpy(float) for s in syms[1:]])
def _cw(y, fb, ff, lags=6):
    adj = (y - fb) ** 2 - ((y - ff) ** 2 - (fb - ff) ** 2); m = adj.mean(); e = adj - m; n = len(adj)
    lrv = e @ e / n + 2 * sum((1 - l / (lags + 1)) * (e[l:] @ e[:-l]) / n for l in range(1, lags + 1))
    t_ = m / np.sqrt(lrv / n); return float(t_), float(1 - stats.norm.cdf(t_))
def ev_rob(sub, outcome="MAE_60", cand="C3_hat", ctrl=CTRL0, B=B_ROB, seed=91):
    A0 = sub[sub["split"] == "train"].copy(); B0 = sub[sub["split"] == "test"].copy()
    lo, hi = A0[cand].quantile([0.01, 0.99]); A0["cw_"] = A0[cand].clip(lo, hi); B0["cw_"] = B0[cand].clip(lo, hi)
    need = ctrl + ["cw_", outcome]
    A = A0.dropna(subset=need); Bt = B0.dropna(subset=need).sort_values(["date", "symbol", "hour"])
    Bt = Bt[Bt["symbol"].isin(set(A["symbol"]))]
    if len(A) < 200 or len(Bt) < 200:
        return {"skipped": True, "n_train": len(A), "n_test": len(Bt)}
    syms = sorted(A["symbol"].unique()); y = Bt[outcome].to_numpy()
    bb = np.linalg.lstsq(_design(A, ctrl, syms), A[outcome].to_numpy(), rcond=None)[0]
    bf = np.linalg.lstsq(_design(A, ctrl + ["cw_"], syms), A[outcome].to_numpy(), rcond=None)[0]
    fb = _design(Bt, ctrl, syms) @ bb; ff = _design(Bt, ctrl + ["cw_"], syms) @ bf
    ybar = A[outcome].mean(); sst = np.sum((y - ybar) ** 2)
    t_, p_ = _cw(y, fb, ff)
    R_ = rng(seed); dd = Bt["date"].to_numpy(); ud = np.unique(dd); pos = {d: np.where(dd == d)[0] for d in ud}; dR = []
    for _ in range(B):
        idx = np.concatenate([pos[d] for d in R_.choice(ud, len(ud))])
        dR.append((np.sum((y[idx] - fb[idx]) ** 2) - np.sum((y[idx] - ff[idx]) ** 2)) / np.sum((y[idx] - ybar) ** 2))
    return {"n_train": len(A), "n_test": len(Bt), "n_symbols": len(syms),
            "delta_r2": float((np.sum((y - fb) ** 2) - np.sum((y - ff) ** 2)) / sst),
            "delta_r2_ci": [float(np.nanquantile(dR, .025)), float(np.nanquantile(dR, .975))],
            "clark_west_t": t_, "clark_west_p": p_, "coef_candidate_train": float(bf[len(ctrl) + 1])}

thin_r = XB_r[XB_r["tercile"] == "thin"]
res = {}
res["R0_baseline"] = ev_rob(thin_r)
res["R1_tick_controls"] = ev_rob(thin_r, ctrl=CTRL0 + ["rel_tick_bp", "log_rel_tick"])
res["R2_drop_tick_change_symbols"] = ev_rob(thin_r[~thin_r["symbol"].isin(TICK_CHANGED)])
res["R3_same_tick_as_train_only"] = ev_rob(thin_r[thin_r["same_tick_as_train"]])
res["R4_outcome_in_ticks"] = ev_rob(thin_r, outcome="MAE_ticks")
res["R5_C3_percentile_within_symbol"] = ev_rob(thin_r, cand="C3_pct")
res["R1+R3_both"] = ev_rob(thin_r[thin_r["same_tick_as_train"]], ctrl=CTRL0 + ["rel_tick_bp", "log_rel_tick"])
loso = {}
for s in sorted(thin_r["symbol"].unique()):
    loso[s] = ev_rob(thin_r[thin_r["symbol"] != s], B=200)
res["R6_leave_one_symbol_out"] = loso

pth = os.path.join(PREREG, "robustness_evals_xsec.json")
n_rob = (json.load(open(pth))["n"] if os.path.exists(pth) else 0) + 1
json.dump({"n": n_rob, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, open(pth, "w"))

rows = []
for k, v in res.items():
    if k == "R6_leave_one_symbol_out":
        continue
    if v.get("skipped"):
        rows.append({"check": k, "note": "skipped (too few blocks)"}); continue
    rows.append({"check": k, "n_test": v["n_test"], "n_sym": v["n_symbols"], "dR2_pts": round(100 * v["delta_r2"], 3),
                 "CI_pts": [round(100 * c, 3) for c in v["delta_r2_ci"]], "CW_p": round(v["clark_west_p"], 4),
                 "coef": round(v["coef_candidate_train"], 2)})
print(pd.DataFrame(rows).to_string(index=False))
print("\nleave-one-symbol-out (dR2 in pts, CI, CW p):")
for s, v in loso.items():
    if not v.get("skipped"):
        print(f"  without {s:10s}: {100*v['delta_r2']:+.3f}  [{100*v['delta_r2_ci'][0]:+.3f}, {100*v['delta_r2_ci'][1]:+.3f}]  p={v['clark_west_p']:.4f}")
record("X6r_robustness_posthoc", None, "real-data",
       {"checks": res, "tick_changed_symbols": TICK_CHANGED, "robustness_evaluations": n_rob,
        "tick_coverage_share": float(XB_r["rel_tick_bp"].notna().mean())},
       note="POST-HOC. Report separately from the pre-registered X6 result. The X6 result is robust to tick size "
            "if R1, R2, R3 and R4 keep a positive dR2 with CI above 0 and no single symbol drives it (R6).")
_zp = os.path.join(BASE, "xsec_robustness.zip")
with zipfile.ZipFile(_zp, "w", zipfile.ZIP_DEFLATED) as z:
    for fp in [os.path.join(RESULTS, "X6r_robustness_posthoc.json"), pth]:
        z.write(fp, os.path.relpath(fp, BASE))
print("zipped ->", _zp)
if IN_COLAB:
    from google.colab import files
    files.download(_zp)
