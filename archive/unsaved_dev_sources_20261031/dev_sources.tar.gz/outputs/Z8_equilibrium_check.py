# ============================================================================
# CELL Z8 — EQUILIBRIUM PREDICTION (training data only; does not touch the test set)
# Paper 2's equilibrium: fewer dealers -> less reversion -> higher summed response S. Prediction:
# S (and the gain multiple) is higher in thin books than in mid books. Run after Z5 (or Z7).
# ============================================================================
TR8 = ZB[ZB["split"] == "train"]
res8 = {}
for c in ["S60", "gain_multiple", "a_hat", "kappa_hat", "C3_hat"]:
    g = TR8.groupby("group")[c].median().to_dict()
    th, md = TR8.loc[TR8["group"] == "thin", c].dropna(), TR8.loc[TR8["group"] == "mid", c].dropna()
    R8 = rng(81); dates = TR8["date"].unique(); diffs = []
    for _ in range(1000):
        pick = set(R8.choice(dates, len(dates)))
        T_ = TR8[TR8["date"].isin(pick)]
        diffs.append(T_.loc[T_["group"] == "thin", c].median() - T_.loc[T_["group"] == "mid", c].median())
    res8[c] = {"median_thin": g.get("thin"), "median_mid": g.get("mid"),
               "thin_minus_mid_ci": [float(np.nanquantile(diffs, .025)), float(np.nanquantile(diffs, .975))]}
    print(f"{c:14s} thin {g.get('thin'):.4f}  mid {g.get('mid'):.4f}  thin-mid CI {np.round(res8[c]['thin_minus_mid_ci'], 4)}")
record("Z8_equilibrium_prediction", None, "real-data", res8,
       note="Equilibrium predicts S60 and gain_multiple higher in thin books (thin - mid CI above 0). Training data only.")
_zp8 = os.path.join(BASE, "p6_z8.zip")
with zipfile.ZipFile(_zp8, "w") as z:
    z.write(os.path.join(RESULTS, "Z8_equilibrium_prediction.json"), "results/Z8_equilibrium_prediction.json")
if IN_COLAB:
    from google.colab import files
    files.download(_zp8)
