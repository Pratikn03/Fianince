import InfoSafety.Prelude
import InfoSafety.RobustGuard

/-!
# October 2026 hardening results (Papers 1 and 2): the algebraic and order-theoretic cores

* Paper 1, Theorem `thm:rh`: the scalar chain behind the explicit Rayleigh--Hölder bound.
* Paper 1, Proposition `prop:tagged`: positivity of the IV Jacobian determinant.
* Paper 2, Theorem `thm:peak` (ii): the confluent peak lag is the stationary point of `a^(k-1) (aκ + φε k)`;
  (iv): the momentum-only residues lie in `[0, 1]`.
* Paper 2, Theorem `thm:sum`: the summed-response equations have the closed-form solution `κ̃ / (m - q κ̃)`.
* Paper 2, Theorem `thm:disclosure` (v): intersecting two upper bounds admits at least as much as either.
* Paper 2, Proposition `prop:equil` (v): equilibrium depth is increasing in the number of dealers and below the planner's.

Statements that need probability or analysis beyond these cores (the renewal coupling of `prop:lucas` (ii), the
Gaussian divergence bounds of `thm:spectral` (iv), the delta method) are not formalized here.
-/

open Finset

namespace InfoSafety

/-! ## Paper 1, Theorem `thm:rh` -/

/-- From `r² ≥ L₀ (1 - γ D)` and `r ≥ 0`, `r ≥ √L₀ · (1 - γ D)₊` when `γ D ≥ 0`; `s` is any nonnegative square root of
`L₀`. -/
theorem rh_radius_bound (r L0 s γ D : ℝ) (hr : 0 ≤ r) (hs : 0 ≤ s) (hsL : s ^ 2 = L0) (hγD : 0 ≤ γ * D)
    (h : L0 * (1 - γ * D) ≤ r ^ 2) : s * max 0 (1 - γ * D) ≤ r := by
  rcases le_total (1 - γ * D) 0 with hneg | hpos
  · rw [max_eq_left hneg, mul_zero]; exact hr
  · rw [max_eq_right hpos]
    set y := 1 - γ * D with hy
    have hy1 : y ≤ 1 := by rw [hy]; linarith
    have hL0 : 0 ≤ L0 := by rw [← hsL]; positivity
    have hsq : (s * y) ^ 2 ≤ r ^ 2 := by
      rw [mul_pow, hsL]
      have : y ^ 2 ≤ y := by nlinarith
      nlinarith [mul_le_mul_of_nonneg_left this hL0]
    have hl : 0 ≤ s * y := mul_nonneg hs hpos
    nlinarith [sq_nonneg (s * y - r), sq_nonneg (s * y + r)]

/-- **The explicit Rayleigh--Hölder chain.** With loss `L₀ + x²`, a fee that is nonnegative and at least
`c ‖Ed‖₁ r - x √W`, and `r ≥ √L₀ (1 - γ x²)₊`, loss plus fee is at least
`L₀ + x² + max 0 (F (1 - γ x²)₊ - √W x)` with `F = c ‖Ed‖₁ √L₀` (`s = √L₀`, `sW = √W`). -/
theorem rh_chain (L0 x r fee cE s sW γ : ℝ) (hcE : 0 ≤ cE) (hfee0 : 0 ≤ fee)
    (hfee : cE * r - x * sW ≤ fee) (hr : s * max 0 (1 - γ * x ^ 2) ≤ r) :
    L0 + x ^ 2 + max 0 (cE * s * max 0 (1 - γ * x ^ 2) - sW * x) ≤ L0 + x ^ 2 + fee := by
  have h1 : cE * s * max 0 (1 - γ * x ^ 2) ≤ cE * r := by
    rw [mul_assoc]; exact mul_le_mul_of_nonneg_left hr hcE
  have h2 : max 0 (cE * s * max 0 (1 - γ * x ^ 2) - sW * x) ≤ fee :=
    max_le hfee0 (by linarith)
  linarith

/-! ## Paper 1, Proposition `prop:tagged` -/

/-- **IV Jacobian determinant is positive.** With nonnegative autocovariance weights `c`, modes in `[0,1)`, memory rate
`r ∈ [0,1)`, positive merged weight `w` and at least one positive weight, `w ∑ₗ ∑ₘ cₗ cₘ (1 - λₗλₘ)/(1 - r λₘ) > 0`. -/
theorem iv_det_pos {n : ℕ} (c lam : Fin n → ℝ) (w r : ℝ) (hw : 0 < w) (hr0 : 0 ≤ r) (hr1 : r < 1)
    (hc : ∀ l, 0 ≤ c l) (hl0 : ∀ l, 0 ≤ lam l) (hl1 : ∀ l, lam l < 1) (hpos : ∃ l, 0 < c l) :
    0 < w * ∑ l, ∑ m, c l * c m * (1 - lam l * lam m) / (1 - r * lam m) := by
  have hden : ∀ m, 0 < 1 - r * lam m := fun m => by nlinarith [hl0 m, hl1 m]
  have hnum : ∀ l m, 0 ≤ 1 - lam l * lam m := fun l m => by nlinarith [hl0 l, hl1 l, hl0 m, hl1 m]
  have hterm : ∀ l m, 0 ≤ c l * c m * (1 - lam l * lam m) / (1 - r * lam m) := fun l m =>
    div_nonneg (mul_nonneg (mul_nonneg (hc l) (hc m)) (hnum l m)) (hden m).le
  obtain ⟨l0, hl0pos⟩ := hpos
  have hdiag : 0 < c l0 * c l0 * (1 - lam l0 * lam l0) / (1 - r * lam l0) := by
    have : 0 < 1 - lam l0 * lam l0 := by nlinarith [hl0 l0, hl1 l0]
    exact div_pos (mul_pos (mul_pos hl0pos hl0pos) this) (hden l0)
  apply mul_pos hw
  apply Finset.sum_pos' (fun l _ => Finset.sum_nonneg (fun m _ => hterm l m))
  refine ⟨l0, Finset.mem_univ _, ?_⟩
  exact Finset.sum_pos' (fun m _ => hterm l0 m) ⟨l0, Finset.mem_univ _, hdiag⟩

/-! ## Paper 2, Theorem `thm:peak` -/

/-- **(ii), confluent peak lag.** With `L = log (1/a) > 0`, so `log a = -L`, the derivative factor
`(aκ + φε k) log a + φε` of `a^(k-1)(aκ + φε k)` vanishes at `k* = 1/L - aκ/(φε)`. -/
theorem confluent_stationary (a κ φε L : ℝ) (hL : 0 < L) (hφε : 0 < φε) :
    (a * κ + φε * (1 / L - a * κ / φε)) * (-L) + φε = 0 := by
  field_simp
  ring

/-- **(iv), momentum-only residues.** If `λ₂ ≤ m₁₁ ≤ λ₁` and `λ₂ < λ₁`, the residue share
`(m₁₁ - λ₂)/(λ₁ - λ₂)` and its complement lie in `[0,1]`. -/
theorem momentum_residues (l1 l2 m11 : ℝ) (h21 : l2 < l1) (hlo : l2 ≤ m11) (hhi : m11 ≤ l1) :
    0 ≤ (m11 - l2) / (l1 - l2) ∧ (m11 - l2) / (l1 - l2) ≤ 1 ∧ 0 ≤ 1 - (m11 - l2) / (l1 - l2) := by
  have hd : 0 < l1 - l2 := by linarith
  have h1 : (m11 - l2) / (l1 - l2) ≤ 1 := by rw [div_le_one hd]; linarith
  exact ⟨div_nonneg (by linarith) hd.le, h1, by linarith⟩

/-! ## Paper 2, Theorem `thm:sum` -/

/-- **Closed-form summed response.** If the summed price `X`, depth `D` and momentum `F` responses satisfy the stationary
sum equations of the three-state model, then `X = κ̃ / (m - q κ̃)` with `κ̃ = κ + φε/r`, `m = 1 - a`. -/
theorem summed_response_closed_form (a κ φ ε r η q X D F : ℝ) (hr : r ≠ 0) (hη : η ≠ 0)
    (hden : 1 - a - q * (κ + φ * ε / r) ≠ 0)
    (hX : X = κ + a * X + φ * D + κ * F) (hD : D = ε + (1 - r) * D + ε * F) (hF : F = (1 - η) * F + η * q * X) :
    X = (κ + φ * ε / r) / (1 - a - q * (κ + φ * ε / r)) := by
  have hF' : F = q * X := by
    have : η * F = η * (q * X) := by linarith
    exact mul_left_cancel₀ hη this
  have hD' : D = ε * (1 + q * X) / r := by
    field_simp; rw [hF'] at hD; linarith
  rw [eq_div_iff hden]
  rw [hD', hF'] at hX
  field_simp at hX ⊢
  linarith

/-! ## Paper 2, Theorem `thm:disclosure` (v) -/

/-- **Intersecting two certificates.** The guard level computed from the smaller of two upper bounds on `Φ` is at least
the level computed from either one. -/
theorem intersection_admits_more (a κ L B P1 P2 : ℝ) (hκ : 0 < κ) (h1 : 0 < P1) (h2 : 0 < P2)
    (hc : 0 ≤ cI a κ L B) :
    alphaStar a κ L B P1 ≤ alphaStar a κ L B (min P1 P2) ∧ alphaStar a κ L B P2 ≤ alphaStar a κ L B (min P1 P2) := by
  have hm : 0 < min P1 P2 := lt_min h1 h2
  have key : ∀ P, 0 < P → min P1 P2 ≤ P → alphaStar a κ L B P ≤ alphaStar a κ L B (min P1 P2) := by
    intro P hP hle
    unfold alphaStar
    apply min_le_min_left
    apply div_le_div_of_nonneg_left hc (by positivity)
    exact mul_le_mul_of_nonneg_left hle hκ.le
  exact ⟨key P1 h1 (min_le_left _ _), key P2 h2 (min_le_right _ _)⟩

/-! ## Paper 2, Proposition `prop:equil` (v) -/

/-- `D ↦ D - A/D²` is strictly increasing on `D > 0` when `A ≥ 0`, so its level sets are single points and larger
right-hand sides have larger solutions. -/
theorem depth_solution_increasing (A b1 b2 D1 D2 : ℝ) (hA : 0 ≤ A) (hD1 : 0 < D1) (hD2 : 0 < D2)
    (h1 : D1 - A / D1 ^ 2 = b1) (h2 : D2 - A / D2 ^ 2 = b2) (hb : b1 < b2) : D1 < D2 := by
  by_contra h
  push_neg at h
  have hsq : D2 ^ 2 ≤ D1 ^ 2 := by nlinarith
  have : A / D1 ^ 2 ≤ A / D2 ^ 2 := div_le_div_of_nonneg_left hA (by positivity) hsq
  linarith

/-- **Equilibrium depth is below the planner's.** If `D_eq - θX/D_eq² = b` and `D_sp - N X/D_sp² = b` with
`X > 0` and `θ < N`, then `D_eq < D_sp`. -/
theorem depth_eq_lt_sp (θ N X b Deq Dsp : ℝ) (hX : 0 < X) (hθ : 0 ≤ θ) (hθN : θ < N) (hDeq : 0 < Deq) (hDsp : 0 < Dsp)
    (heq : Deq - θ * X / Deq ^ 2 = b) (hsp : Dsp - N * X / Dsp ^ 2 = b) : Deq < Dsp := by
  have hgap : θ * X / Dsp ^ 2 < N * X / Dsp ^ 2 := by
    apply div_lt_div_of_pos_right _ (by positivity); nlinarith
  apply depth_solution_increasing (θ * X) b (Dsp - θ * X / Dsp ^ 2) Deq Dsp (by positivity) hDeq hDsp heq rfl
  linarith

/-- **The depth rebate is identified.** With `S = Γ/D` and `κ̃ = 1/D`, the marginal external benefit `Γ/D²` equals
`S κ̃`. -/
theorem depth_rebate_identified (Γ D : ℝ) (hD : D ≠ 0) : Γ / D ^ 2 = (Γ / D) * (1 / D) := by
  field_simp

end InfoSafety
