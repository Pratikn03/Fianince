import InfoSafety.Prelude

/-!
# Theorem `thm:certcost` (i), the deterministic part (Paper 2)

For a positive cohort economy the stacked operator `J` is entrywise nonnegative, its price row sums to `a + κ Φ ≤ s̄` and
cohort row `i` sums to `1 - η_i (1 - a - κ Φ) ≤ λ̄ = 1 - (1 - r̄)(1 - s̄)` when `η_i ≥ 1 - r̄`. Then every coordinate of
`J^t b` is at most `κ λ̄^t` when the input `b` has entries in `[0, κ]`, so `h_t ≤ κ λ̄^t` and the tail after `T` periods
is at most `κ λ̄^T / (1 - λ̄)`.
-/

open Finset

namespace InfoSafety

/-- Cohort row sum bound: `1 - η (1 - a - κ Φ) ≤ 1 - (1 - r̄)(1 - s̄)` when `η ≥ 1 - r̄` and `a + κ Φ ≤ s̄ ≤ 1`. -/
theorem cohort_row_bound (η a κΦ rbar sbar : ℝ) (hη : 1 - rbar ≤ η) (hs : a + κΦ ≤ sbar) (hs1 : sbar ≤ 1)
    (hr : rbar ≤ 1) : 1 - η * (1 - a - κΦ) ≤ 1 - (1 - rbar) * (1 - sbar) := by
  have h1 : 0 ≤ 1 - sbar := by linarith
  have h2 : 1 - sbar ≤ 1 - a - κΦ := by linarith
  have h3 : 0 ≤ 1 - rbar := by linarith
  nlinarith [mul_le_mul hη h2 h1 (h3.trans hη)]

/-- Price row sum bound: `a + κ Φ ≤ λ̄`. -/
theorem price_row_bound (a κΦ rbar sbar : ℝ) (hs : a + κΦ ≤ sbar) (hs1 : sbar ≤ 1) (hr0 : 0 ≤ rbar) :
    a + κΦ ≤ 1 - (1 - rbar) * (1 - sbar) := by nlinarith

variable {n : ℕ}

/-- One application of a nonnegative operator with row sums at most `λ` maps `[0, M]^n` into `[0, λ M]^n`. -/
theorem step_bound (J : Fin n → Fin n → ℝ) (v : Fin n → ℝ) (lam M : ℝ) (hJ : ∀ i j, 0 ≤ J i j)
    (hrow : ∀ i, ∑ j, J i j ≤ lam) (hv0 : ∀ j, 0 ≤ v j) (hvM : ∀ j, v j ≤ M) (hM : 0 ≤ M) (i : Fin n) :
    0 ≤ ∑ j, J i j * v j ∧ ∑ j, J i j * v j ≤ lam * M := by
  refine ⟨Finset.sum_nonneg (fun j _ => mul_nonneg (hJ i j) (hv0 j)), ?_⟩
  calc ∑ j, J i j * v j ≤ ∑ j, J i j * M := Finset.sum_le_sum (fun j _ => mul_le_mul_of_nonneg_left (hvM j) (hJ i j))
    _ = (∑ j, J i j) * M := by rw [Finset.sum_mul]
    _ ≤ lam * M := mul_le_mul_of_nonneg_right (hrow i) hM

/-- Iterates of the operator. -/
def iter (J : Fin n → Fin n → ℝ) (b : Fin n → ℝ) : ℕ → Fin n → ℝ
  | 0 => b
  | t + 1 => fun i => ∑ j, J i j * iter J b t j

/-- **Geometric decay.** Every coordinate of `J^t b` lies in `[0, κ λ^t]`. -/
theorem iter_bound (J : Fin n → Fin n → ℝ) (b : Fin n → ℝ) (lam κ : ℝ) (hJ : ∀ i j, 0 ≤ J i j)
    (hrow : ∀ i, ∑ j, J i j ≤ lam) (hlam : 0 ≤ lam) (hb0 : ∀ j, 0 ≤ b j) (hbκ : ∀ j, b j ≤ κ) (hκ : 0 ≤ κ) :
    ∀ t i, 0 ≤ iter J b t i ∧ iter J b t i ≤ κ * lam ^ t := by
  intro t
  induction t with
  | zero => intro i; simp [iter, hb0 i, hbκ i]
  | succ t ih =>
    intro i
    have h := step_bound J (iter J b t) lam (κ * lam ^ t) hJ hrow (fun j => (ih j).1) (fun j => (ih j).2)
      (by positivity) i
    refine ⟨h.1, ?_⟩
    calc iter J b (t + 1) i = ∑ j, J i j * iter J b t j := rfl
      _ ≤ lam * (κ * lam ^ t) := h.2
      _ = κ * lam ^ (t + 1) := by ring

/-- **Tail bound.** `∑_{s<m} κ λ^{T+s} ≤ κ λ^T / (1 - λ)` for `0 ≤ λ < 1`, every `m`. -/
theorem tail_bound (κ lam : ℝ) (T m : ℕ) (hκ : 0 ≤ κ) (h0 : 0 ≤ lam) (h1 : lam < 1) :
    ∑ s ∈ range m, κ * lam ^ (T + s) ≤ κ * lam ^ T / (1 - lam) := by
  have hgeom : ∀ k : ℕ, (∑ s ∈ range k, lam ^ s) * (1 - lam) = 1 - lam ^ k := by
    intro k
    induction k with
    | zero => simp
    | succ k ih => rw [Finset.sum_range_succ, add_mul, ih]; ring
  have hg : ∑ s ∈ range m, lam ^ s = (1 - lam ^ m) / (1 - lam) := by
    have hne2 : 1 - lam ≠ 0 := sub_ne_zero.mpr h1.ne'
    rw [eq_div_iff hne2]; exact hgeom m
  have hsum : ∑ s ∈ range m, κ * lam ^ (T + s) = κ * lam ^ T * ∑ s ∈ range m, lam ^ s := by
    rw [Finset.mul_sum]; exact Finset.sum_congr rfl (fun s _ => by ring)
  rw [hsum, hg, mul_div_assoc']
  apply div_le_div_of_nonneg_right _ (by linarith)
  have : 0 ≤ lam ^ m := pow_nonneg h0 m
  nlinarith [mul_nonneg (mul_nonneg hκ (pow_nonneg h0 T)) this]

end InfoSafety
