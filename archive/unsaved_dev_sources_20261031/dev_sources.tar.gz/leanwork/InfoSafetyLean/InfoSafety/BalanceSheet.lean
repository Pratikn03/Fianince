import InfoSafety.Prelude

/-!
# Theorem `thm:forward` (Paper 2), one step with no drift

A dealer holds cash `K` and inventory `I` at mark `p`; equity is `K + I p`, maintenance margin `max 0 (μ |I| p - c₀)` and
the remaining buffer their difference. If hedge and fill costs `Ch, Cf` are paid and the price moves by `dp` with
`|dp| ≤ U`, the guard inequality `|I| (1 + μ) U + Ch + Cf + R ≤ buffer` keeps the buffer above the reserve `R`.
The Section 6 scenario (`E₀ = 10,000`, `I₀ = -2,000` at `100`, `μ = 0.005`, buffer `9,050`, reserve `950`) is checked:
the admissible shock is `8,100 / 2,010`, a move of `4.02` keeps the reserve and a move of `4.05` breaches it.
-/

namespace InfoSafety

/-- Remaining buffer `E - MM`. -/
noncomputable def buffer (K I p μ c0 : ℝ) : ℝ := K + I * p - max 0 (μ * |I| * p - c0)

/-- **Theorem `thm:forward` (one step, `z = 0`).** -/
theorem buffer_after_step (K I p dp μ c0 U Ch Cf R : ℝ) (hμ : 0 ≤ μ) (hdp : |dp| ≤ U)
    (hguard : |I| * (1 + μ) * U + Ch + Cf + R ≤ buffer K I p μ c0) :
    R ≤ buffer (K - Ch - Cf) I (p + dp) μ c0 := by
  unfold buffer at *
  have hmove : -(|I| * |dp|) ≤ I * dp := by
    have := abs_mul I dp; have := neg_abs_le (I * dp); nlinarith [abs_nonneg I, abs_nonneg dp]
  have hmm : max 0 (μ * |I| * (p + dp) - c0) ≤ max 0 (μ * |I| * p - c0) + μ * |I| * |dp| := by
    have h1 : μ * |I| * dp ≤ μ * |I| * |dp| := mul_le_mul_of_nonneg_left (le_abs_self dp) (by positivity)
    apply max_le
    · exact add_nonneg (le_max_left _ _) (by positivity)
    · have := le_max_right 0 (μ * |I| * p - c0); nlinarith
  have hU : |I| * |dp| ≤ |I| * U := mul_le_mul_of_nonneg_left hdp (abs_nonneg I)
  have hU2 : μ * |I| * |dp| ≤ μ * |I| * U := by
    have := mul_le_mul_of_nonneg_left hdp (mul_nonneg hμ (abs_nonneg I)); linarith
  nlinarith

/-- The admissible shock at `α = 0` with no drift. -/
noncomputable def admissibleShock (Brem R I μ : ℝ) : ℝ := (Brem - R) / (|I| * (1 + μ))

/-- **The Section 6 scenario.** -/
theorem scenario :
    buffer (10000 + 2000 * 100) (-2000) 100 0.005 50 = 9050 ∧
      admissibleShock 9050 950 (-2000) 0.005 = 8100 / 2010 ∧
      950 ≤ buffer (10000 + 2000 * 100) (-2000) (100 + 4.02) 0.005 50 ∧
      buffer (10000 + 2000 * 100) (-2000) (100 + 4.05) 0.005 50 < 950 := by
  unfold buffer admissibleShock
  refine ⟨?_, ?_, ?_, ?_⟩ <;> norm_num [abs_of_neg, max_def]

end InfoSafety
