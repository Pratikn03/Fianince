import InfoSafety.Prelude

/-!
# Theorem `thm:robustguard` (i)-(iv), Theorem `thm:disclosure` (i)-(ii) and Lemma `lem:sound` (Paper 2)

Cohort economy with price persistence `a`, impact `κ > 0`, feedback weight `Φ ≥ 0` and admission level `α`:
the summed response is `S(α, Φ) = κ / (1 - a - κ α Φ)`. With exposure `L = |I| ū > 0` and budget `B > 0`, a level is safe
when the denominator is positive and `L S ≤ B`; we write this without division as `0 < D ∧ L κ ≤ B D`.
The guard admits the levels that are safe for every `Φ ∈ [0, Φ⁺]`.
-/

namespace InfoSafety

/-- Denominator of the summed response. -/
def den (a κ α Φ : ℝ) : ℝ := 1 - a - κ * α * Φ

/-- A level is safe for one economy: stable and worst-case loss within budget (`L κ / D ≤ B`). -/
def Safe (a κ L B α Φ : ℝ) : Prop := 0 < den a κ α Φ ∧ L * κ ≤ B * den a κ α Φ

/-- The division form and the multiplicative form agree. -/
lemma safe_iff_div (a κ L B α Φ : ℝ) (hD : 0 < den a κ α Φ) (hB : 0 < B) :
    Safe a κ L B α Φ ↔ L * κ / den a κ α Φ ≤ B := by
  unfold Safe; rw [div_le_iff₀ hD]; constructor
  · rintro ⟨_, h⟩; linarith
  · intro h; exact ⟨hD, by linarith⟩

/-- Robustly safe: safe for every feedback weight in `[0, Φ⁺]`. -/
def RobustSafe (a κ L B Φp α : ℝ) : Prop := ∀ Φ ∈ Set.Icc (0 : ℝ) Φp, Safe a κ L B α Φ

/-- The capacity margin `c_I = 1 - a - κ L / B`. -/
noncomputable def cI (a κ L B : ℝ) : ℝ := 1 - a - κ * L / B

/-- For a nonnegative level, robust safety is exactly `κ α Φ⁺ ≤ c_I`. -/
lemma robustSafe_iff (a κ L B Φp α : ℝ) (hκ : 0 < κ) (hL : 0 < L) (hB : 0 < B) (hΦ : 0 ≤ Φp) (hα : 0 ≤ α) :
    RobustSafe a κ L B Φp α ↔ κ * α * Φp ≤ cI a κ L B := by
  unfold RobustSafe Safe den cI
  have hLκB : κ * L / B * B = L * κ := by field_simp
  constructor
  · intro h
    obtain ⟨_, h2⟩ := h Φp ⟨hΦ, le_refl _⟩
    have : κ * L / B ≤ 1 - a - κ * α * Φp := by
      rw [div_le_iff₀ hB]; linarith
    linarith
  · intro h Φ hΦ'
    have hmono : κ * α * Φ ≤ κ * α * Φp := mul_le_mul_of_nonneg_left hΦ'.2 (by positivity)
    have hpos : 0 < κ * L / B := by positivity
    refine ⟨by linarith, ?_⟩
    have : κ * L / B ≤ 1 - a - κ * α * Φ := by linarith
    have := mul_le_mul_of_nonneg_right this hB.le
    rw [hLκB] at this; linarith

/-- The guard level `α* = min 1 (c_I / (κ Φ⁺))`. -/
noncomputable def alphaStar (a κ L B Φp : ℝ) : ℝ := min 1 (cI a κ L B / (κ * Φp))

/-- **Theorem `thm:robustguard` (i) and (iii): closed form, interval and maximality.** If `c_I ≥ 0` the robustly safe levels
in `[0,1]` are exactly the interval `[0, α*]`; in particular `α*` is the greatest robustly safe level. -/
theorem robust_safe_set_eq (a κ L B Φp : ℝ) (hκ : 0 < κ) (hL : 0 < L) (hB : 0 < B) (hΦ : 0 < Φp)
    (hc : 0 ≤ cI a κ L B) :
    {α : ℝ | α ∈ Set.Icc (0 : ℝ) 1 ∧ RobustSafe a κ L B Φp α} = Set.Icc 0 (alphaStar a κ L B Φp) := by
  ext α
  simp only [Set.mem_setOf_eq, Set.mem_Icc, alphaStar, le_min_iff]
  constructor
  · rintro ⟨⟨h0, h1⟩, hs⟩
    refine ⟨h0, h1, ?_⟩
    rw [robustSafe_iff a κ L B Φp α hκ hL hB hΦ.le h0] at hs
    rw [le_div_iff₀ (by positivity)]; linarith
  · rintro ⟨h0, h1, h2⟩
    refine ⟨⟨h0, h1⟩, ?_⟩
    rw [robustSafe_iff a κ L B Φp α hκ hL hB hΦ.le h0]
    rw [le_div_iff₀ (by positivity)] at h2; linarith

theorem alphaStar_isGreatest (a κ L B Φp : ℝ) (hκ : 0 < κ) (hL : 0 < L) (hB : 0 < B) (hΦ : 0 < Φp)
    (hc : 0 ≤ cI a κ L B) :
    IsGreatest {α : ℝ | α ∈ Set.Icc (0 : ℝ) 1 ∧ RobustSafe a κ L B Φp α} (alphaStar a κ L B Φp) := by
  rw [robust_safe_set_eq a κ L B Φp hκ hL hB hΦ hc]
  refine ⟨⟨?_, le_refl _⟩, fun x hx => hx.2⟩
  unfold alphaStar; exact le_min zero_le_one (div_nonneg hc (by positivity))

/-- **Theorem `thm:robustguard` (iv): infeasibility.** If `c_I < 0`, no admission level in `[0,1]` is safe for any
economy with nonnegative feedback, including `α = 0`: the guard must halt. -/
theorem infeasible_of_cI_neg (a κ L B α Φ : ℝ) (hκ : 0 < κ) (hL : 0 < L) (hB : 0 < B) (hα : 0 ≤ α) (hΦ : 0 ≤ Φ)
    (hc : cI a κ L B < 0) : ¬ Safe a κ L B α Φ := by
  unfold Safe den
  unfold cI at hc
  rintro ⟨hD, h⟩
  have hfb : 0 ≤ κ * α * Φ := by positivity
  have : κ * L / B * B = L * κ := by field_simp
  have h3 : B * (1 - a - κ * α * Φ) ≤ B * (1 - a) := by nlinarith
  have h4 : B * (1 - a) < κ * L / B * B := by nlinarith
  linarith

/-- **Theorem `thm:robustguard` (ii) / Lemma `lem:sound`: soundness.** If the true feedback lies in `[0, Φ⁺]` (the event
that the certificate covers), every admitted level is safe for the true economy. -/
theorem sound (a κ L B Φp Φtrue α : ℝ) (hcov : Φtrue ∈ Set.Icc (0 : ℝ) Φp) (h : RobustSafe a κ L B Φp α) :
    Safe a κ L B α Φtrue := h Φtrue hcov

/-- **Theorem `thm:disclosure` (i): disclosure never lowers safe capacity.** A smaller certified bound admits more. -/
theorem disclosure_monotone (a κ L B Φtag Φpub α : ℝ) (hle : Φtag ≤ Φpub) (h : RobustSafe a κ L B Φpub α) :
    RobustSafe a κ L B Φtag α := fun Φ hΦ => h Φ ⟨hΦ.1, hΦ.2.trans hle⟩

/-- **Theorem `thm:disclosure` (ii): strictness.** When the public guard binds (`α*_pub < 1`, `c_I > 0`), excluding the
extremal economy (`Φ_tag < Φ_pub`) strictly raises capacity. -/
theorem disclosure_strict (a κ L B Φtag Φpub : ℝ) (hκ : 0 < κ) (hc : 0 < cI a κ L B) (h0 : 0 < Φtag)
    (hlt : Φtag < Φpub) (hbind : cI a κ L B / (κ * Φpub) < 1) :
    alphaStar a κ L B Φpub < alphaStar a κ L B Φtag := by
  unfold alphaStar
  rw [min_eq_right hbind.le]
  have h1 : cI a κ L B / (κ * Φpub) < cI a κ L B / (κ * Φtag) :=
    div_lt_div_of_pos_left hc (by positivity) (by nlinarith)
  exact lt_min hbind h1

/-- Abstract form of Theorem `thm:disclosure` (i): for any risk function, robust safety over a larger compatible set
implies robust safety over a smaller one. -/
theorem robust_safe_antitone {Θ U : Type*} (R : Θ → U → ℝ) (B : ℝ) (Θsmall Θbig : Set Θ) (hsub : Θsmall ⊆ Θbig)
    (u : U) (h : ∀ θ ∈ Θbig, R θ u ≤ B) : ∀ θ ∈ Θsmall, R θ u ≤ B := fun θ hθ => h θ (hsub hθ)

end InfoSafety
