import InfoSafety.Prelude

/-!
# Lemma `lem:certnum` (Paper 2), weak-duality part

A positive cohort economy has a merged measure with finitely many atoms: weights `w i ≥ 0` at memory rates `x i ∈ [0, r̄]`.
The window identifies its moments `k j = ∑ w i x i ^ j` for `j < n`. For any polynomial `p(r) = ∑_{j<n} c j r ^ j`:
`∑ c j k j = ∑ w i p (x i)`. Hence if `p ≥ f` on `[0, r̄]`, every compatible economy has `Φ = ∑ w i f (x i) ≤ ∑ c j k j`,
and if `p ≤ f`, `Φ ≥ ∑ c j k j`. These are the bounds that the interval-arithmetic verification certifies.
-/

open Finset

namespace InfoSafety

variable {m n : ℕ}

/-- Moments of an atomic measure. -/
def moment (w x : Fin m → ℝ) (j : ℕ) : ℝ := ∑ i, w i * x i ^ j

/-- Polynomial with coefficients `c` (degree `< n`). -/
def poly (c : Fin n → ℝ) (r : ℝ) : ℝ := ∑ j, c j * r ^ (j : ℕ)

/-- `∑ c j k j = ∫ p dM` for an atomic measure (exchange of finite sums). -/
theorem coeff_moment_eq (w x : Fin m → ℝ) (c : Fin n → ℝ) :
    ∑ j, c j * moment w x j = ∑ i, w i * poly c (x i) := by
  unfold moment poly
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => by ring))

/-- **Upper bound.** If `p ≥ f` on the support, `Φ ≤ ∑ c j k j`. -/
theorem upper_bound (w x : Fin m → ℝ) (c : Fin n → ℝ) (f : ℝ → ℝ) (rbar : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hx : ∀ i, x i ∈ Set.Icc (0 : ℝ) rbar) (hp : ∀ r ∈ Set.Icc (0 : ℝ) rbar, f r ≤ poly c r) :
    ∑ i, w i * f (x i) ≤ ∑ j, c j * moment w x j := by
  rw [coeff_moment_eq]
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hp _ (hx i)) (hw i))

/-- **Lower bound.** If `p ≤ f` on the support, `∑ c j k j ≤ Φ`. -/
theorem lower_bound (w x : Fin m → ℝ) (c : Fin n → ℝ) (f : ℝ → ℝ) (rbar : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hx : ∀ i, x i ∈ Set.Icc (0 : ℝ) rbar) (hp : ∀ r ∈ Set.Icc (0 : ℝ) rbar, poly c r ≤ f r) :
    ∑ j, c j * moment w x j ≤ ∑ i, w i * f (x i) := by
  rw [coeff_moment_eq]
  exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hp _ (hx i)) (hw i))

/-- **Slack.** Adding `s` to the constant coefficient raises the bound by `s k₀`; this is how the certified computation
turns a strict sign condition into a valid bound for the rounded polynomial. -/
theorem slack_shift (w x : Fin m → ℝ) (c : Fin n → ℝ) (f : ℝ → ℝ) (rbar s : ℝ)
    (hw : ∀ i, 0 ≤ w i) (hx : ∀ i, x i ∈ Set.Icc (0 : ℝ) rbar) (hp : ∀ r ∈ Set.Icc (0 : ℝ) rbar, f r ≤ poly c r + s) :
    ∑ i, w i * f (x i) ≤ ∑ j, c j * moment w x j + s * moment w x 0 := by
  have h1 : ∑ i, w i * f (x i) ≤ ∑ i, w i * (poly c (x i) + s) :=
    Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hp _ (hx i)) (hw i))
  have h2 : ∑ i, w i * (poly c (x i) + s) = ∑ i, w i * poly c (x i) + s * moment w x 0 := by
    unfold moment; simp only [pow_zero, mul_one, mul_add, Finset.sum_add_distrib, Finset.mul_sum]
    congr 1; exact Finset.sum_congr rfl (fun i _ => by ring)
  rw [h2, ← coeff_moment_eq] at h1; exact h1

end InfoSafety
