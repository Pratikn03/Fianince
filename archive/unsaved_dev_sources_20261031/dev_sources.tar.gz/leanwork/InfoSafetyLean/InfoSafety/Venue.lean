import InfoSafety.Prelude

/-!
# Proposition `prop:venue` (Paper 2, Section 6.6): admission that changes the dynamics

Admitting a fraction `α` adds feedback `α Φ`, deepens the book (impact `κ₀ / (1 + δ α)`) and speeds reversion
(`1 - a₀ + ρ α`). The summed response is `κ₀ / D α` with `D α = (1 + δ α)(1 - a₀ + ρ α) - κ₀ Φ α`, and a level is safe iff
`D α ≥ τ` with `τ = κ₀ L / B`, i.e. iff the margin `D α - κ₀ L / B ≥ 0`.
-/

namespace InfoSafety

/-- `D α`. -/
def Dv (κ0 a0 Φ δ ρ α : ℝ) : ℝ := (1 + δ * α) * (1 - a0 + ρ * α) - κ0 * Φ * α

/-- Safety margin `D α - κ₀ ℓ`, with `ℓ = L / B`. -/
def margin (κ0 a0 Φ δ ρ ℓ α : ℝ) : ℝ := Dv κ0 a0 Φ δ ρ α - κ0 * ℓ

/-- `D` is convex in `α` when `δ ρ ≥ 0`. -/
theorem Dv_convex (κ0 a0 Φ δ ρ x y t : ℝ) (hδρ : 0 ≤ δ * ρ) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    Dv κ0 a0 Φ δ ρ (t * x + (1 - t) * y) ≤ t * Dv κ0 a0 Φ δ ρ x + (1 - t) * Dv κ0 a0 Φ δ ρ y := by
  unfold Dv
  have key : t * ((1 + δ * x) * (1 - a0 + ρ * x) - κ0 * Φ * x) + (1 - t) * ((1 + δ * y) * (1 - a0 + ρ * y) - κ0 * Φ * y)
      - ((1 + δ * (t * x + (1 - t) * y)) * (1 - a0 + ρ * (t * x + (1 - t) * y)) - κ0 * Φ * (t * x + (1 - t) * y))
      = (δ * ρ) * (t * (1 - t)) * (x - y) ^ 2 := by ring
  have : 0 ≤ (δ * ρ) * (t * (1 - t)) * (x - y) ^ 2 := by
    apply mul_nonneg (mul_nonneg hδρ (mul_nonneg ht0 (by linarith))) (sq_nonneg _)
  linarith

/-- **Proposition `prop:venue` (i).** The unsafe levels form an interval: if two levels are unsafe, so is every level
between them. Hence the safe levels in `[0,1]` are `[0,1]` minus at most one interval. -/
theorem unsafe_between (κ0 a0 Φ δ ρ ℓ x y z : ℝ) (hδρ : 0 ≤ δ * ρ) (hxy : x ≤ y) (hyz : y ≤ z)
    (hx : margin κ0 a0 Φ δ ρ ℓ x < 0) (hz : margin κ0 a0 Φ δ ρ ℓ z < 0) : margin κ0 a0 Φ δ ρ ℓ y < 0 := by
  unfold margin at *
  rcases eq_or_lt_of_le (hxy.trans hyz) with hxz | hxz
  · have : y = x := le_antisymm (hxz ▸ hyz) hxy
    rw [this]; exact hx
  · set t := (z - y) / (z - x) with ht
    have hzx : 0 < z - x := by linarith
    have ht0 : 0 ≤ t := div_nonneg (by linarith) hzx.le
    have ht1 : t ≤ 1 := by rw [div_le_one hzx]; linarith
    have hy : y = t * x + (1 - t) * z := by
      rw [ht]; field_simp <;> ring
    have hc := Dv_convex κ0 a0 Φ δ ρ x z t hδρ ht0 ht1
    rw [← hy] at hc
    have hm := max_lt hx hz
    have h1 := mul_le_mul_of_nonneg_left
      (le_max_left (Dv κ0 a0 Φ δ ρ x - κ0 * ℓ) (Dv κ0 a0 Φ δ ρ z - κ0 * ℓ)) ht0
    have h2 := mul_le_mul_of_nonneg_left
      (le_max_right (Dv κ0 a0 Φ δ ρ x - κ0 * ℓ) (Dv κ0 a0 Φ δ ρ z - κ0 * ℓ)) (sub_nonneg.mpr ht1)
    nlinarith

/-- **Proposition `prop:venue` (ii).** For `α ≥ 0` the margin is smallest at the corner
`(κ₀⁺, a₀⁺, Φ⁺, δ⁻, ρ⁻)` of the parameter box, the same corner for every `α`. -/
theorem worst_corner (κ0 a0 Φ δ ρ κp ap Φp δm ρm ℓ α : ℝ) (hα : 0 ≤ α) (hℓ : 0 ≤ ℓ)
    (hκ : κ0 ≤ κp) (ha : a0 ≤ ap) (hΦ : Φ ≤ Φp) (hδ : δm ≤ δ) (hρ : ρm ≤ ρ)
    (hΦ0 : 0 ≤ Φ) (hκ0 : 0 ≤ κ0) (hδm : 0 ≤ δm) (hρm : 0 ≤ ρm) (hap : ap < 1) :
    margin κp ap Φp δm ρm ℓ α ≤ margin κ0 a0 Φ δ ρ ℓ α := by
  unfold margin Dv
  have h1 : (1 + δm * α) * (1 - ap + ρm * α) ≤ (1 + δ * α) * (1 - a0 + ρ * α) := by
    apply mul_le_mul
    · nlinarith
    · nlinarith
    · nlinarith
    · nlinarith
  have h2 : κ0 * Φ * α ≤ κp * Φp * α := by
    apply mul_le_mul_of_nonneg_right _ hα
    exact mul_le_mul hκ hΦ hΦ0 (hκ0.trans hκ)
  have h3 : κ0 * ℓ ≤ κp * ℓ := mul_le_mul_of_nonneg_right hκ hℓ
  linarith

/-- **Proposition `prop:venue` (iii), the example of Section 6.6.** At the worst corner of the box
`κ₀ ∈ [0.98, 1.02]`, `a₀ ∈ [0.58, 0.60]`, `Φ ∈ [2.3, 2.4]`, `δ ∈ [2.9, 3.1]`, `ρ ∈ [0.58, 0.62]` with `L/B = 0.37`,
the levels `0` and `1` are safe while `0.2` is not: the robust safe set is not an interval, so certifying the largest safe
level (`1`) and accepting every level below it would accept an unsafe level. -/
theorem venue_example :
    0 ≤ margin 1.02 0.60 2.4 2.9 0.58 0.37 0 ∧ margin 1.02 0.60 2.4 2.9 0.58 0.37 0.2 < 0 ∧
      0 ≤ margin 1.02 0.60 2.4 2.9 0.58 0.37 1 := by
  unfold margin Dv; norm_num

/-- The example's safe set has two components: every economy of the box is safe at `0` and `1`, and the worst one is
unsafe at `0.2`. -/
theorem venue_example_box (κ0 a0 Φ δ ρ : ℝ) (hκ : 0.98 ≤ κ0 ∧ κ0 ≤ 1.02) (ha : 0.58 ≤ a0 ∧ a0 ≤ 0.60)
    (hΦ : 2.3 ≤ Φ ∧ Φ ≤ 2.4) (hδ : 2.9 ≤ δ ∧ δ ≤ 3.1) (hρ : 0.58 ≤ ρ ∧ ρ ≤ 0.62) :
    0 ≤ margin κ0 a0 Φ δ ρ 0.37 0 ∧ 0 ≤ margin κ0 a0 Φ δ ρ 0.37 1 := by
  have c0 := worst_corner κ0 a0 Φ δ ρ 1.02 0.60 2.4 2.9 0.58 0.37 0 le_rfl (by norm_num) hκ.2 ha.2 hΦ.2 hδ.1 hρ.1
    (by linarith) (by linarith) (by norm_num) (by norm_num) (by norm_num)
  have c1 := worst_corner κ0 a0 Φ δ ρ 1.02 0.60 2.4 2.9 0.58 0.37 1 zero_le_one (by norm_num) hκ.2 ha.2 hΦ.2 hδ.1 hρ.1
    (by linarith) (by linarith) (by norm_num) (by norm_num) (by norm_num)
  obtain ⟨e0, -, e1⟩ := venue_example
  exact ⟨e0.trans c0, e1.trans c1⟩

end InfoSafety
