import InfoSafety.Prelude
import Mathlib.Data.Fintype.BigOperators

/-!
# Proposition `prop:twoworld` (Paper 2): the two-world capacity-loss bound

Finite observation spaces. Data `ω` are drawn from `p0` (world 0, safe capacity `v0`) or from `p1` (world 1, safe capacity
`v1 ≥ v0`). A data-driven admission rule `A : Ω → ℝ` never exceeds `v1`. Total variation is DEFINED as the largest
discrepancy over events (not assumed); the Markov step is PROVED. If the rule admits more than `v0` in world 0 with
probability at most `β`, then in world 1 it gives up at least `(v1 - v0) (1 - β - TV)₊` in expectation. The bound is
attained when the two worlds produce the same data.
-/

open Finset

namespace InfoSafety

variable {Ω : Type*} [Fintype Ω] [DecidableEq Ω]

/-- Probability of an event under a weight function. -/
def prob (p : Ω → ℝ) (E : Finset Ω) : ℝ := ∑ ω ∈ E, p ω

/-- Expectation under a weight function. -/
def expect (p : Ω → ℝ) (f : Ω → ℝ) : ℝ := ∑ ω, p ω * f ω

/-- Total variation distance: the largest discrepancy between the two laws over all events. -/
noncomputable def tv (p0 p1 : Ω → ℝ) : ℝ :=
  (Finset.univ : Finset (Finset Ω)).sup' ⟨∅, Finset.mem_univ _⟩ (fun E => |prob p0 E - prob p1 E|)

lemma prob_sub_le_tv (p0 p1 : Ω → ℝ) (E : Finset Ω) : prob p0 E - prob p1 E ≤ tv p0 p1 :=
  (le_abs_self _).trans (Finset.le_sup' (fun E => |prob p0 E - prob p1 E|) (Finset.mem_univ E))

lemma prob_filter_add_not (p : Ω → ℝ) (P : Ω → Prop) [DecidablePred P] :
    prob p (univ.filter P) + prob p (univ.filter (fun ω => ¬ P ω)) = ∑ ω, p ω := by
  unfold prob
  exact Finset.sum_filter_add_sum_filter_not univ P p

/-- **Proposition `prop:twoworld`.** -/
theorem two_world_capacity_loss (p0 p1 : Ω → ℝ) (hp0 : ∑ ω, p0 ω = 1) (hp1 : ∀ ω, 0 ≤ p1 ω)
    (A : Ω → ℝ) (v0 v1 β : ℝ) (hv : v0 ≤ v1) (hA : ∀ ω, A ω ≤ v1)
    (hsafe : prob p0 (univ.filter (fun ω => v0 < A ω)) ≤ β) :
    (v1 - v0) * max 0 (1 - β - tv p0 p1) ≤ expect p1 (fun ω => v1 - A ω) := by
  classical
  set E := univ.filter (fun ω => ¬ (v0 < A ω)) with hE
  -- world 0 puts mass at least 1 - β on E
  have h0E : 1 - β ≤ prob p0 E := by
    have := prob_filter_add_not p0 (fun ω => v0 < A ω)
    linarith
  -- world 1 puts mass at least 1 - β - TV on E
  have h1E : 1 - β - tv p0 p1 ≤ prob p1 E := by
    have := prob_sub_le_tv p0 p1 E
    linarith
  -- Markov step: v1 - A ≥ 0 everywhere and ≥ v1 - v0 on E
  have hmarkov : (v1 - v0) * prob p1 E ≤ expect p1 (fun ω => v1 - A ω) := by
    unfold expect prob
    rw [Finset.mul_sum]
    calc ∑ ω ∈ E, (v1 - v0) * p1 ω ≤ ∑ ω ∈ E, p1 ω * (v1 - A ω) := by
            apply Finset.sum_le_sum
            intro ω hω
            have hle : A ω ≤ v0 := by
              simp only [hE, Finset.mem_filter, Finset.mem_univ, true_and, not_lt] at hω
              exact hω
            nlinarith [hp1 ω]
      _ ≤ ∑ ω, p1 ω * (v1 - A ω) := by
            apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ E)
            intro ω _ _
            exact mul_nonneg (hp1 ω) (by linarith [hA ω])
  have hexp_nn : 0 ≤ expect p1 (fun ω => v1 - A ω) := by
    unfold expect
    exact Finset.sum_nonneg (fun ω _ => mul_nonneg (hp1 ω) (by linarith [hA ω]))
  rcases le_total (1 - β - tv p0 p1) 0 with h | h
  · rw [max_eq_left h]; simpa using hexp_nn
  · rw [max_eq_right h]
    calc (v1 - v0) * (1 - β - tv p0 p1) ≤ (v1 - v0) * prob p1 E :=
          mul_le_mul_of_nonneg_left h1E (by linarith)
      _ ≤ _ := hmarkov

/-- **Attainment.** With identical data (`TV = 0`), the randomized rule that admits `v1` with probability `β` and `v0`
otherwise satisfies the safety constraint and loses exactly `(1 - β)(v1 - v0)`. -/
theorem two_world_attained (v0 v1 β : ℝ) (hβ0 : 0 ≤ β) (hβ1 : β ≤ 1) (hv : v0 < v1) :
    let p : Bool → ℝ := fun b => if b then β else 1 - β
    let A : Bool → ℝ := fun b => if b then v1 else v0
    tv p p = 0 ∧ prob p (univ.filter (fun ω => v0 < A ω)) = β ∧
      expect p (fun ω => v1 - A ω) = (v1 - v0) * max 0 (1 - β - tv p p) := by
  intro p A
  have htv : tv p p = 0 := by
    unfold tv
    apply le_antisymm
    · apply Finset.sup'_le; intro E _; simp
    · exact (abs_nonneg _).trans (Finset.le_sup' (fun E => |prob p E - prob p E|) (Finset.mem_univ ∅))
  refine ⟨htv, ?_, ?_⟩
  · have : univ.filter (fun ω : Bool => v0 < A ω) = {true} := by
      ext b; cases b <;> simp [A, hv, lt_irrefl]
    rw [this]; simp [prob, p]
  · rw [htv, sub_zero, max_eq_right (by linarith)]
    simp [expect, p, A, Fintype.sum_bool] <;> ring

end InfoSafety
