import InfoSafety.Prelude
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.MetricSpace.Pseudo.Lemmas

/-!
# Theorem `thm:venuebb` (Paper 2, Section 6.6): what the branch-and-bound output certifies

The certified computation encloses the summed response `S α θ` over boxes of levels and parameters in interval arithmetic
with outward rounding. That enclosures contain the exact values is a property of IEEE floating point (Rump 2010) and is
taken here as the hypothesis `hencl`; everything that follows from it is proved:

* (i) a level box classified safe (upper enclosure within budget on every part of a cover of `Θ`) is safe for every
  economy in `Θ`; a box classified unsafe (lower enclosure above budget at one economy) is unsafe for that economy;
* (ii) the robust safe set is closed when each `S · θ` is continuous, so the largest safe level in `[0,1]` exists whenever
  some level is safe, and any certified-safe level is a lower bracket for it.
-/

namespace InfoSafety

variable {Θ : Type*}

/-- **(i) Safe classification is sound.** If `Θ` is covered by parts on each of which the enclosure's upper end is within
budget, every level in the box is safe for every economy. -/
theorem classify_safe_sound {ι : Type*} (S : ℝ → Θ → ℝ) (A : Set ℝ) (Θs : Set Θ) (part : ι → Set Θ) (U : ι → ℝ)
    (B : ℝ) (hcover : Θs ⊆ ⋃ i, part i) (hencl : ∀ i, ∀ α ∈ A, ∀ θ ∈ part i, S α θ ≤ U i) (hU : ∀ i, U i ≤ B) :
    ∀ α ∈ A, ∀ θ ∈ Θs, S α θ ≤ B := by
  intro α hα θ hθ
  obtain ⟨i, hi⟩ := Set.mem_iUnion.mp (hcover hθ)
  exact (hencl i α hα θ hi).trans (hU i)

/-- **(i) Unsafe classification is sound.** A lower enclosure above budget at one economy of `Θ` makes every level in the
box unsafe for that economy. -/
theorem classify_unsafe_sound (S : ℝ → Θ → ℝ) (A : Set ℝ) (Θs : Set Θ) (θj : Θ) (hθj : θj ∈ Θs) (L B : ℝ)
    (hencl : ∀ α ∈ A, L ≤ S α θj) (hL : B < L) : ∀ α ∈ A, ∃ θ ∈ Θs, B < S α θ :=
  fun α hα => ⟨θj, hθj, hL.trans_le (hencl α hα)⟩

/-- The robust safe set `{α | ∀ θ ∈ Θ, S α θ ≤ B}`. -/
def robustSafeSet (S : ℝ → Θ → ℝ) (Θs : Set Θ) (B : ℝ) : Set ℝ := {α | ∀ θ ∈ Θs, S α θ ≤ B}

/-- **(ii) Closedness.** -/
theorem robustSafeSet_closed (S : ℝ → Θ → ℝ) (Θs : Set Θ) (B : ℝ) (hcont : ∀ θ, Continuous fun α => S α θ) :
    IsClosed (robustSafeSet S Θs B) := by
  have : robustSafeSet S Θs B = ⋂ θ ∈ Θs, {α | S α θ ≤ B} := by
    ext α; simp [robustSafeSet]
  rw [this]
  exact isClosed_biInter (fun θ _ => isClosed_le (hcont θ) continuous_const)

/-- **(ii) Existence and bracketing of the largest safe level.** If some level in `[0,1]` is safe, a greatest safe level
in `[0,1]` exists, and every certified-safe level lies below it. -/
theorem largest_safe_exists (S : ℝ → Θ → ℝ) (Θs : Set Θ) (B : ℝ) (hcont : ∀ θ, Continuous fun α => S α θ)
    (hne : (Set.Icc (0 : ℝ) 1 ∩ robustSafeSet S Θs B).Nonempty) :
    ∃ αmax, IsGreatest (Set.Icc (0 : ℝ) 1 ∩ robustSafeSet S Θs B) αmax ∧
      ∀ α ∈ Set.Icc (0 : ℝ) 1 ∩ robustSafeSet S Θs B, α ≤ αmax := by
  have hK : IsCompact (Set.Icc (0 : ℝ) 1 ∩ robustSafeSet S Θs B) :=
    isCompact_Icc.inter_right (robustSafeSet_closed S Θs B hcont)
  obtain ⟨αmax, hmax⟩ := hK.exists_isGreatest hne
  exact ⟨αmax, hmax, hmax.2⟩

end InfoSafety
