import InfoSafety.Prelude

/-!
# Deterministic cores of Proposition `prop:hotelling` (iii) and Proposition `prop:probe` (Paper 2)

* `prop:hotelling` (iii): with nonnegatively correlated taps (correlation `φ^|i-j|`, `φ ≥ 0`), the variance of the summed
  window, `σ² 1ᵀR1`, is at least the `T σ²` that the (O1) certificate assumes, so its margin `z σ √(T/N)` is at most the
  margin `z σ √(1ᵀR1/N)` that exact coverage needs. (That the second margin covers exactly `1 - γ` is Student/normal
  theory and is not formalized.)
* `prop:probe`: on the time-uniform event `|X̄ₙ - S_T| < rₙ` for every `n` (which Ville's inequality makes probability at
  least `1 - γ`; not formalized), the sequential rule never decides wrongly, whatever its stopping time.
-/

open Finset

namespace InfoSafety

/-- Sum of the AR(1) correlation matrix entries. -/
def corrSum (φ : ℝ) (T : ℕ) : ℝ := ∑ i ∈ range T, ∑ j ∈ range T, φ ^ (max i j - min i j)

/-- `1ᵀR1 ≥ T` when `φ ≥ 0`. -/
theorem corrSum_ge (φ : ℝ) (hφ : 0 ≤ φ) (T : ℕ) : (T : ℝ) ≤ corrSum φ T := by
  unfold corrSum
  have : ∀ i ∈ range T, (1 : ℝ) ≤ ∑ j ∈ range T, φ ^ (max i j - min i j) := by
    intro i hi
    have h := Finset.single_le_sum (f := fun j => φ ^ (max i j - min i j)) (fun j _ => pow_nonneg hφ _) hi
    simpa using h
  calc (T : ℝ) = ∑ i ∈ range T, (1 : ℝ) := by simp
    _ ≤ _ := Finset.sum_le_sum this

/-- **`prop:hotelling` (iii), deterministic core.** The (O1) margin `z σ √(T/N)` is at most the margin `z σ √(1ᵀR1/N)`
that exact coverage needs; stated for any nonnegative square roots `s₁² = T/N` and `s₂² = 1ᵀR1/N`. -/
theorem o1_margin_too_small (φ z σ N s1 s2 : ℝ) (T : ℕ) (hφ : 0 ≤ φ) (hz : 0 ≤ z) (hσ : 0 ≤ σ) (hN : 0 < N)
    (hs1 : 0 ≤ s1) (hs2 : 0 ≤ s2) (h1 : s1 ^ 2 = T / N) (h2 : s2 ^ 2 = corrSum φ T / N) :
    z * σ * s1 ≤ z * σ * s2 := by
  apply mul_le_mul_of_nonneg_left _ (mul_nonneg hz hσ)
  have hle : s1 ^ 2 ≤ s2 ^ 2 := by
    rw [h1, h2]; exact div_le_div_of_nonneg_right (corrSum_ge φ hφ T) hN.le
  nlinarith [sq_nonneg (s1 - s2), sq_nonneg (s1 + s2)]

/-- **`prop:probe`, deterministic core: no wrong decision on the time-uniform event.** If at every `n` the running mean is
within `r n` of `S_T`, and the true risk exceeds `S_T` by at most the tail bound, then whenever the rule stops to accept
(`X̄ + r + tail ≤ s_B`) the true risk is within budget, and whenever it stops to refuse (`X̄ - r > s_B`) the true risk
exceeds the budget — at every `n`, hence at any stopping time. -/
theorem sequential_rule_correct (xbar r : ℕ → ℝ) (ST S tail sB : ℝ) (hcs : ∀ n, |xbar n - ST| < r n)
    (htail : ST ≤ S ∧ S ≤ ST + tail) (n : ℕ) :
    (xbar n + r n + tail ≤ sB → S ≤ sB) ∧ (sB < xbar n - r n → sB < S) := by
  have h := abs_lt.mp (hcs n)
  constructor
  · intro hstop; linarith [htail.2, h.1]
  · intro hstop; linarith [htail.1, h.2]

end InfoSafety
