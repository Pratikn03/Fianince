import InfoSafety.Prelude

/-!
# The corrected quantity gate (Paper 2, Section 6.1; blueprint D1)

For a linear market with price impulse coefficients `g k` and a drift `d` from the current state, the worst price excursion
over shock paths with a per-period bound `|v k| ≤ V` is `|d| + V ∑ |g k|`, attained by aligning every shock's sign with the
drift; with a total budget `∑ |v k| ≤ W` (and no drift) it is `W max |g k|`, attained at a vertex. The peak gain
`max |g k|` is therefore the right allowance only for a single shock, not for repeated per-period trading.
-/

open Finset

namespace InfoSafety

variable {n : ℕ}

/-- Per-period bound: `|d + ∑ g v| ≤ |d| + V ∑ |g|` for every admissible path. -/
theorem per_period_upper (g v : Fin n → ℝ) (d V : ℝ) (hv : ∀ k, |v k| ≤ V) :
    |d + ∑ k, g k * v k| ≤ |d| + V * ∑ k, |g k| := by
  calc |d + ∑ k, g k * v k| ≤ |d| + |∑ k, g k * v k| := abs_add_le _ _
    _ ≤ |d| + ∑ k, |g k * v k| := by gcongr; exact Finset.abs_sum_le_sum_abs _ _
    _ ≤ |d| + V * ∑ k, |g k| := by
        rw [Finset.mul_sum]; gcongr with k
        rw [abs_mul, mul_comm V]
        exact mul_le_mul_of_nonneg_left (hv k) (abs_nonneg _)

/-- Sign of the drift (`1` when `d ≥ 0`). -/
noncomputable def driftSign (d : ℝ) : ℝ := if 0 ≤ d then 1 else -1

/-- The shock path that attains the per-period bound: each shock has the sign of `driftSign d * g k`. -/
noncomputable def alignedPath (g : Fin n → ℝ) (d V : ℝ) : Fin n → ℝ :=
  fun k => if 0 ≤ driftSign d * g k then V else -V

lemma aligned_term (g : Fin n → ℝ) (d V : ℝ) (k : Fin n) :
    g k * alignedPath g d V k = driftSign d * (V * |g k|) := by
  unfold alignedPath driftSign
  by_cases hd : 0 ≤ d
  · rw [if_pos hd, one_mul, one_mul]
    by_cases hg : 0 ≤ g k
    · rw [if_pos hg, abs_of_nonneg hg]; ring
    · rw [if_neg hg, abs_of_neg (not_le.mp hg)]; ring
  · rw [if_neg hd]
    by_cases hg : 0 ≤ -1 * g k
    · rw [if_pos hg, abs_of_nonpos (by linarith)]; ring
    · rw [if_neg hg, abs_of_pos (by linarith)]; ring

/-- **Attainment.** The aligned path is admissible and its excursion equals `|d| + V ∑ |g|`. -/
theorem per_period_attained (g : Fin n → ℝ) (d V : ℝ) (hV : 0 ≤ V) :
    (∀ k, |alignedPath g d V k| ≤ V) ∧
      |d + ∑ k, g k * alignedPath g d V k| = |d| + V * ∑ k, |g k| := by
  refine ⟨fun k => by unfold alignedPath; split_ifs <;> simp [abs_of_nonneg hV], ?_⟩
  have hsum : ∑ k, g k * alignedPath g d V k = driftSign d * (V * ∑ k, |g k|) := by
    rw [Finset.mul_sum, Finset.mul_sum]
    exact Finset.sum_congr rfl (fun k _ => by rw [aligned_term]; try ring)
  have hX : 0 ≤ V * ∑ k, |g k| := mul_nonneg hV (Finset.sum_nonneg (fun k _ => abs_nonneg _))
  rw [hsum]
  unfold driftSign
  by_cases hd : 0 ≤ d
  · rw [if_pos hd, one_mul, abs_of_nonneg (by linarith), abs_of_nonneg hd]
  · push_neg at hd
    rw [if_neg (not_le.mpr hd), abs_of_neg hd, abs_of_nonpos (by linarith)]; ring

/-- Total-budget bound: with `∑ |v k| ≤ W`, `|∑ g v| ≤ W · max |g|` (here `M` is any bound on every `|g k|`). -/
theorem budget_upper (g v : Fin n → ℝ) (W M : ℝ) (hM : ∀ k, |g k| ≤ M) (hW : ∑ k, |v k| ≤ W) (hM0 : 0 ≤ M) :
    |∑ k, g k * v k| ≤ W * M := by
  calc |∑ k, g k * v k| ≤ ∑ k, |g k * v k| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ k, M * |v k| := by
        gcongr with k; rw [abs_mul]; exact mul_le_mul_of_nonneg_right (hM k) (abs_nonneg _)
    _ = M * ∑ k, |v k| := by rw [Finset.mul_sum]
    _ ≤ M * W := mul_le_mul_of_nonneg_left hW hM0
    _ = W * M := mul_comm _ _

/-- **Attainment at a vertex.** Putting the whole budget on the coefficient of largest magnitude attains `W |g j|`. -/
theorem budget_attained (g : Fin n → ℝ) (W : ℝ) (hW : 0 ≤ W) (j : Fin n) :
    let v : Fin n → ℝ := fun k => if k = j then W else 0
    (∑ k, |v k| = W) ∧ |∑ k, g k * v k| = W * |g j| := by
  intro v
  have habs : ∀ x, |(if x = j then W else 0)| = if x = j then W else 0 := fun x => by
    split_ifs <;> simp [abs_of_nonneg hW]
  constructor
  · simp [v, habs]
  · simp [v, abs_mul, abs_of_nonneg hW, mul_comm]

/-- **The peak gain understates the repeated-shock risk.** If two coefficients are nonzero, the per-period worst case
`V ∑ |g|` strictly exceeds the single-shock allowance `V max |g|` (stated with any coefficient `j`). -/
theorem peak_understates (g : Fin n → ℝ) (V : ℝ) (hV : 0 < V) (i j : Fin n) (hij : i ≠ j) (hi : g i ≠ 0) :
    V * |g j| < V * ∑ k, |g k| := by
  apply mul_lt_mul_of_pos_left _ hV
  have hsub : ({i, j} : Finset (Fin n)) ⊆ Finset.univ := Finset.subset_univ _
  have h2 : ∑ k ∈ ({i, j} : Finset (Fin n)), |g k| ≤ ∑ k, |g k| :=
    Finset.sum_le_sum_of_subset_of_nonneg hsub (fun k _ _ => abs_nonneg _)
  rw [Finset.sum_pair hij] at h2
  have : 0 < |g i| := abs_pos.mpr hi
  linarith

end InfoSafety
