p='InfoSafety/VenueBB.lean'; s=open(p).read()
s=s.replace("import Mathlib.Topology.Instances.Real.Lemmas","import Mathlib.Topology.MetricSpace.Pseudo.Lemmas"); open(p,'w').write(s)
p='InfoSafety/Stat.lean'; s=open(p).read()
s=s.replace("import Mathlib.Data.Real.Sqrt\n","")
old=s[s.index("/-- **`prop:hotelling` (iii), deterministic core.**"):s.index("/-- **`prop:probe`, deterministic core")]
new='''/-- **`prop:hotelling` (iii), deterministic core.** The (O1) margin `z σ √(T/N)` is at most the margin `z σ √(1ᵀR1/N)`
that exact coverage needs; stated for any nonnegative square roots `s₁² = T/N` and `s₂² = 1ᵀR1/N`. -/
theorem o1_margin_too_small (φ z σ N s1 s2 : ℝ) (T : ℕ) (hφ : 0 ≤ φ) (hz : 0 ≤ z) (hσ : 0 ≤ σ) (hN : 0 < N)
    (hs1 : 0 ≤ s1) (hs2 : 0 ≤ s2) (h1 : s1 ^ 2 = T / N) (h2 : s2 ^ 2 = corrSum φ T / N) :
    z * σ * s1 ≤ z * σ * s2 := by
  apply mul_le_mul_of_nonneg_left _ (mul_nonneg hz hσ)
  have hle : s1 ^ 2 ≤ s2 ^ 2 := by
    rw [h1, h2]; exact div_le_div_of_nonneg_right (corrSum_ge φ hφ T) hN.le
  nlinarith [sq_nonneg (s1 - s2), sq_nonneg (s1 + s2)]

'''
s=s.replace(old,new); open(p,'w').write(s)
p='InfoSafety/Hardening.lean'; s=open(p).read()
s=s.replace("import Mathlib.Data.Real.Sqrt\n","")
old=s[s.index("/-- From `r² ≥ L₀ (1 - γ D)`"):s.index("/-! ## Paper 1, Proposition `prop:tagged` -/")]
new='''/-- From `r² ≥ L₀ (1 - γ D)` and `r ≥ 0`, `r ≥ √L₀ · (1 - γ D)₊` when `γ D ≥ 0`; `s` is any nonnegative square root of
`L₀`. -/
theorem rh_radius_bound (r L0 s γ D : ℝ) (hr : 0 ≤ r) (hs : 0 ≤ s) (hsL : s ^ 2 = L0) (hγD : 0 ≤ γ * D)
    (h : L0 * (1 - γ * D) ≤ r ^ 2) : s * max 0 (1 - γ * D) ≤ r := by
  rcases le_total (1 - γ * D) 0 with hneg | hpos
  · rw [max_eq_left hneg, mul_zero]; exact hr
  · rw [max_eq_right hpos]
    set y := 1 - γ * D with hy
    have hy1 : y ≤ 1 := by rw [hy]; linarith
    have hL0 : 0 ≤ L0 := by rw [← hsL]; positivity
    have hsq : (s * y) ^ 2 ≤ r ^ 2 := by
      rw [mul_pow, hsL]
      have : y ^ 2 ≤ y := by nlinarith
      nlinarith [mul_le_mul_of_nonneg_left this hL0]
    have hl : 0 ≤ s * y := mul_nonneg hs hpos
    nlinarith [sq_nonneg (s * y - r), sq_nonneg (s * y + r)]

/-- **The explicit Rayleigh--Hölder chain.** With loss `L₀ + x²`, a fee that is nonnegative and at least
`c ‖Ed‖₁ r - x √W`, and `r ≥ √L₀ (1 - γ x²)₊`, loss plus fee is at least
`L₀ + x² + max 0 (F (1 - γ x²)₊ - √W x)` with `F = c ‖Ed‖₁ √L₀` (`s = √L₀`, `sW = √W`). -/
theorem rh_chain (L0 x r fee cE s sW γ : ℝ) (hcE : 0 ≤ cE) (hfee0 : 0 ≤ fee)
    (hfee : cE * r - x * sW ≤ fee) (hr : s * max 0 (1 - γ * x ^ 2) ≤ r) :
    L0 + x ^ 2 + max 0 (cE * s * max 0 (1 - γ * x ^ 2) - sW * x) ≤ L0 + x ^ 2 + fee := by
  have h1 : cE * s * max 0 (1 - γ * x ^ 2) ≤ cE * r := by
    rw [mul_assoc]; exact mul_le_mul_of_nonneg_left hr hcE
  have h2 : max 0 (cE * s * max 0 (1 - γ * x ^ 2) - sW * x) ≤ fee :=
    max_le hfee0 (by linarith)
  linarith

'''
s=s.replace(old,new); open(p,'w').write(s)
p='InfoSafety.lean'; s=open(p).read()
if "Hardening" not in s: s=s.rstrip()+"\nimport InfoSafety.Hardening\n"
open(p,'w').write(s)
print("edited")
