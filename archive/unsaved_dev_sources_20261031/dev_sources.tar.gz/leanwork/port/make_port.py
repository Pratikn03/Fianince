"""Combine the InfoSafety modules into one CurrentMM file with is_-prefixed names."""
import re, sys
SRC = "/home/claude/leanwork/InfoSafetyLean/InfoSafety/"
ORDER = ["TwoWorld", "Gate", "RobustGuard", "Venue", "VenueBB", "WeakDuality", "Decay", "BalanceSheet", "Stat", "Hardening"]
texts = {m: open(SRC + m + ".lean").read() for m in ORDER}
decl = re.compile(r"^(?:noncomputable )?(?:def|theorem|lemma|abbrev) ([A-Za-z0-9_']+)", re.M)
names = sorted({n for t in texts.values() for n in decl.findall(t)}, key=len, reverse=True)
def rename(t):
    for n in names:
        t = re.sub(r"(?<![A-Za-z0-9_.'])" + re.escape(n) + r"(?![A-Za-z0-9_'])", "is_" + n, t)
    return t
body = []
for m in ORDER:
    t = texts[m]
    t = re.sub(r"^import .*\n", "", t, flags=re.M)
    t = t.replace("namespace InfoSafety", "").replace("end InfoSafety", "")
    t = rename(t)
    t = t.replace("InfoSafety.", "")
    body.append(f"section IS_{m}\n" + t.strip() + f"\n\nend IS_{m}\n")
HEADER_REPO = "import Mathlib\n"
HEADER_LOCAL = "\n".join(["import InfoSafety.Prelude", "import Mathlib.Data.Fintype.BigOperators",
                          "import Mathlib.Topology.Order.Compact", "import Mathlib.Topology.MetricSpace.Pseudo.Lemmas"]) + "\n"
DOC = '''
/-!
# Information-safety extensions of Paper 2 and the October 2026 hardening results (Papers 1 and 2)

Machine-checked cores of: Proposition `prop:twoworld`, the corrected quantity gate, Theorem `thm:robustguard`,
Proposition `prop:venue`, Theorem `thm:venuebb` (given the floating-point enclosure property as a hypothesis),
Lemma `lem:certnum` (weak duality; the Hermite sign condition is not formalized), Theorem `thm:certcost` (i)
(deterministic decay and tail), Theorem `thm:forward` (one step), Proposition `prop:hotelling` (iii) and
Proposition `prop:probe` (deterministic cores; the probability statements are not formalized), and the hardening results
listed in section `IS_Hardening`. Every declaration is prefixed `is_`. Coverage tags are in `COVERAGE.md`.
-/

namespace CurrentMM
open Finset

'''
out = DOC + "\n".join(body) + "\nend CurrentMM\n"
open(sys.argv[1], "w").write(HEADER_REPO + out)
open(sys.argv[2], "w").write(HEADER_LOCAL + out)
print(len(names), "names renamed")
